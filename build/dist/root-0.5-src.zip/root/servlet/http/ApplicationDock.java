package root.servlet.http;

import java.util.Enumeration;

import javax.servlet.ServletContext;

class ApplicationDock implements LoadingDock {

	private final ServletContext context;

	ApplicationDock(final ServletContext context) {
		this.context = context;
	}

	public boolean contains(final String name) {
		return context.getAttribute(name) != null;
	}

	public boolean contains(final Object key) {
		return context.getAttribute(key.toString()) != null;
	}

	public Object get(final String name) {
		return context.getAttribute(name);
	}

	public Object get(final Object key) {
		return context.getAttribute(key.toString());
	}

	public void set(final String name, final Object value) {
		context.setAttribute(name, value);
	}

	public void set(final Object key, final Object value) {
		context.setAttribute(key.toString(), value);
	}

	public void remove(final String name) {
		context.removeAttribute(name);
	}

	public void remove(final Object key) {
		context.removeAttribute(key.toString());
	}

	@Override
	@SuppressWarnings("unchecked")
	public String toString() {
		String s;
		final StringBuilder builder = new StringBuilder(512);

		builder.append("ServletContext ").append(context.getServletContextName()).append(" attributes:\n");
		for (Enumeration<String> e = context.getAttributeNames(); e.hasMoreElements(); ) {
			s = e.nextElement();
			builder.append(s).append('=').append(context.getAttribute(s)).append('\n');
		}

		return builder.toString();
	}

}	// End ApplicationDock
