package root.servlet.http;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Warehouse {

	private ApplicationDock				app;
	private ClientDock					client;
	private RequestDock					reqDock;
	private SessionDock					session;

	private final HttpServletRequest	request;
	private final HttpServletResponse	response;

	public Warehouse(final HttpServletRequest request, final HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}

	public LoadingDock application() {
		if (app == null)
			app = new ApplicationDock(request.getSession().getServletContext());

		return app;
	}

	public LoadingDock client() {
		if (client == null)
			client = new ClientDock(request, response);

		return client;
	}

	public LoadingDock request() {
		if (reqDock == null)
			reqDock = new RequestDock(request);

		return reqDock;
	}

	public LoadingDock session() {
		if (session == null)
			session = new SessionDock(request.getSession());

		return session;
	}

}	// End Warehouse
