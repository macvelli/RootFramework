package root.servlet;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

public class HttpRequestDebugger {

	private final HttpServletRequest httpRequest;

	public HttpRequestDebugger(final HttpServletRequest httpRequest) {
		this.httpRequest = httpRequest;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder(512);
		String headerName;

		builder.append(httpRequest.getMethod()).append(' ').append(httpRequest.getRequestURI()).append(' ').append(httpRequest.getProtocol());
		for (Enumeration<String> e = httpRequest.getHeaderNames(); e.hasMoreElements(); ) {
			headerName = e.nextElement();
			builder.append('\n').append(headerName);
			int i = 0;
			for (Enumeration<String> f = httpRequest.getHeaders(headerName); f.hasMoreElements();)
				builder.append((i++ == 0) ? ':' : ',').append(' ').append(f.nextElement());
		}
		builder.append('\n').append('\n');

		if (httpRequest.getQueryString() != null)
			builder.append(httpRequest.getQueryString()).append('\n');
		else {
			String paramName;
			String[] paramValues;

			for (Enumeration<String> e = httpRequest.getParameterNames(); e.hasMoreElements();) {
				paramName = e.nextElement();
				paramValues = httpRequest.getParameterValues(paramName);

				builder.append(paramName).append(' ').append('=').append(' ');
				if (paramValues.length == 1)
					builder.append(paramValues[0]);
				else if (paramValues.length > 1) {
					builder.append('{').append(paramValues[0]);
					for (int i=1; i < paramValues.length; i++)
						builder.append(',').append(paramValues[i]);
					builder.append('}');
				}
			}
		}

		return builder.toString();
	}

}	// End HttpRequestDebugger
