package root.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import root.log.Log;

public abstract class HttpFilter implements Filter {

	private static final Log log = new Log(HttpFilter.class);

	public void init(final FilterConfig config) throws ServletException {
		// Default implementation does nothing.
	}

	public final void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
		final HttpServletRequest req = (HttpServletRequest) request;
		final HttpServletResponse resp = (HttpServletResponse) response;

		try {
			execute(req, resp);
		} catch (FilterInterruptException e) {
			return;
		} catch (Exception e) {
			log.error("{P} had a fatal error while attempting to process HTTP request:\n{P}", this.getClass().getName(), new HttpRequestDebugger(req));
			throw new ServletException(e);
		}

		chain.doFilter(request, response);

		this.afterChain(req, resp);
	}

	public void destroy() {
		// Default implementation does nothing
	}

//	*************************** Protected Methods ****************************

	protected abstract void execute(final HttpServletRequest request, final HttpServletResponse response) throws Exception;

	protected void afterChain(final HttpServletRequest req, final HttpServletResponse resp) {
		// Default implementation does nothing.
	}

}	// End HttpFilter
