package root.servlet;

@SuppressWarnings("serial")
public abstract class FilterInterruptException extends RuntimeException {}
