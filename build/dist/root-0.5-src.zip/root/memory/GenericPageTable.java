/*
 * GenericPageTable.java
 */
package root.memory;

import java.util.Collection;

import root.util.Clean;

/**
 * TODO
 * 		+ The demarcation comments were wonked coming into this class but they
 * 		  have been fixed and now need to be propagated back to the other classes
 * 		+ Any chance of turning this into a native implementation? LOL that would be killer
 * 		+ Need another "PagedList" that works natively with SQLBroker to only pull in
 * 		  data that qualify for the page window to display (i.e. pageSize = 10, page = 3,
 * 		  only pull elements 21 thru 30)
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public class GenericPageTable<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int capacity;
	private T[][] pageTable;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public GenericPageTable() {
		capacity = 128;
		pageTable = Clean.newArrayTwoDimensional(8);
	}

	public GenericPageTable(final int numPages) {
		capacity = numPages << 4;
		pageTable = Clean.newArrayTwoDimensional(numPages);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void arraycopy(int srcPos, final Object[] dest, int destPos, final int length) {
		int i = 0;

		for (int pageIndex = srcPos >> 4; i < length && pageIndex < pageTable.length; pageIndex++) {
			final T[] page = pageTable[pageIndex];

			for (int offset = srcPos - (pageIndex << 4); i < length && offset < page.length; i++, srcPos++, offset++) {
				dest[destPos++] = page[offset];
			}
		}
	}

	public final void clear() {
		for (int pageIndex = 0; pageIndex < pageTable.length; pageIndex++) {
			final T[] page = pageTable[pageIndex];

			if (page != null) {
				for (int offset = 0; offset < page.length; offset++) {
					page[offset] = null;
				}
				pageTable[pageIndex] = null;
			}
		}
	}

	public final T get(final int index) {
		final int pageIndex = index >> 4;

		if (pageIndex >= pageTable.length) {
			throw new InvalidPageReferenceException(pageIndex, pageTable.length);
		}

		final T[] page = pageTable[pageIndex];

		return (page == null) ? null : page[index - (pageIndex << 4)];
	}

	public final void put(final int index, final T o) {
		if (index >= capacity) {
			resize(index);
		}

		final int pageIndex = index >> 4;
		final T[] page = loadPage(pageIndex);
		page[index - (pageIndex << 4)] = o;
	}

	public final void putAll(int index, final T[] a) {
		final int lastIndex = index + a.length;

		if (lastIndex >= capacity) {
			resize(lastIndex);
		}

		for (T t : a) {
			final int pageIndex = index >> 4;
			final T[] page = loadPage(pageIndex);
			page[index - (pageIndex << 4)] = t;
			index++;
		}
	}

	public final void putAll(int index, final Collection<? extends T> c) {
		final int lastIndex = index + c.size();

		if (lastIndex >= capacity) {
			resize(lastIndex);
		}

		for (T t : c) {
			final int pageIndex = index >> 4;
			final T[] page = loadPage(pageIndex);
			page[index - (pageIndex << 4)] = t;
			index++;
		}
	}

	// <><><><><><><><><><><><><><> Private Methods <><><><><><><><><><><><><><

	private T[] loadPage(final int pageIndex) {
		T[] page = pageTable[pageIndex];

		if (page == null) {
			page = Clean.newArray(16);
			pageTable[pageIndex] = page;
		}

		return page;
	}

	private void resize(final int index) {
		int shiftCount = 0;

		do {
			capacity <<= 1;
			shiftCount++;
		} while (capacity <= index);

		final T[][] t = Clean.newArrayTwoDimensional(pageTable.length << shiftCount);
		System.arraycopy(pageTable, 0, t, 0, pageTable.length);
		pageTable = t;
	}

}	// End GenericPageTable
