/*
 * Base32File.java
 * 
 * Last Modified: 03/04/2016
 */
package root.io;

import java.io.File;

import root.codec.Base32;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class Base32File {

	// Constructors

	private Base32File() {}

	// Public Methods

	/**
	 * 
	 * 
	 * @param str
	 * @param basePath
	 * @param dirDepth
	 * @return
	 * @throws IllegalArgumentException
	 */
	public static File retrieve(final String str, final String basePath, final int dirDepth) {
		// TODO: Set a sensible string input max length here based on standard file length maximums
		if (str == null || str.length() < 3) {
			// TODO: Replace StringBuilder with faster Root implementation
			throw new IllegalArgumentException(
					new StringBuilder(120)
					.append("Attempt to retrieve Base32File with string input of ")
					.append(str)
					.append(" failed. String input must be at least three characters long.")
					.toString());
		}

		if (dirDepth < 0 || dirDepth > 2) {
			// TODO: Replace StringBuilder with faster Root implementation
			throw new IllegalArgumentException(
					new StringBuilder(125)
					.append("Attempt to retrieve Base32File with directory depth of ")
					.append(dirDepth)
					.append(" failed. Directory depth must be betwen zero and two.")
					.toString());
		}

		final String base32Str = Base32.encode(str);
		// TODO: Replace StringBuilder with faster Root implementation
		final StringBuilder fullPath = new StringBuilder(
				(basePath == null ? 0 : basePath.length()) +
				base32Str.length() + dirDepth + 1);

		fullPath.append(basePath);
		if (!basePath.endsWith(File.separator)) {
			fullPath.append(File.separatorChar);
		}

		if (dirDepth == 0) {
			fullPath.append(base32Str);
		} else {
			fullPath.append(base32Str, 0, 2);	// TODO: This is going to be slow
			fullPath.append(File.separatorChar);

			if (dirDepth == 1) {
				fullPath.append(base32Str, 2, base32Str.length()); // TODO: This is going to be slow
			} else {
				fullPath.append(base32Str, 2, 4);	// TODO: This is going to be slow
				fullPath.append(File.separatorChar);
				fullPath.append(base32Str, 4, base32Str.length()); // TODO: This is going to be slow				
			}
		}

		return new File(fullPath.toString());
	}

}	// End Base32File
