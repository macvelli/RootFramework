package root.io;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * http://java.sun.com/developer/technicalArticles/Streams/WritingIOSC/index.html
 * http://mindprod.com/jgloss/unsigned.html
 * 
 * TODO: Good example of a) extend from multiple classes b) parent class checked exception erasure
 * TODO: What about character encodings?
 * 
 * @author Ed Smith
 */
public class ByteArrayStream {

	private int		size;
	private byte[]	bytes;

	public ByteArrayStream() {
		bytes = new byte[32];
	}

	public ByteArrayStream(final int size) {
		bytes = new byte[size];
	}

	public ByteArrayStream(final byte[] bytes) {
		this.bytes = bytes;
		size = bytes.length;
	}

	public ByteArrayStream(final InputStream is) throws IOException {
		// TODO: What is the appropriate code here?  What if the InputStream is buffered?
		this.bytes = new byte[is.available()];
		is.read(bytes, 0, bytes.length);
		size = bytes.length;
	}

	public ByteArrayStream(final ByteArrayOutputStream os) {
		// TODO: Make this Fast!
		this.bytes = os.toByteArray();
		size = bytes.length;
	}

	public ByteArrayInput getInputStream() {
		return new ByteArrayInput();
	}

	public ByteArrayOutput getOutputStream() {
		return new ByteArrayOutput();
	}

	public byte[] getBytes() {
		final byte b[] = new byte[size];
		System.arraycopy(bytes, 0, b, 0, size);
		return b;
	}

	public int getSize() {
		return size;
	}

	public void reset() {
		size = 0;
	}

	public void writeTo(final OutputStream os) throws IOException {
		os.write(bytes, 0, size);
	}

	public String toString() {
		return new String(bytes, 0, size);
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Inner Classes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public class ByteArrayInput extends InputStream {

		private int loc;
		private int mark;

		private ByteArrayInput() {}

		public final int read() {
			return (loc == size) ? -1 : (bytes[loc++] & 0xff);
		}

		public final int read(final byte[] b) {
			return read(b, 0, b.length);
		}

		public final int read(final byte[] b, final int off, int len) {
			if (loc == size) {
				return -1;
			}

			if (loc + len > size) {
				len = size - loc;
			}

			System.arraycopy(bytes, loc, b, off, len);
			loc += len;

			return len;
		}

		public final int available() {
			return size - loc;
		}

		public final void mark(final int readlimit) {
			mark = loc;
		}

		public final boolean markSupported() {
			return true;
		}

		public final void reset() {
			loc = mark;
		}

		public final long skip(long len) {
			if (loc + len > size) {
				len = size - loc;
			}

			loc += len;

			return len;
		}

		public final void close() {}

	}	// End ByteArrayInput

	public class ByteArrayOutput extends OutputStream {

		private ByteArrayOutput() {}

		public final void write(final int b) {
			if (size == bytes.length) {
				resize(size << 1);
			}

			bytes[size++] = (byte) b;
		}

		public final void write(final byte[] b) {
			final int newSize = size + b.length;

			if (newSize > bytes.length) {
				resize(newSize << 1);
			}

	        System.arraycopy(b, 0, bytes, size, b.length);
			size = newSize;
		}

		public final void write(final byte[] b, final int offset, final int len) {
			final int newSize = size + len;

			if (newSize > bytes.length) {
				resize(newSize << 1);
			}

	        System.arraycopy(b, offset, bytes, size, len);
			size = newSize;
		}

		public final void close() {}

		public final void flush() {}

		public String toString() {
			return ByteArrayStream.this.toString();
		}

		// ~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~

		private void resize(final int capacity) {
			final byte[] b = new byte[capacity];
			System.arraycopy(bytes, 0, b, 0, size);
			bytes = b;
		}

	}	// End ByteArrayOutput

}	// End ByteArrayStream
