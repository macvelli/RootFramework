package root.lang;

public interface Builder {

	Object build();

}
