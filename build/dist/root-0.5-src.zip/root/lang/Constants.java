/*
 * Constants.java
 * 
 * Last Modified: 03/28/2016
 */
package root.lang;

/**
 * TODO: Move constants in Safe.java to here
 * 
 * @author esmith
 * @version 1.0
 */
public interface Constants {

	// <><><><><><><><><><><><><><><>< Constants <><><><><><><><><><><><><><><>

	public static final String EMPTY_STRING = "";

}	// End Constants
