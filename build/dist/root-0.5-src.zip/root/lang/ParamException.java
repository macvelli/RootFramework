package root.lang;

public class ParamException extends RuntimeException {

	private static final long serialVersionUID = 1138500495367634889L;

	public ParamException(final String msg, final Object... params) {
		super(ParamStr.format(msg, params));
	}

	public ParamException(final Throwable t, final String msg, final Object... params) {
		super(ParamStr.format(msg, params), t);
	}

}	// End ParamException
