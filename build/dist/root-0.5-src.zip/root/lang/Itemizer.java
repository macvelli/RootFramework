/*
 * Itemizer.java
 * 
 * Last Modified: 04/22/2016
 */
package root.lang;

import java.util.Iterator;

/**
 * The <code>Itemizer</code> class combines the {@link Iterator} and
 * {@link Iterable} interfaces since an {@link Iterator} is {@link Iterable}.
 * <code>Itemizer</code> also adds the <code>getIndex()</code>,
 * <code>getSize()</code>, and <code>reset()</code> utility methods.
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface Itemizer<T> extends Iterator<T>, Iterable<T> {

	/**
	 * 
	 * @return the current index of the {@link Itemizer}
	 */
	int getIndex();

	
	/**
	 * 
	 * @return the number of elements in the {@link Itemizer}
	 */
	int getSize();

	/**
	 * 
	 * @return this <code>Itemizer</code> in an {@link Iterable} role
	 */
	Itemizer<T> iterator();

	/**
	 * Resets the {@link Itemizer} to the beginning so it can be reused to
	 * iterate over the same items without calling <code>iterator()</code>
	 * again.
	 */
	void reset();

}	// End Itemizer
