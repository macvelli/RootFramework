/*
 * ParamStrBuilder.java
 * 
 * Last Modified: 04/28/2016
 */
package root.lang;

import java.io.IOException;

import root.util.Fast;
import root.util.Safe;

/**
 * TODO: Need to add insert(), indexOf(), lastIndexOf(), etc methods from StringBuilder
 * TODO: Should I make class final just like StringBuilder or just the methods?
 * TODO: Need to make primitive Extractable implementations to improve over JDK sorry ass implementation
 * TODO: This still has a looooong way to go before it's ready
 * 
 * @author Edward Smith
 * @version 1.0
 */
public class ParamStrBuilder implements Characters {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int size;
	private char[] chars;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ParamStrBuilder() {
		this.chars = new char[64];
	}

	public ParamStrBuilder(final int capacity) {
		this.chars = new char[capacity];
	}

	public ParamStrBuilder(final String s) {
		this.size = s.length();
		this.chars = new char[size + 16];
		s.getChars(0, size, chars, 0);
	}

	public ParamStrBuilder(final CharSequence s) {
		this.size = s.length();
		this.chars = new char[size + 16];
		for (int i=0; i < size; i++) {
			chars[i] = s.charAt(i);
		}
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final ParamStrBuilder append(final boolean b) {
		return b ? append('t','r','u','e') : append('f','a','l','s','e');
	}

	@Override
	public final ParamStrBuilder append(final byte[] b) {
		append('[');
		if (b != null) {
			final int start = size;
			for (int i=0; i < b.length; i++) {
				separator(start).append(b[i]);
			}
		}
		return append(']');
	}

	/**
	 * TODO: Optimize!
	 * 
	 * @param d
	 * @return
	 */
	@Override
	public final ParamStrBuilder append(final double d) {
		return append(Double.toString(d));
	}

	/**
	 * TODO: Optimize!
	 * 
	 * @param f
	 * @return
	 */
	@Override
	public final ParamStrBuilder append(final float f) {
		return append(Float.toString(f));
	}

	@Override
	public final ParamStrBuilder append(final int i) {
		Fast.extract(this, i);
		return this;
	}

	/**
	 * TODO: Optimize!
	 * 
	 * @param l
	 * @return
	 */
	@Override
	public final ParamStrBuilder append(final long l) {
		return append(Long.toString(l, 10));
	}

	@Override
	public final ParamStrBuilder append(final char c) {
		if (size == chars.length) {
			resize(size << 1);
		}

		chars[size++] = c;
		return this;
	}

	@Override
	public final ParamStrBuilder append(final char... str) {
		return append(str, 0, str.length);
	}

	@Override
	public final ParamStrBuilder append(final char[] str, final int offset, final int count) {
		final int newSize = size + count;

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		System.arraycopy(str, offset, chars, size, count);
		size = newSize;

		return this;
	}

	@Override
	public final ParamStrBuilder append(final CharSequence s) throws IOException {
//		TODO: Fix this shit
//		final int newSize = size + s.length();
//
//		if (newSize > chars.length) {
//			resize(newSize << 1);
//		}
//
//		s.getChars(0, s.length(), chars, size);
//		size = newSize;

		return this;
	}

	@Override
	public final ParamStrBuilder append(final CharSequence csq, final int start, final int end) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final ParamStrBuilder append(final Extractable<Characters> e) {
		if (e != null) {
			e.extract(this);
		}

		return this;
	}

	@Override
	public final ParamStrBuilder append(final Extractable<Characters>[] array, final int offset, final int count) {
		if (array == null || array.length == 0) {
			return append(Characters.emptyArray, 0, Characters.emptyArray.length);
		}

		final int endpoint = offset + count;
		Extractable<Characters> e;

		append('[');
		for (int i = offset; i < endpoint; i++) {
			if (i > offset) {
				append(Characters.separator, 0, Characters.separator.length);
			}

			e = array[i];
			if (e != null) {
				e.extract(this);
			}
		}
		append(']');

		return this;
	}

	@Override
	public final Characters append(final Object o) {
		return append(Safe.toString(o));
	}

	@Override
	public final Characters append(final Object[] array, final int offset, final int count) {
		if (array == null || array.length == 0) {
			return append(Characters.emptyArray, 0, Characters.emptyArray.length);
		}

		final int endpoint = offset + count;

		append('[');
		for (int i = offset; i < endpoint; i++) {
			if (i > offset) {
				append(Characters.separator, 0, Characters.separator.length);
			}

			append(Safe.toString(array[i]));
		}
		append(']');

		return this;
	}

	public final ParamStrBuilder append(final ParamStr p, final Object... objs) {
		final String[] strs = new String[objs.length];
		int newSize = size;
		for (int i=0; i < objs.length; i++) {
			strs[i] = objs[i].toString();
			newSize += strs[i].length();
		}

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}
		size = newSize;

		char[] z;
		String s;
		int i = 0, destPos = 0;
		while (true) {
			z = p.segs[i];
			System.arraycopy(z, 0, chars, destPos, z.length);
			destPos += z.length;

			if (i == objs.length) {
				return this;
			}

			s = strs[i++];
			s.getChars(0, s.length(), chars, destPos);
			destPos += s.length();
		}
	}

	@Override
	public ParamStrBuilder append(final String s) {
		final int newSize = size + s.length();

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		s.getChars(0, s.length(), chars, size);
		size = newSize;

		return this;
	}

	public void append(final String msg, final Object... params) {
		final char[] m = msg.toCharArray();
		final String[] strs = Safe.valueOf(params);
		final int newSize = size + (m.length - params.length - (params.length << 1) + Safe.length(strs));

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		int i = 0, j = 0, srcPos = 0, destPos = size, len;
		while (true) {
			if (m[i++] == '{' && m[i] == 'P' && m[++i] == '}') {
				len = i - srcPos - 2;
				System.arraycopy(m, srcPos, chars, destPos, len);
				destPos += len;
				strs[j].getChars(0, strs[j].length(), chars, destPos);
				destPos += strs[j++].length();
				srcPos = ++i;
				if (j == params.length) {
					System.arraycopy(m, srcPos, chars, destPos, m.length - srcPos);
					size = newSize;
					return;
				}
			}
		}
	}

	@Override
	public final ParamStrBuilder append(final StringBuffer strBuf) {
		final int newSize = size + strBuf.length();

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		strBuf.getChars(0, strBuf.length(), chars, size);
		size = newSize;

		return this;
	}

	@Override
	public final ParamStrBuilder append(final StringBuilder builder) {
		final int newSize = size + builder.length();

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		builder.getChars(0, builder.length(), chars, size);
		size = newSize;

		return this;
	}

	@Override
	public final char charAt(final int index) {
		return chars[index];
	}

	@Override
	public final void clear() {
		size = 0;
	}

	public final ParamStrBuilder delete(final int start, final int end) {
		final int len = end-start;

		if (len > 0) {
			System.arraycopy(chars, end, chars, start, size-end);
			size -= len;
		}

		return this;
	}

	public final ParamStrBuilder deleteCharAt(final int index) {
		System.arraycopy(chars, index+1, chars, index, size-index-1);
		size--;
		return this;
	}

	@Override
	public final int getCapacity() {
		return chars.length;
	}

	/**
	 * TODO: Is this really a good idea?
	 */
	@Override
	public char[] getChars(final int numCharsToAdd) {
		final int newSize = size + numCharsToAdd;

		if (newSize > chars.length) {
			// TODO: I think this is too much to increase, adjust
			resize(newSize << 1);
		}

		size = newSize;

		return chars;
	}

	@Override
	public final void setCharAt(final int index, final char c) {
		chars[index] = c;
	}

	@Override
	public final int getLength() {
		return size;
	}

	@Override
	public void setLength(final int len) {
		this.size = len;
	}

	@Override
	public int length() {
		return size;
	}

	public final ParamStrBuilder replace(final int start, final int end, final String str) {
		final int len = end-start;

		if (len > 0) {
			final int newSize = size + str.length() - len;
			if (newSize > chars.length) {
				// TODO: I think this is too much to increase, adjust
				final char[] c = new char[newSize << 1];
				System.arraycopy(chars, 0, c, 0, start);
				str.getChars(0, str.length(), c, start);
				System.arraycopy(chars, end, c, start+str.length(), size-end);
				chars = c;
			} else {
				System.arraycopy(chars, end, chars, start+str.length(), size-end);
				str.getChars(0, str.length(), chars, start);
			}
			size = newSize;
		}

		return this;
	}

	public final ParamStrBuilder reverse() {
		final int h = size >> 1;
		int s = 0, e = size;
		char c;

		while (s < h) {
			c = chars[--e];
			chars[e] = chars[s];
			chars[s++] = c;
		}

		return this;
	}

	@Override
	public final Characters separator(int start) {
		if (size > start) {
			append(separator);
		}

		return this;
	}

	@Override
	public final String subSequence(final int start, final int end) {
		return new String(chars, start, end-start);
	}

	public final String substring(final int start) {
		return new String(chars, start, size);
	}

	public final String substring(final int start, final int end) {
		return new String(chars, start, end-start);
	}

	@Override
	public final String toString() {
		// TODO: Make this Fast!
		return new String(chars, 0, size);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private void resize(final int capacity) {
		final char[] c = new char[capacity];
		System.arraycopy(chars, 0, c, 0, size);
		chars = c;
	}

	public static void main(String[] args) {
		ParamStrBuilder builder = new ParamStrBuilder("FooBarABCXYZ123");
//		builder.replace(3, 6, "WhooHoo!!!");
//		builder.delete(3, 6);
		builder.reverse();
		System.out.println(builder);
	}

}	// End ParamStrBuilder
