package root.lang;

/**
 * Every class which implements the {@link Affiliate} interface standardizes
 * on a single method definition that allows one object to be associated
 * with another in any given relationship.
 * <p>
 * In a 1-N relationship, the class defining the N side of the relationship
 * is an affiliate of the class defining the 1 side.
 *
 * @author Ed Smith
 *
 * @param <E> The type to affiliate with the implementor of this interface.
 */
public interface Affiliate<E> {

	public void associate(E o);

}	// End Affiliate
