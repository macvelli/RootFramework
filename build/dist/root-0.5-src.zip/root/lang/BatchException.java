package root.lang;

import java.util.Iterator;

import root.data.structure.ListArray;

// TODO: Generally this is not a good way performance-wise to batch up validation errors and then report them.  Find another way a la ValidationErrors in Stripes
public class BatchException extends Exception implements Iterable<Throwable> {

	private static final long serialVersionUID = 4011098842854477382L;

	private final ListArray<Throwable> exceptions;

	public BatchException() {
		exceptions = new ListArray<Throwable>();
	}

	public void add(final Throwable t) {
		exceptions.add(t);
	}

	public void checkThrow() throws BatchException {
		if (exceptions.getSize() > 0)
			throw this;
	}

	@Override public String getMessage() {
		final StringBuilder builder = new StringBuilder();

		for (Throwable t : exceptions) {
			if (builder.length() > 0)
				builder.append('\n');
			builder.append(t.getMessage());
		}

		return builder.toString();
	}

	public Iterator<Throwable> iterator() {
		return exceptions.iterator();
	}

}	// End BatchException
