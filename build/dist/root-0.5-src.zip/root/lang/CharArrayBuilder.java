/*
 * CharArrayBuilder.java
 * 
 * Last Modified: 04/28/2016
 */
package root.lang;

import java.io.IOException;

/**
 * Supports either building the char[] array outside and appending it or
 * getting the char[] array and working with it as needed.
 * 
 * TODO: Is this really needed since ParamStrBuilder does all the same crap?
 * TODO: I don't like this implementation because you have to do System.arraycopy() every time you change something
 * TODO: I think the original intent of this class was to give the client of this class one shot at creating a char[] that will store all of the character data for it's toString() or extract() method
 * 
 * @author Edward Smith
 * @version 1.0
 */
public final class CharArrayBuilder implements Characters {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private char[] chars = Characters.empty;

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final Characters append(final boolean b) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final byte[] b) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final char c) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final char... chars) {
		final char[] c = new char[this.chars.length+chars.length];
		System.arraycopy(this.chars, 0, c, 0, this.chars.length);
		System.arraycopy(chars, 0, this.chars, this.chars.length, chars.length);
		this.chars = c;

		return this;
	}

	@Override
	public final Characters append(final char[] str, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final double d) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final float f) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final int i) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final long l) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Appendable append(final CharSequence csq) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final Extractable<Characters> e) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final Extractable<Characters>[] e, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final Object o) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final Object[] objs, final int offset, final int count) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final StringBuffer strBuf) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final StringBuilder builder) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final Characters append(final String str) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final char charAt(final int index) {
		return chars[index];
	}

	@Override
	public final void clear() {
		chars = Characters.empty;
	}

	@Override
	public final int getCapacity() {
		return chars.length;
	}

	@Override
	public final char[] getChars(final int numCharsToAdd) {
		final char[] c = new char[chars.length+numCharsToAdd];
		System.arraycopy(chars, 0, c, 0, chars.length);
		chars = c;

		return chars;
	}

	@Override
	public final int getLength() {
		return chars.length;
	}

	@Override
	public final int length() {
		return chars.length;
	}

	@Override
	public final Characters separator(final int start) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final void setCharAt(final int index, final char c) {
		chars[index] = c;
	}

	@Override
	public final void setLength(final int len) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final CharSequence subSequence(final int start, final int end) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final String toString() {
		// TODO: Make this Fast!
		return new String(chars, 0, chars.length);
	}

}	// End CharArrayBuilder
