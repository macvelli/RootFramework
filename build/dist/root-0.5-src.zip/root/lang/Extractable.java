/*
 * Extractable.java
 * 
 * Last Modified: 04/10/2016
 */
package root.lang;

/**
 * TODO: Make every possible data class, collection class, etc implement this method
 * TODO: Ok so I have proven that checking for instanceof Extractor on an Object is not cost-effective..but what about having an ExtractableList that only takes objects that implement Extractable?
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <C>
 */
public interface Extractable<C extends Characters> {

	void extract(C c);

}	// End Extractable
