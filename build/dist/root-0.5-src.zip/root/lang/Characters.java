/*
 * Characters.java
 * 
 * Last Modified: 04/28/2016
 */
package root.lang;

/**
 * TODO: Come up with Iterable solution that covers all of root.data.structure and java.util collections
 * 
 * @author Edward Smith
 * @version 1.0
 */
public interface Characters extends Appendable, CharSequence {

	// <><><><><><><><><><><><><><><>< Constants <><><><><><><><><><><><><><><>

	public static final String NULL_STRING = "null";

	public static final char[] separator = {',',' '};

	public static final char[] digits = {'0','1','2','3','4','5','6','7','8','9'};

	public static final char[] digitOnes = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        };

	public static final char[] digitTens = {
        '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
        '1', '1', '1', '1', '1', '1', '1', '1', '1', '1',
        '2', '2', '2', '2', '2', '2', '2', '2', '2', '2',
        '3', '3', '3', '3', '3', '3', '3', '3', '3', '3',
        '4', '4', '4', '4', '4', '4', '4', '4', '4', '4',
        '5', '5', '5', '5', '5', '5', '5', '5', '5', '5',
        '6', '6', '6', '6', '6', '6', '6', '6', '6', '6',
        '7', '7', '7', '7', '7', '7', '7', '7', '7', '7',
        '8', '8', '8', '8', '8', '8', '8', '8', '8', '8',
        '9', '9', '9', '9', '9', '9', '9', '9', '9', '9',
        };

	// TODO: Should I delete this crap? Actually this needs to be renamed so that it doesn't confuse with emptyArray
	public static final char[] empty = {};

	public static final char[] emptyArray = {'[',']'};

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	Characters append(boolean b);

	Characters append(byte[] b);

	Characters append(double d);

	Characters append(float f);

	Characters append(int i);

	Characters append(long l);

	Characters append(char c);

	Characters append(char... str);

	Characters append(char[] str, int offset, int count);

	Characters append(Extractable<Characters> e);

	Characters append(Extractable<Characters>[] array, int offset, int count);

	Characters append(Object o);

	Characters append(Object[] array, int offset, int count);

	Characters append(String str);

	Characters append(StringBuffer strBuf);

	Characters append(StringBuilder builder);

	void clear();

	int getCapacity();

	char[] getChars(int numCharsToAdd);

	void setCharAt(int index, char c);

	int getLength();

	void setLength(int len);

	Characters separator(int start);

}	// End Characters
