/*
 * Itemizable.java
 */
package root.lang;

import java.util.Collection;

/**
 * Extends the {@link Iterable} interface to incorporate the {@link Itemizer}
 * concept. The <code>iterator()</code> method returns an {@link Itemizer} as
 * well as a new method that traverses items in descending order.
 * 
 * TODO: Shouldn't I also define a getAscending() method to be feature-complete?
 * TODO: This needs some rework...what belongs? what goes? should I extend Collection<T>?
 * 
 * @author Edward Smith
 * @version 0.5
 * 
 * @param <T>
 */
public interface Itemizable<T> extends Iterable<T> {

	// TODO: Don't think this needs to be here
	void clear();

	// TODO I think this method can go away when all Itemizable classes implement the Java Collections API
	Collection<T> getCollection();

	// TODO: Review whether a descending Itemizer should return a valid value on a getIndex() call or should it always throw UnsupportedOperationException?
	Itemizer<T> getDescending();

	int getSize();

	boolean isEmpty();

	Itemizer<T> iterator();

}	// End Itemizable
