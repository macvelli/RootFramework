/*
 * ConcurrentIterator.java
 * 
 * Last Modified: 03/12/2016
 */
package root.lang;

import java.util.Iterator;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <T>
 */
public interface ConcurrentIterator<T> extends Iterator<T> {

	public void lock();

	public void unlock();

}	// End ConcurrentIterator
