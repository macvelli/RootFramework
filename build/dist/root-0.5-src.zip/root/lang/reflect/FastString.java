package root.lang.reflect;


// TODO: What to do about the damn offset and count crap in String?
// TODO: Fast.toString(char[]), Fast.toString(char[], int len), Fast.toString(char[], int offset, int len)
public class FastString {

	private static final ObjectField<String, char[]> valueField = new ObjectField<String, char[]>(String.class, "value");

	public static final char[] getChars(final String s) {
		return valueField.get(s);
	}

	private String str;

	public FastString(final String str) {
		this.str = str;
	}

	public final char[] getChars() {
		return valueField.get(str);
	}

	public final void setChars(final char[] chars) {
		valueField.set(str, chars);
	}

	@Override
	public String toString() {
		return str;
	}

	public static void main(String[] args) throws Exception {
		FastString fast = new FastString("Foo");

		System.out.println(fast);
		char[] c = fast.getChars();
		c[0] = 'B';
		c[1] = 'a';
		c[2] = 'r';
		System.out.println(fast);
		char[] test = new char[] { 'L', 'O', 'L', '!' };
		fast.setChars(test);
		System.out.println(fast);
	}

}	// End FastString
