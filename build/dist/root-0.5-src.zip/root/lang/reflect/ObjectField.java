package root.lang.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

import sun.misc.Unsafe;

public class ObjectField<C, F> {

	private static final Unsafe unsafe = getUnsafe();

	private final long offset;

	public ObjectField(final Class<?> clazz, final String fieldName) {
		try {
			final Field f = clazz.getDeclaredField(fieldName);

			if (Modifier.isStatic(f.getModifiers())) {
				throw new RuntimeException("FastField does not support static fields");
			}

			offset = unsafe.objectFieldOffset(f);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings("unchecked")
	public F get(final C c) {
		return (F) unsafe.getObject(c, offset);
	}

	public void set(final C c, final F value) {
		unsafe.putObject(c, offset, value);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static Unsafe getUnsafe() {
		try {
			Field field = Unsafe.class.getDeclaredField("theUnsafe");
			field.setAccessible(true);
			return (Unsafe) field.get(null);
		} catch (Exception ex) {
			throw new RuntimeException("Cannot get Unsafe instance", ex);
		}
	}

	public static void main(String[] args) {
		final int numTries = 20;
		long[] test1 = new long[numTries];
		long[] test2 = new long[numTries];
		long start;
		String foo = "Foo";
		ObjectField<String, char[]> value = new ObjectField<String, char[]>(String.class, "value");

		int j;
		for (int i=0; i < numTries; i++) {
			start = System.nanoTime();
			for (j=0; j < 10000000; j++) {
				value.get(foo);
			}
			test1[i] = System.nanoTime()-start;
	
			start = System.nanoTime();
			for (j=0; j < 10000000; j++) {
				foo.toCharArray();
			}
			test2[i] = System.nanoTime()-start;
		}

		System.out.println(Arrays.toString(test1));
		System.out.println(Arrays.toString(test2));
		// TODO: Now can do summations, averages, min/max, and aggregate percentage ratio comparisons 
	}

}	// End FastField
