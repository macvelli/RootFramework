package root.lang.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;

public class TestInteger {

	public static void main(String[] args) throws Exception {
		Integer value = Integer.valueOf(141241);

		Method getChars = Integer.class.getDeclaredMethod("getChars", int.class, int.class, char[].class);
		getChars.setAccessible(true);

		Constructor<String> c = String.class.getDeclaredConstructor(int.class, int.class, char[].class);
		c.setAccessible(true);

		ObjectField<String, char[]> valueField = new ObjectField<String, char[]>(String.class, "value");
		PrimitiveField<String> length = new PrimitiveField<String>(String.class, "count");
		String num = null;

		final int numTries = 10;
		long[] test1 = new long[numTries];
		long[] test2 = new long[numTries];
		long start;

		int j;
		for (int i=0; i < numTries; i++) {
			start = System.nanoTime();
			for (j=0; j < 10000000; j++) {
		        char[] buf = new char[6];
		        getChars.invoke(null, value, 6, buf);
//		        num = new String();
//		        valueField.set(num, buf);
//		        length.setInt(num, 6);			// TODO: It appears faster to create a String with its default constructor and reflectively set the fields vs. reflectively calling its package private constructor 
//		        c.newInstance(0, 6, buf);		// TODO: Damn reflection method calls are SLOOOOOOW...I'm only doing half of what Integer.toString() does and I'm still slower
			}
			test1[i] = System.nanoTime()-start;

			start = System.nanoTime();
			for (j=0; j < 10000000; j++) {
				value.toString();
			}
			test2[i] = System.nanoTime()-start;
		}

		System.out.println(Arrays.toString(test1));
		System.out.println(Arrays.toString(test2));
		// TODO: Now can do summations, averages, min/max, and aggregate percentage ratio comparisons
		System.out.println(num);
	}

}	// End TestInteger
