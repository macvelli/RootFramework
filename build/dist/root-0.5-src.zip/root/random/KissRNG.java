/*
 * KissRNG.java
 * 
 * Last Modified: 02/24/2016
 */
package root.random;

/**
 * The KISS (Keep It Simple Stupid) random number generator by George
 * Marsaglia. This is the version posted by George Marsaglia to
 * comp.lang.fortran on Jun 23 2007. Combines:
 * 
 * <ol>
 *   <li>Simple additive generator x(n)=x(n-1)+545925293</li>
 *   <li>A 3-shift XOR-Shift generator</li>
 *   <li>A basic Add-With-Carry generator</li>
 * </ol>
 * 
 * The output will be a sequence of 32-bit integers with period greater than
 * 2^121 or 10^36. 
 * 
 * @author esmith
 * @version KISS07
 */
public final class KissRNG implements RNG {

	private int x;
	private int y;
	private int z;
	private int w;
	private int c;

	private final Seed seed;

	public KissRNG() {
		this(new SecureRandomSeedFactory());
	}

	public KissRNG(final SeedFactory seedFactory) {
		seed = seedFactory.create(17);

		x = seed.getInt(0);
		y = seed.getInt(4);
		if (y == 0) y++;
		z = seed.getInt(8) >>> 1;
		w = seed.getInt(12) >>> 1;
		c = seed.getByte(16) >>> 7;
	}

	public byte[] getSeed() {
		return seed.getBytes();
	}

	public boolean nextBoolean() {
		return nextInt() < 0;
	}

	public byte[] nextBytes(final byte[] bytes) {
		final int numBytes = bytes.length;
		int rndInt, i=0, j=0;

		while (true) {
			rndInt = nextInt();
			for (j += 4; i < j; rndInt >>>= 8) {
				bytes[i++] = (byte) rndInt;
				if (i == numBytes) {
					return bytes;
				}
			}
		}
	}

	public double nextDouble() {
		return (((((long)nextInt()) << 32) | nextInt()) >>> 11) / 9007199254740992.0d;
	}

	public float nextFloat() {
        return (nextInt() >>> 8) / 0x1000000f;
	}

	public int nextIndex(final int size) {
		// TODO: Which is faster? nextInt() & 0x7FFFFFFF or nextInt() >>> 1?
		return (nextInt() & 0x7FFFFFFF) % size;
	}

	public int nextInt() {
		// Simple Additive Generator
		x += 545925293; 

		// Three-pass XOR-Shift Generator
		y ^= (y << 13);
		y ^= (y >>> 17);
		y ^= (y << 5);

		// Add-With-Carry Generator
		final int t = z + w + c;
		z = w;
		c = (t >>> 31);
		// TODO: Which is faster? t & 0x7FFFFFFF or t >>> 1?
		w = (t & 0x7FFFFFFF); 

		return x + y + w;
	}

	public long nextLong() {
		return (((long)nextInt()) << 32) | nextInt();
	}

	public int nextRange(final int from, final int to) {
		// TODO: Which is faster? nextInt() & 0x7FFFFFFF or nextInt() >>> 1?
		return ((nextInt() & 0x7FFFFFFF) % (to-from)) + from;
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static void main(String[] args) {
		long start, end;

		KissRNG kiss = new KissRNG();
		start = System.nanoTime();
		for (int i=0; i < 100000000; i++) {
			kiss.nextInt();
		}
		end = System.nanoTime();

		System.out.println(end-start);

//		Random rand = new Random();
//		start = System.nanoTime();
//		for (int i=0; i < 100000000; i++) {
//			rand.nextInt();
//		}
//		end = System.nanoTime();
//
//		System.out.println(end-start);
	}

}	// End KissRNG
