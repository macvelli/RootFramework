package root.random;

import java.security.SecureRandom;

public class SecureRandomSeedFactory implements SeedFactory {

	private static final SecureRandom seedSource = new SecureRandom();

	public Seed create(final int numBytes) {
		return new Seed(seedSource.generateSeed(numBytes));
	}

}	// End SecureRandomSeedFactory
