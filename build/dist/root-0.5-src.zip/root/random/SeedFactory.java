package root.random;

public interface SeedFactory {

	public Seed create(int numBytes);

}	// End SeedFactory
