package root.util;

import root.lang.ParamStr;
import root.util.Properties;

// TODO: This class could really benefit from a CompiledParamStr class that precompiles the message ahead of time and stored those instead of the raw Properties
public class Messages {

	private final Properties messages;

	public Messages(final String... resources) {
		messages = new Properties(resources);
	}

	public String get(final String key) {
		final String msg = messages.get(key);

		return (msg == null) ? key : msg;
	}

	public String get(final String key, final Object... params) {
		return ParamStr.format(messages.get(key), params);
	}

	@Override public String toString() {
		return messages.toString();
	}

}	// End Messages
