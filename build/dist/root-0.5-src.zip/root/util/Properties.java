package root.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;

// TODO: Right now this is just a wrapper around java.util.Properties but this thing really needs to be completely rewritten -- just look at the implementation from the JDK for evidence
public class Properties {

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Static Artifacts ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static final InputStream getInputStream(String resource) {
		// Check to see if the resource is actually an env variable
		if (System.getenv(resource) != null)
			resource = System.getenv(resource);

		URL url = Properties.class.getResource(resource);

		if (url == null)
			url = ClassLoader.getSystemResource(resource);

		try {
			return new BufferedInputStream((url == null) ? new FileInputStream(resource) : url.openStream());
		} catch (IOException e) {
			return null;
		}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~ End Static Artifacts ~~~~~~~~~~~~~~~~~~~~~~~~~~

	protected final java.util.Properties properties;

	public Properties(final String... resources) {
		properties = new java.util.Properties();

		InputStream in = null;
		for (String r : resources) {
			try {
				in = Properties.getInputStream(r);
				if (in != null)
					properties.load(in);
			} catch (IOException e) {
				throw new RuntimeException("An error occurred when attempting to load " + r, e);
			} finally {
				Safe.close(in);
			}
		}
	}

	public void clear() {
		properties.clear();
	}

	public boolean contains(final String value) {
		return properties.contains(value);
	}

	public boolean containsKey(final String key) {
		return properties.containsKey(key);
	}

	public String get(final String key) {
		return properties.getProperty(key);
	}

	public String get(final String key, final String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

	public int getInt(final String key) {
		final String i = properties.getProperty(key);

		return (i != null) ? Integer.valueOf(i) : 0;
	}

	public void set(final String key, final String value) {
		properties.setProperty(key, value);
	}

	public String remove(final String key) {
		return (String) properties.remove(key);
	}

	@Override public String toString() {
		final StringWriter writer = new StringWriter();

		properties.list(new PrintWriter(writer));

		return writer.toString();
	}

	public static void main(String[] args) {
		final Properties props = new Properties("/Server/server.properties");

		System.out.println(props);
	}

}	// End Properties
