/*
 * Clean.java
 */
package root.util;


/**
 * TODO: Put any and all @SuppressWarnings stuff in here
 * 
 * @author Edward Smith
 * @version 0.5
 */
public final class Clean {

	/**
	 * TODO: Document!
	 * 
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T cast(final Object obj) {
		return (T) obj;
	}

	/**
	 * TODO: Document!
	 * 
	 * @param size
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T[] newArray(final int size) {
		return (T[]) new Object[size];
	}

	/**
	 * TODO: Document!
	 * 
	 * @param array
	 * @param size
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T[] newArray(final T[] array, final int size) {
		if (array == null) {
			return (T[]) new Object[size];
		}

		if (array.length >= size) {
			// Null out the rest of the array if array.length > size
			for (int i = size; i < array.length; i++) {
				array[i] = null;
			}

			return array;
		}

		return (T[]) java.lang.reflect.Array.newInstance(array.getClass()
				.getComponentType(), size);
	}

	/**
	 * TODO: Document!
	 * 
	 * @param size
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T[][] newArrayTwoDimensional(
			final int firstDimensionSize) {
		return (T[][]) new Object[firstDimensionSize][];
	}

	/**
	 * TODO: Document!
	 * 
	 * @param clazz
	 * @return
	 */
	public static final <T> T newInstance(final Class<T> clazz) {
		try {
			return clazz.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

} // End Clean
