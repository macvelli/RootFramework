package root.util;

import java.util.concurrent.locks.ReentrantLock;

import root.random.SecureRandomSeedFactory;
import root.random.Seed;

public final class Random {

	private static int x;
	private static int y;
	private static int z;
	private static int w;
	private static int c;

	private static final Seed seed = new SecureRandomSeedFactory().create(17);
	private static final ReentrantLock lock = new ReentrantLock();

	static {
		x = seed.getInt(0);
		y = seed.getInt(4);
		if (y == 0) y++;
		z = seed.getInt(8) >>> 1;
		w = seed.getInt(12) >>> 1;
		c = seed.getByte(16) >>> 7;
	}

	private Random() {}

	public static byte[] getSeed() {
		return seed.getBytes();
	}

	public static boolean nextBoolean() {
		return nextInt() < 0;
	}

	public static byte[] nextBytes(final byte[] bytes) {
		final int numBytes = bytes.length;
		int rndInt, i=0, j=0;

		while (true) {
			rndInt = nextInt();
			for (j += 4; i < j; rndInt >>>= 8) {
				bytes[i++] = (byte) rndInt;
				if (i == numBytes) {
					return bytes;
				}
			}
		}
	}

	public static double nextDouble() {
		return (((((long)nextInt()) << 32) | nextInt()) >>> 11) / 9007199254740992.0d;
	}

	public static float nextFloat() {
		return (nextInt() >>> 8) / 0x1000000f;
	}

	public static int nextIndex(final int size) {
		return (nextInt() & 0x7FFFFFFF) % size;
	}

	public static int nextInt() {
		lock.lock();

		// Simple Additive Generator
		x += 545925293; 

		// Three-pass XOR-Shift Generator
		y ^= (y << 13);
		y ^= (y >>> 17);
		y ^= (y << 5);

		// Add-With-Carry Generator
		final int t = z + w + c;
		z = w;
		c = (t >>> 31);
		w = (t & 0x7FFFFFFF); 

		try {
			return x + y + w;
		} finally {
			lock.unlock();
		}
	}

	public static long nextLong() {
		return (((long)nextInt()) << 32) | nextInt();
	}

	public static int nextRange(final int from, final int to) {
		return ((nextInt() & 0x7FFFFFFF) % (to-from)) + from;
	}

}	// End Random
