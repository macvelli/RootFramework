package root.util;

import java.util.Collection;
import java.util.Iterator;

public class WorkUnit implements Iterable<Object[]>, Iterator<Object[]> {

	private int i, j;

	private final int		unitSize;
	private final Object[]	work;

	public WorkUnit(final Collection<?> c, final int unitSize) {
		work = c.toArray(new Object[c.size()]);
		this.unitSize = unitSize;
	}

	public Iterator<Object[]> iterator() {
		return this;
	}

	public boolean hasNext() {
		return j < work.length;
	}

	public Object[] next() {
		i = j;
		j += unitSize;
		if (j > work.length)
			j = work.length;

		int size = j - i;
		Object[] unit = new Object[size];
		System.arraycopy(work, i, unit, 0, size);

		return unit;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

}	// End WorkUnit
