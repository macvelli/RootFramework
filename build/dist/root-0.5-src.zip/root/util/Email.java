package root.util;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {

	private static Session session;

	private final MimeMessage	message;

	private final StringBuilder	text;

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Static Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static void setSMTPHost(final String hostName) {
		final Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", hostName);
		session = Session.getDefaultInstance(props);
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Instance Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public Email(final String subject) throws Exception {
		message = new MimeMessage(session);
		message.setSubject(subject);
		text = new StringBuilder(8192);
	}

	public StringBuilder append(final String text) {
		return this.text.append(text);
	}

	public void from(final String name, final String address) throws Exception {
		message.setFrom(new InternetAddress(address, name));
	}

	public void send() throws Exception {
		message.setText(text.toString());
		Transport.send(message);
	}

	public void to(final String name, final String address) throws Exception {
		message.addRecipient(RecipientType.TO, new InternetAddress(address, name));
	}

	public void to(final Address... addresses) throws Exception {
		message.addRecipients(RecipientType.TO, addresses);
	}

}	// End Email
