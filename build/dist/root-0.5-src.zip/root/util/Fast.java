package root.util;

import root.clock.Timer;
import root.lang.Characters;
import root.lang.ParamStrBuilder;

/**
 * 
 * @author esmith
 */
@SuppressWarnings("unchecked")
public final class Fast {

	/**
	 * Returns the <code>int[]</code> parameter with each <code>int</code>
	 * converted to its absolute value.
	 * 
	 * @param ints The <code>int[]</code> of values.
	 * @return the <code>int[]</code> absolute values.
	 */
	public static int[] abs(final int... ints) {
		int j=0;

		for (int i : ints) {
			if (i < 0) {
				ints[j] = -i;
			}
			j++;
		}

		return ints;
	}

	/**
	 * Returns <code>a</code> divided by <code>b</code> as a <code>double</code>.
	 * 
	 * @param a the numerator
	 * @param b the denominator
	 * @return <code>a</code> divided by <code>b</code> as a <code>double</code>
	 */
	public static final double divideDouble(final double a, final double b) {
		return a/b;
	}

	/**
	 *  Returns <code>a</code> divided by <code>b</code> as a <code>float</code>.
	 * 
	 * @param a the numerator
	 * @param b the denominator
	 * @return <code>a</code> divided by <code>b</code> as a <code>float</code>
	 */
	public static final float divideFloat(final float a, final float b) {
		return a/b;
	}

	/**
	 * Returns <code>true</code> if the <code>int</code> is an even number,
	 * <code>false</code> if it is odd.
	 * 
	 * @param i The <code>int</code> value.
	 * @return <code>true</code> if the <code>int</code> is an even number.
	 */
	public static boolean even(final int i) {
		return (i & 1) == 0;
	}

	/**
	 * TODO: 20140516 Test this new implementation out.  Combination of
	 * Integer class implementation and the cppformat library's fmt::FormatInt
	 * method found at https://github.com/cppformat/cppformat.
	 * 
	 * TODO: Shouldn't I just move this into ParamStrBuilder?  Where else am I going to use this? And I want people to call builder.append(i) not Fast.extract(builder, i)
	 * 
	 * @param chars
	 * @param i
	 */
	public static final void extract(final Characters chars, int i) {
		if (i == Integer.MIN_VALUE) {
            chars.append('-','2','1','4','7','4','8','3','6','4','8');
            return;
		}

		final int charsSize = chars.getLength();
		int charPos = stringSize(i);
		final char[] buf = chars.getChars(charPos);
		final boolean sign = (i < 0);
		charPos += charsSize;

		i = (sign) ? -i : i;
		int q, r;

		while (i >= 100) {
			q = i / 100;
			r = i - (q << 6) - (q << 5) - (q << 2);
			i = q;
			buf[--charPos] = Characters.digitOnes[r];
			buf[--charPos] = Characters.digitTens[r];
		}

		if (i < 10) {
			buf[--charPos] = Characters.digits[i];
		} else {
			buf[--charPos] = Characters.digitOnes[i];
			buf[--charPos] = Characters.digitTens[i];
		}

		if (sign) {
			buf[--charPos] = '-';
		}
	}

	/**
	 * Returns the size of a hash table based upon the given capacity. For
	 * capacity values under 1274, a predetermined prime number will be
	 * returned with the load factor varying between 41% and 75%.  Capacity
	 * values of 1274 and over will return a hash table size approximating
	 * a 75% load factor.
	 * 
	 * TODO Would it be better if the size was always an odd number?
	 * 
	 * @param capacity The capacity of the hash table.
	 * @return the size of the hash table based upon the given capacity.
	 */
	public static int hashTableSize(final int capacity) {
		if (capacity == 8) return 11;
		if (capacity < 15) return 19;
		if (capacity < 26) return 37;
		if (capacity < 45) return 59;
		if (capacity < 78) return 103;
		if (capacity < 136) return 181;
		if (capacity < 238) return 317;
		if (capacity < 416) return 557;
		if (capacity < 728) return 971;
		if (capacity < 1274) return 1699;

		return capacity + (capacity >> 2) + (capacity >> 4);
	}

	/**
	 * Returns the maximum <code>int</code> value between the two parameters.
	 * 
	 * @param a The first <code>int</code>.
	 * @param b The second <code>int</code>.
	 * @return the maximum <code>int</code> value.
	 */
	public static final int max(final int a, final int b) {
		return (a > b) ? a : b;
	}

	/**
	 * Returns the maximum <code>int</code> value from an <code>int[]</code>
	 * of values.
	 * 
	 * @param ints The <code>int[]</code> of values.
	 * @return the maximum <code>int</code> value.
	 */
	public static int max(final int... ints) {
		int max = Integer.MIN_VALUE;

		for (int i : ints) {
			if (i > max) {
				max = i;
			}
		}

		return max;
	}

	/**
	 * Returns the generic <code>T[]</code> parameter if its size already
	 * equals the size parameter, otherwise reflectively creates and returns
	 * a new generic <code>T[]</code> set to the requested size.
	 * 
	 * TODO: Why is this deprecated? Is there a better way of doing this?
	 *   
	 * @param t The generic <code>T[]</code>.
	 * @param size The requested size.
	 * @return a generic <code>T[]</code> of the requested size.
	 */
	@Deprecated
	public static <T> T[] newInstance(final T[] t, final int size) {
		return (t.length == size) ? t
				: (T[]) java.lang.reflect.Array.newInstance(t.getClass().getComponentType(), size);
	}

	/**
	 * Returns <code>true</code> if the <code>int</code> is an odd number,
	 * <code>false</code> if it is even.
	 * 
	 * @param i The <code>int</code> value.
	 * @return <code>true</code> if the <code>int</code> is an odd number.
	 */
	public static boolean odd(final int i) {
		return (i & 1) == 1;
	}

	/**
	 * This is needed because casting a negative <code>byte</code> value to
	 * an <code>int</code> results in the same negative value.
	 * 
	 * @param b
	 * @return
	 */
	public static int unsignedInt(final byte b) {
		// TODO: unsignedInt(short), unsignedLong(int), what else?
		return b & 0xff;
	}

	/**
	 * Allows variable <code>boolean</code> arguments to be used for any method
	 * parameter, though it would be pointless to use this for the last method
	 * parameter that is already defined as a vararg.
	 * 
	 * @param args The variable number of <code>boolean</code> values.  
	 * @return A <code>boolean[]</code> array containing the values.
	 */
	public static boolean[] varg(final boolean... args) {
		return args;
	}

	/**
	 * Allows variable <code>char</code> arguments to be used for any method
	 * parameter, though it would be pointless to use this for the last method
	 * parameter that is already defined as a vararg.
	 * 
	 * @param args The variable number of <code>char</code> values.  
	 * @return A <code>char[]</code> array containing the values.
	 */
	public static char[] varg(final char... args) {
		return args;
	}

	/**
	 * Allows variable <code>int</code> arguments to be used for any method
	 * parameter, though it would be pointless to use this for the last method
	 * parameter that is already defined as a vararg.
	 * 
	 * @param args The variable number of <code>int</code> values.  
	 * @return An <code>int[]</code> array containing the values.
	 */
	public static int[] varg(final int... args) {
		return args;
	}

	/**
	 * Allows variable generic arguments to be used for any method parameter,
	 * though it would be pointless to use this for the last method parameter
	 * that is already defined as a vararg.
	 * 
	 * @param args The variable number of generic <code>T</code> values.  
	 * @return A generic array <code>T[]</code> containing the values.
	 */
	public static <T> T[] varg(final T... args) {
		return args;
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private static int stringSize(final int i) {
		if (i < 0) {
			if (i > -10) return 2;
			if (i > -100) return 3;
			if (i > -1000) return 4;
			if (i > -10000) return 5;
			if (i > -100000) return 6;
			if (i > -1000000) return 7;
			if (i > -10000000) return 8;
			if (i > -100000000) return 9;
			if (i > -1000000000) return 10;

			return 11;
		}

		if (i < 10) return 1;
		if (i < 100) return 2;
		if (i < 1000) return 3;
		if (i < 10000) return 4;
		if (i < 100000) return 5;
		if (i < 1000000) return 6;
		if (i < 10000000) return 7;
		if (i < 100000000) return 8;
		if (i < 1000000000) return 9;

		return 10;
	}

	/**
	 * TODO: 20140516 Test this new implementation out.  Combination of
	 * Integer class implementation and the cppformat library's fmt::FormatInt
	 * method found at https://github.com/cppformat/cppformat.
	 * 
	 * TODO: Shouldn't I just move this into ParamStrBuilder?  Where else am I going to use this? And I want people to call builder.append(i) not Fast.extract(builder, i)
	 * 
	 * @param chars
	 * @param i
	 */
	public static final void extract(final Characters chars, final float f) {
		if (f == Float.NaN) {
            chars.append('N','a','N');
            return;
		}

		if (f == Float.POSITIVE_INFINITY) {
            chars.append('I','n','f','i','n','i','t','y');
            return;
		}

		if (f == Float.NEGATIVE_INFINITY) {
            chars.append('-','I','n','f','i','n','i','t','y');
            return;
		}

		final int floatBits = Float.floatToRawIntBits(f);
		if (floatBits == 0) {
            chars.append('0','.','0');
            return;
		}

		if (floatBits == 0x80000000) {
            chars.append('-','0','.','0');
            return;
		}

		if (floatBits == 0x4b800000) {
			chars.append('1','6','7','7','7','2','1','6','.','0');
			return;
		}

		if (floatBits == 0xcb800000) {
			chars.append('-','1','6','7','7','7','2','1','6','.','0');
			return;
		}

		final boolean sign = (floatBits & 0x80000000) != 0;
		final int exponent = ((floatBits & 0x7f800000) >> 23) - 127;
		int significand = (floatBits & 0x007fffff) | 0x00800000;

		int fraction=0, numDigitsOfPrecision=8;

		int charPos = chars.getLength();
		final char[] charArr = chars.getChars(15);

		if (exponent >= 0) {
			// We have an integer component to process

			if (exponent < 24) {
				long longSignificand = ((long)significand) << exponent;
				int integer = (int)(longSignificand >> 23);
				fraction = (int)(longSignificand - (((long)integer) << 23));
				int q, r, decimalPos;

				if (sign) {
					charArr[charPos++] = '-';
				}

				decimalPos = charPos + intFormatSize(integer);
				charPos = decimalPos;

				while (integer >= 100) {
					q = integer / 100;
					r = integer - (q << 6) - (q << 5) - (q << 2);
					integer = q;
					charArr[--charPos] = Characters.digitOnes[r];
					charArr[--charPos] = Characters.digitTens[r];
					numDigitsOfPrecision -= 2;
				}

				if (integer < 10) {
					charArr[--charPos] = Characters.digits[integer];
					numDigitsOfPrecision--;
				} else {
					charArr[--charPos] = Characters.digitOnes[integer];
					charArr[--charPos] = Characters.digitTens[integer];
					numDigitsOfPrecision -= 2;
				}

				charPos = decimalPos;
				charArr[charPos++] = '.';

				if (numDigitsOfPrecision == 0 || fraction == 0) {
					charArr[charPos++] = '0';
				} else {
					while (numDigitsOfPrecision >= 2 && fraction > 0) {
						fraction = (fraction << 6) + (fraction << 5) + (fraction << 2);
						q = fraction >> 23;
						fraction -= (q << 23);

						charArr[charPos++] = Characters.digitTens[q];
						charArr[charPos++] = Characters.digitOnes[q];
						numDigitsOfPrecision -= 2;
					}

					if (numDigitsOfPrecision == 1 && fraction > 0) {
						fraction = (fraction << 3) + (fraction << 1);
						q = fraction >> 23;

						charArr[charPos++] = Characters.digits[q];
					}

					if (fraction >= 4194304) {
						// Round half up
						while (charArr[--charPos] == '9');

						charArr[charPos] = (char)(charArr[charPos++] + 1);
					}
				}

//				System.out.println("Integer: " + integer + ", fraction: " + fraction + ", q: " + q + ", r: " + r);
			}
		} else {
			// We are dealing with just the fractional part
			int q;

//			System.out.println("floatBits: " + Integer.toHexString(floatBits) + ", Sign: " + sign + ", exponent: " + exponent + ", significand: " + significand);

			if (exponent >= -15) {
				long longFraction = (long)significand;
				int shift = 23 - exponent;

				if (sign) {
					charArr[charPos++] = '-';
				}

				charArr[charPos++] = '0';
				charArr[charPos++] = '.';

				do {
					longFraction = (longFraction << 6) + (longFraction << 5) + (longFraction << 2);
					q = (int) (longFraction >> shift);
					if (q > 0) {
						longFraction -= (((long)q) << shift);
					}

					charArr[charPos++] = Characters.digitTens[q];
					charArr[charPos++] = Characters.digitOnes[q];
					numDigitsOfPrecision -= 2;
				}	while (numDigitsOfPrecision >= 2 && longFraction > 0);

				if (numDigitsOfPrecision == 1 && longFraction > 0) {
					longFraction = (longFraction << 3) + (longFraction << 1);
					q = (int) (longFraction >> shift);

					charArr[charPos++] = Characters.digits[q];
				}

				if (longFraction >= (1L << (shift - 1))) {
					// Round half up
					while (charArr[--charPos] == '9');

					charArr[charPos] = (char)(charArr[charPos++] + 1);
				}
			}
		}

		chars.setLength(charPos);
	}

	private static int intFormatSize(final int i) {
		if (i < 10) return 1;					// 9
		if (i < 100) return 2;					// 99
		if (i < 1000) return 3;					// 999
		if (i < 10000) return 4;				// 9999
		if (i < 100000) return 5;				// 99999
		if (i < 1000000) return 6;				// 999999
		if (i < 10000000) return 7;				// 9999999

		return 8;								// 99999999
	}

	public static void main(String[] args) {
		// TODO: http://download.oracle.com/javase/tutorial/java/nutsandbolts/datatypes.html
//		String a = "A";
//		String b = "B";
//		String c = "C";

//		String[] sts = {a, b, c};
//		byte[]  byts = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,-128,-127,-126,-125,-124,-123,-122,-121,-120,-119,-118,-117,-116,-115,-114,-113,-112,-111,-110,-109,-108,-107,-106,-105,-104,-103,-102,-101,-100,-99,-98,-97,-96,-95,-94,-93,-92,-91,-90,-89,-88,-87,-86,-85,-84,-83,-82,-81,-80,-79,-78,-77,-76,-75,-74,-73,-72,-71,-70,-69,-68,-67,-66,-65,-64,-63,-62,-61,-60,-59,-58,-57,-56,-55,-54,-53,-52,-51,-50,-49,-48,-47,-46,-45,-44,-43,-42,-41,-40,-39,-38,-37,-36,-35,-34,-33,-32,-31,-30,-29,-28,-27,-26,-25,-24,-23,-22,-21,-20,-19,-18,-17,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1};
//		short[] shts = {4, 5, 6};
//		int[]   ints = {7, 8, 9};
//		byte[] ints = Fast.varg((byte) 1,  (byte) 2, (byte) 3);
//		Arrays.sort(
//		byte bi = (byte) 255;
//		System.out.println(bi);
//		System.out.print(-128);
//		for (int i=127; i > 0; i--) {
//			System.out.print("," + (-i));
//		}
//		System.out.println();
//		System.out.println((int) byts[255]);
//		System.out.println(Fast.unsignedInt(byts[255]));

//		final float f = (Fast.divideFloat(47120, 26099)-1);
//		final float f = 16777216.0f;
//		final float f = 15777216.0f;
//		final float f = 10000000.0f;
//		final float f = 8000000.49f;
//		final float f = 1.0f;
//		final float f = 0.99f;
//		final float f = 0.00045603f;
//		final float f = 0.009999999f;
//		final float f = 0.0001f;
//		final float f = 0.00005f;
//		final float f = 0.000976575f;
//		float f = 0.00099999f;
//
//		ParamStrBuilder builder = new ParamStrBuilder();
//		Fast.extract(builder, f);
//
//		System.out.println(builder);
//		System.out.println(f);
//
//		f = 0.1f;
//		builder.clear();
//		Fast.extract(builder, f);
//
//		System.out.println(builder);
//		System.out.println(f);
//
//		f = 0.00000012f;
//		builder.clear();
//		Fast.extract(builder, f);
//
//		System.out.println(builder);
//		System.out.println(f);
//
//		f = 52.234375f;
//		builder.clear();
//		Fast.extract(builder, f);
//
//		System.out.println(builder);
//		System.out.println(f);
//
//		f = (Fast.divideFloat(47120, 26099)-1);
//		builder.clear();
//		Fast.extract(builder, f);
//
//		System.out.println(builder);
//		System.out.println(f);

//		final float f = (Fast.divideFloat(47120, 26099)-1);
		final float f = 0.00005f;
//		final float f = 8000000.49f;
//
		ParamStrBuilder builder = new ParamStrBuilder();
		Timer t = new Timer();
		for (int i=0; i < 10000000; i++) {
			builder.clear();
			Fast.extract(builder, f);
		}

		System.out.println("Float: " + builder.toString() + ", time: " + t.elapsed());

		t.reset();
		for (int i=0; i < 10000000; i++) {
			builder.clear();
			builder.append(Float.toString(f));
		}

		System.out.println("Float: " + builder.toString() + ", time: " + t.elapsed());
	}

}	// End Fast
