/*
 * Safe.java
 */
package root.util;

import java.io.IOException;
import java.io.InputStream;

import root.lang.Characters;
import root.lang.ParamStrBuilder;

/**
 * TODO: Test the hell out of this class TODO: Might need List<> implementations
 * along with the array[] implementations TODO: Safe.toString(),
 * Safe.close(ResultSet), Safe.close(Statement), etc [good idea to consolidate
 * all safety methods into one class so developers don't have to remember
 * multiple classes]
 * 
 * @author Edward Smith
 * @version 0.5
 */
public final class Safe {

	// <><><><><><><><><><><><><><> Static Methods <><><><><><><><><><><><><><>

	/**
	 * Safely extract a <code>boolean</code> value from a {@link Boolean} object
	 * instance. If the {@link Boolean} instance is <code>null</code>,
	 * <code>false</code> is returned.
	 * 
	 * @param n
	 *            The {@link Boolean} object instance.
	 * @return a <code>boolean</code> value, <code>false</code> if
	 *         <code>null</code>.
	 */
	public static final boolean booleanValue(final Boolean b) {
		return (b != null && b.booleanValue());
	}

	/**
	 * Safely extract a <code>byte</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return a <code>byte</code> value, or zero if <code>null</code>.
	 */
	public static final byte byteValue(final Number n) {
		return (byte) ((n == null) ? 0 : n.intValue());
	}

	/**
	 * Closes an <code>InputStream</code> while catching and rethrowing any
	 * <code>IOException</code>s as <code>RuntimeException</code>s.
	 * 
	 * @param in
	 *            the <code>InputStream</code> to close.
	 */
	public static final void close(final InputStream in) {
		if (in != null) {
			try {
				in.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Returns <code>true</code> if the {@link Object} array contains the
	 * specified {@link Object}, <code>false</code> otherwise.
	 * 
	 * @param array
	 *            The {@link Object} array.
	 * @param obj
	 *            The {@link Object} to find.
	 * @return <code>true</code> if the {@link Object} array contains the
	 *         specified {@link Object}.
	 */
	public static final boolean contains(final Object[] array, final Object obj) {
		// TODO: Do the same for Comparable[], Comparable as well as primitives
		// (see java.util.Arrays)
		if (array != null) {
			for (Object p : array) {
				if (obj == p || (obj != null && obj.equals(p))) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Safely extract a <code>double</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return a <code>double</code> value, or zero if <code>null</code>.
	 */
	public static final double doubleValue(final Number n) {
		return (n == null) ? 0.0d : n.doubleValue();
	}

	/**
	 * Safely determines whether the two objects are equal to one another
	 * according to the semantics of <code>Object.equals()</code> while
	 * gracefully handling <code>null</code> reference values.
	 * 
	 * @param o
	 *            the first object to compare for equality.
	 * @param p
	 *            the second object to company for equality.
	 * @return <code>true</code> if <code>o.equals(p)</code>; <code>false</code>
	 *         otherwise.
	 */
	public static final boolean equals(final Object o, final Object p) {
		return o == p || (o != null && o.equals(p));
	}

	/**
	 * Performs a deep dive to determine whether two arrays are equal to each
	 * another. Both arrays must be the same length and each element is safely
	 * compared according to the semantics of <code>Object.equals()</code> while
	 * gracefully handling <code>null</code> reference values.
	 * 
	 * @param a
	 *            the first array to compare for equality.
	 * @param b
	 *            the second array to company for equality.
	 * @return <code>true</code> if both arrays are the same length and contain
	 *         the same elements in the exact same order; <code>false</code>
	 *         otherwise.
	 */
	public static final boolean equals(final Object[] a, final Object[] b) {
		if (a == b) {
			return true;
		}

		if (a == null || b == null || a.length != b.length) {
			return false;
		}

		Object c, d;
		for (int i = 0; i < a.length; i++) {
			c = a[i];
			d = b[i];

			if (c != d && (c == null || !c.equals(d))) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Safely extract a <code>float</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return a <code>float</code> value, or zero if <code>null</code>.
	 */
	public static final float floatValue(final Number n) {
		return (n == null) ? 0.0f : n.floatValue();
	}

	/**
	 * Defaults <code>null</code> object reference hash code values to zero
	 * while ensuring non-null references always return a positive hash code
	 * value.
	 * 
	 * @param obj
	 *            the object to calculate its hash code.
	 * @return a hash code value greater than or equal to zero for the object.
	 */
	public static final int hashCode(final Object obj) {
		return (obj == null) ? 0 : obj.hashCode() & 0x7FFFFFFF;
	}

	/**
	 * TODO: Document!
	 * 
	 * @param array
	 * @return
	 */
	public static final int hashCode(final Object[] array) {
		if (array == null) {
			return 0;
		}

		int h = array.length;
		for (Object o : array) {
			if (o != null) {
				h ^= o.hashCode();
			}
			h <<= 1;
		}

		return h & 0x7FFFFFFF;
	}

	/**
	 * Performs a deep dive to calculate an <code>Object[]</code> hash code
	 * value. Each array element hash code value is used to calculate the
	 * aggregate hash code value. This method always returns a positive value.
	 * 
	 * @param array
	 *            The {@link Object} array
	 * @param size
	 *            The size of the {@link Object} array
	 * @return a hash code value greater than or equal to zero.
	 */
	public static final int hashCode(final Object[] array, final int size) {
		if (array == null) {
			return 0;
		}

		int h = size;
		for (int i = 0; i < size; i++) {
			if (array[i] != null) {
				h ^= array[i].hashCode();
			}
			h <<= 1;
		}

		return h & 0x7FFFFFFF;
	}

	/**
	 * Safely extract an <code>int</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return an <code>int</code> value, or zero if <code>null</code>.
	 */
	public static final int intValue(final Number n) {
		return (n == null) ? 0 : n.intValue();
	}

	/**
	 * TODO: Document!
	 * 
	 * @param obj
	 * @return
	 */
	public static final boolean isArray(final Object obj) {
		return (obj != null && obj.getClass().isArray());
	}

	/**
	 * Returns <code>true</code> if the specified string is either
	 * <code>null</code> or its length is equal to zero.
	 * 
	 * @param value
	 *            The string to evaluate.
	 * @return <code>true</code> if the string is empty.
	 */
	public static final boolean isEmpty(final String value) {
		return (value == null || value.length() == 0);
	}

	/**
	 * Returns the largest index where the specified fragment is located within
	 * the <code>char[]</code>, or -1 if not found.
	 * 
	 * @param c
	 *            The <code>char[]</code> to search.
	 * @param fgmt
	 *            The fragment to look for.
	 * @return the largest index where the fragment is located, -1 if not found.
	 */
	public static final int lastIndexOf(final char[] c, final char... fgmt) {
		// TODO: Pass in the length of char[] c
		// TODO: Make one of these to just find a single character so that I
		// don't have to slow down this implementation that expects the char
		// fragment length > 1
		if (c != null && fgmt != null && c.length >= fgmt.length) {
			final int end = fgmt.length - 2;
			final char fgmtLastChar = fgmt[end + 1];
			int j, k;

			search: for (int i = c.length - 1; i > end;) {
				if (c[i--] == fgmtLastChar) {
					final int l = i - end;
					for (j = i, k = end; j >= l;) {
						if (c[j--] != fgmt[k--]) {
							continue search;
						}
					}

					return l;
				}
			}
		}

		return -1;
	}

	/**
	 * Returns the largest index where the specified fragment is located within
	 * the {@link String}, or -1 if not found.
	 * 
	 * @param s
	 *            The {@link String} to search.
	 * @param fgmt
	 *            The fragment to look for.
	 * @return the largest index where the fragment is located, -1 if not found.
	 */
	public static final int lastIndexOf(final String s, final String fgmt) {
		return (s == null) ? -1 : s.lastIndexOf(fgmt);
	}

	/**
	 * Safely returns the {@link String} length (zero if <code>null</code>).
	 * 
	 * @param s
	 *            The {@link String}
	 * @return the {@link String} length, or zero if <code>null</code>.
	 */
	public static final int length(final String s) {
		return (s == null) ? 0 : s.length();
	}

	/**
	 * Safely calculates and returns the aggregate length of all {@link String}
	 * instances in the array.
	 * 
	 * @param strs
	 *            the {@link String} array
	 * @return the aggregate length of the {@link String} array.
	 */
	public static final int length(final String... strs) {
		int len = 0;

		if (strs != null) {
			for (String s : strs) {
				if (s != null) {
					len += s.length();
				}
			}
		}

		return len;
	}

	/**
	 * Safely extract a <code>long</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return a <code>long</code> value, or zero if <code>null</code>.
	 */
	public static final long longValue(final Number n) {
		return (n == null) ? 0 : n.longValue();
	}

	/**
	 * Ensures the length of a {@link String} does not exceed the maximum length
	 * value provided as input. A substring is returned equal to the max length
	 * if the {@link String} length is greater than max length.
	 * 
	 * @param str
	 *            The {@link String} to evaluate.
	 * @param maxLen
	 *            The maximum length of the {@link String}.
	 * @return A substring(0, maxLen) if {@link String} length > maxLen
	 */
	public static final String maxLength(final String str, final int maxLen) {
		return (str != null && str.length() > maxLen) ? str
				.substring(0, maxLen) : str;
	}

	/**
	 * Returns <code>true</code> if the <code>char[]</code> is not
	 * <code>null</code> and its length is greater than zero.
	 * 
	 * @param c
	 *            The char[] to check for not empty condition.
	 * @return <code>true</code> if char[] is not empty, <code>false</code>
	 *         otherwise.
	 */
	public static final boolean notEmpty(final char[] c) {
		return (c != null && c.length > 0);
	}

	/**
	 * Returns <code>true</code> if the {@link CharSequence} is not
	 * <code>null</code> and its length is greater than zero.
	 * 
	 * @param s
	 *            The {@link CharSequence} to check for not empty condition.
	 * @return <code>true</code> if {@link CharSequence} is not empty,
	 *         <code>false</code> otherwise.
	 */
	public static final boolean notEmpty(final CharSequence chSeq) {
		return (chSeq != null && chSeq.length() > 0);
	}

	/**
	 * Safely determines whether an {@link Object}'s {@link Class} type is
	 * <i>not equal</i> to the {@link Class} parameter while gracefully handling
	 * <code>null</code> reference values.
	 * 
	 * @param o
	 *            The {@link Object} to check it's {@link Class} type
	 * @param clazz
	 *            The {@link Class} type to check for
	 * @return <code>true</code> if
	 *         <code>(o == null || o.getClass() != clazz)</code>
	 */
	public static final boolean notEqual(final Object o,
			final Class<? extends Object> clazz) {
		return (o == null || o.getClass() != clazz);
	}

	/**
	 * Safely determines whether the two objects are <i>not equal</i> to one
	 * another according to the semantics of <code>Object.equals()</code> while
	 * gracefully handling <code>null</code> reference values.
	 * 
	 * @param o
	 *            the first object to compare for inequality.
	 * @param p
	 *            the second object to company for inequality.
	 * @return <code>true</code> if <code>!o.equals(p)</code>;
	 *         <code>false</code> otherwise.
	 */
	public static final boolean notEqual(final Object o, final Object p) {
		return o != p && (o == null || !o.equals(p));
	}

	/**
	 * Safely extract a <code>short</code> value from a {@link Number} object
	 * instance. If the {@link Number} instance is <code>null</code>, zero is
	 * returned.
	 * 
	 * @param n
	 *            The {@link Number} object instance.
	 * @return a <code>short</code> value, or zero if <code>null</code>.
	 */
	public static final short shortValue(final Number n) {
		return (short) ((n == null) ? 0 : n.intValue());
	}

	/**
	 * Safely calls <code>startsWith(String prefix)</code> on a {@link String}
	 * instance. Returns <code>false</code> if the {@link String} reference is
	 * <code>null</code>.
	 * 
	 * @param s
	 *            The {@link String} instance.
	 * @param prefix
	 *            The prefix.
	 * @return <code>true</code> if the {@link String} starts with the prefix.
	 */
	public static final boolean startsWith(final String s, final String prefix) {
		return (s != null && s.startsWith(prefix));
	}

	/**
	 * Safely returns a substring of the {@link String} parameter starting at
	 * <code>beginIndex</code>.
	 * 
	 * @param s
	 *            The {@link String} to substring.
	 * @param beginIndex
	 *            The beginning index.
	 * @return The specified substring, or <code>null</code>.
	 */
	public static final String substring(final String s, final int beginIndex) {
		return (s == null) ? null : s.substring(beginIndex);
	}

	/**
	 * Safely returns a substring of the {@link String} parameter starting at
	 * <code>beginIndex</code> and ends at <code>endIndex - 1</code>.
	 * 
	 * @param s
	 *            The {@link String} to substring.
	 * @param beginIndex
	 *            The beginning index.
	 * @param endIndex
	 *            The ending index.
	 * @return The specified substring, or <code>null</code>.
	 */
	public static final String substring(final String s, final int beginIndex,
			final int endIndex) {
		return (s == null) ? null : s.substring(beginIndex, endIndex);
	}

	/**
	 * Defaults <code>null</code> object references to the string value "null"
	 * (without quotes) while calling <code>Object.toString()</code> on non-null
	 * references.
	 * 
	 * @param obj
	 *            the object to represent as a string.
	 * @return a string representation of the object.
	 */
	public static final String toString(final Object obj) {
		return (obj == null) ? Characters.NULL_STRING : obj.toString();
	}

	/**
	 * Generates a string representation of an <code>int</code> array. If an
	 * array contains elements 1, 2, and 3 then the generated string will be
	 * "[1,2,3]".
	 * 
	 * @param ints
	 *            the array to represent as a string.
	 * @return a string representation of the array.
	 */
	public static final String toString(final int[] ints) {
		final ParamStrBuilder builder = new ParamStrBuilder();

		builder.append('[');
		if (ints != null) {
			for (int i = 0; i < ints.length; i++) {
				builder.separator(1).append(ints[i]);
			}
		}
		builder.append(']');

		return builder.toString();
	}

	/**
	 * Generates a string representation of an object array. If an array
	 * contains elements 'A', 'B', and 'C' then the generated string will be
	 * "[A,B,C]".
	 * 
	 * @param objs
	 *            the array to represent as a string.
	 * @return a string representation of the array.
	 */
	public static final String toString(final Object[] objs) {
		// TODO: How does this match up with Array.join() or whatever? And how
		// about an Extractable version (doesn't make sense on single
		// Extractable instance)?
		if (objs == null || objs.length == 0)
			return "[]";

		// 1. Calculate the string length
		int strLen = objs.length + 1;
		final String[] strs = new String[objs.length];
		for (int i = 0; i < objs.length; i++) {
			strs[i] = (objs[i] == null) ? Characters.NULL_STRING : objs[i]
					.toString();
			strLen += strs[i].length();
		}

		// 2. Create the character array
		final char[] c = new char[strLen];

		// 3. Get characters from first array element
		c[0] = '[';
		strLen = strs[0].length();
		strs[0].getChars(0, strLen, c, 1);

		// 4. Append characters from remaining elements
		int j = strLen + 1;
		for (int i = 1; i < objs.length; i++) {
			c[j++] = ',';
			strLen = strs[i].length();
			strs[i].getChars(0, strLen, c, j);
			j += strLen;
		}
		c[j] = ']';

		return new String(c);
	}

	/**
	 * TODO: Document!
	 * 
	 * @param objs
	 * @param len
	 * @return
	 */
	public static final String toString(final Object[] objs, final int len) {
		// TODO: How does this match up with Array.join() or whatever? And how
		// about an Extractable version (doesn't make sense on single
		// Extractable instance)?
		if (objs == null || len == 0)
			return "[]";

		int strLen = len + 1;
		final String[] strs = new String[len];
		for (int i = 0; i < len; i++) {
			strs[i] = (objs[i] == null) ? Characters.NULL_STRING : objs[i]
					.toString();
			strLen += strs[i].length();
		}

		final char[] c = new char[strLen];
		strLen = strs[0].length();

		c[0] = '[';
		strs[0].getChars(0, strLen, c, 1);
		int j = strLen + 1;
		for (int i = 1; i < len; i++) {
			c[j++] = ',';
			strLen = strs[i].length();
			strs[i].getChars(0, strLen, c, j);
			j += strLen;
		}
		c[j] = ']';

		return new String(c);
	}

	/**
	 * Safely trims the {@link String} value by checking for a <code>null</code>
	 * reference before trimming.
	 * 
	 * @param value
	 *            the string to trim.
	 * @return the trimmed string.
	 */
	public static final String trim(final String value) {
		return (value == null) ? null : value.trim();
	}

	/**
	 * Returns the string array representation of the object array argument.
	 * 
	 * @param objs
	 *            the object array.
	 * @return the string array representation of the object array.
	 */
	public static final String[] valueOf(final Object[] objs) {
		final String[] s = new String[objs.length];

		for (int i = 0; i < objs.length; i++)
			s[i] = (objs[i] == null) ? Characters.NULL_STRING
					: (objs[i] instanceof Object[]) ? Safe
							.toString((Object[]) objs[i]) : objs[i].toString();

		return s;
	}

	/**
	 * TODO: Remove!
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		final char[] c = { 'F', 'o', 'o', 'B', 'o', 'o' };

		System.out.println(Safe.lastIndexOf(c, 'o', 'o'));
	}

} // End Safe
