/*
 * Easy.java
 */
package root.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public final class Easy {

	/**
	 * TODO: Document!
	 * 
	 * @param t
	 * @return
	 */
	public static final String getStackTrace(final Throwable t) {
		final StringWriter sw = new StringWriter(500);

		t.printStackTrace(new PrintWriter(sw));

		return sw.toString();
	}

} // End Easy
