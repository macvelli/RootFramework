/*
 * Stat.java
 */
package root.math;

import java.math.BigDecimal;
import java.math.RoundingMode;

import root.data.structure.ListArray;
import root.data.structure.ListArraySorted;
import root.data.structure.MapHashed;

/**
 * TODO: This REALLY needs a primitive List of type long
 * TODO: Fix all of the missing braces
 * 
 * @author Edward Smith
 * @version 0.5
 */
public final class Stat {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private long					max;
	private long					min;
	private long					sum;
	private final ListArray<Long>	longs;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Stat() {
		longs = new ListArray<Long>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public void add(final long n) {
		longs.add(n);
		if (n > max)
			max = n;
		else if (n < min)
			min = n;
		sum += n;
	}

	public double correl(final Stat y) {
		return covar(y) / (stdev() * y.stdev());
	}

	public double covar(final Stat y) {
		double xm = mean();
		double ym = y.mean();
		double sum = 0.0;

		for (int i=0; i < longs.getSize(); i++)
			sum += ((longs.get(i) - xm) * (y.longs.get(i) - ym));
		
		return sum / longs.getSize();
	}

	public int count() {
		return longs.getSize();
	}

	public double intercept(final Stat y) {
		return (y.sum - (slope(y) * sum)) / longs.getSize();
	}

	public long max() {
		return max;
	}

	public double mean() {
		return divide(sum, longs.getSize());
	}

	public double median() {
		final ListArraySorted<Long> sorted = new ListArraySorted<Long>(longs.toArray(new Long[longs.getSize()]));
		final int half = sorted.getSize() >>> 1;

		if ((sorted.getSize() & 0x01) == 0)
			return divide(sorted.get(half - 1) + sorted.get(half), 2);

		return sorted.get(half);
	}

	public long min() {
		return min;
	}

	public long mode() {
		long mode = 0;
		int numTimes = 0;
		final ListArraySorted<Long> sorted = new ListArraySorted<Long>(longs.toArray(new Long[longs.getSize()]));

		long n = 0;
		int j = 0;
		for (Long l : sorted) {
			if (n != l) {
				if (j > numTimes) {
					mode = n;
					numTimes = j;
				}
				n = l;
				j = 1;
			} else
				j++;
		}

		if (numTimes < 2)
			throw new IllegalStateException("Mode value not available");

		return mode;
	}

	public float percent(final Stat part) {
		return new BigDecimal((part.sum * 100) / (double) sum).setScale(1, RoundingMode.HALF_DOWN).floatValue();
	}

	public long range() {
		return max() - min();
	}

	public double[] rank() {
		final MapHashed<Long, Double>	ties = new MapHashed<>(longs.getSize());
		final ListArraySorted<Long> sorted = new ListArraySorted<Long>(longs.toArray(new Long[longs.getSize()]));
		final double[] ranks = new double[longs.getSize()];

		int i = 0;
		for (Long l : longs) {
			if (ties.containsKey(l))
				ranks[i] = ties.get(l);
			else {
				int rank = sorted.indexOf(l) + 1;
				int n = 1;
				int j = rank;
				while (j < sorted.getSize() && sorted.get(j++) == l) {
					rank += j;
					n++;
				}

				if (n > 1) {
					ranks[i] = divide(rank, n);
					ties.put(l, ranks[i]);
				} else
					ranks[i] = rank;
			}

			i++;
		}

		return ranks;
	}

	public String regression(final Stat y) {
		StringBuilder builder = new StringBuilder("y = ");

		builder.append(intercept(y));
		double slope = slope(y);

		if (slope >= 0.0)
			builder.append(" + ").append(slope);
		else
			builder.append(" - ").append(Math.abs(slope));

		return builder.append('x').toString();
	}

	public double rms() {
		double sum = 0.0;

		for (Long l : longs)
			sum += Math.pow(l, 2);

		return Math.sqrt(sum / longs.getSize());
	}

	public double slope(final Stat y) {
		return (longs.getSize() * sumprod(y) - (sum * y.sum)) / (longs.getSize() * sumsq() - Math.pow(sum, 2));
	}

	public double stdev() {
		return stdev(true);
	}

	public double stdev(final boolean population) {
		double stdev = 0;
		double mean = mean();

		for (Long l : longs)
			stdev += Math.pow(l - mean, 2);

		if (population)
			stdev /= longs.getSize();
		else
			stdev /= (longs.getSize() - 1);

		return Math.sqrt(stdev);
	}

	public long sum() {
		return sum;
	}

	// <><><><><><><><><><><><><><> Private Methods <><><><><><><><><><><><><><

	private double divide(final double dividend, final double divisor) {
		return (divisor > 0) ? new BigDecimal(dividend).divide(new BigDecimal(divisor), 5, RoundingMode.HALF_DOWN).doubleValue() : 0.0d;
	}

	private long sumprod(final Stat y) {
		long sum = 0;

		for (int i=0; i < longs.getSize(); i++)
			sum += longs.get(i) * y.longs.get(i);

		return sum;
	}

	private long sumsq() {
		long sum = 0;

		for (Long l : longs)
			sum += Math.pow(l, 2);

		return sum;
	}

}	// End Stat
