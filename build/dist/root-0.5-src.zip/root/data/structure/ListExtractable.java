/*
 * ListExtractable.java
 */
package root.data.structure;

import root.lang.Characters;
import root.lang.Extractable;
import root.lang.ParamStrBuilder;

/**
 * TODO: Find a way to get String, Integer, etc to fit into this...
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public final class ListExtractable<T extends Extractable<Characters>> extends ListArray<T> implements Extractable<Characters> {

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListExtractable() {
		super();
	}

	public ListExtractable(final int capacity) {
		super(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		if (size == 0) {
			chars.append(Characters.emptyArray);
		} else {
			chars.append('[');
			final int start = chars.getLength();
			for (int i=0; i < size; i++) {
				chars.separator(start).append(values[i]);
			}
			chars.append(']');
		}
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(size << 4);
		extract(chars);
		return chars.toString();
	}

}	// End ListExtractable
