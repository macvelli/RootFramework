/*
 * ListArraySorted.java
 */
package root.data.structure;

import java.util.Arrays;
import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.util.Fast;
import root.util.Safe;

/**
 * Similar to the {@link ListArray} though it keeps its elements in sorted
 * order.
 * 
 * TODO:
 * 		+ Add final designation to every non-private method
 * 		+ Add final designation to every method argument that is not used as a local variable
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc
 * 		+ Remove @Override annotations
 * 		+ Finish implementing List methods that are down at the bottom
 * 		+ Set this up like the Immutables where unsupported operations will be deleted once the List<T> implements is removed
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public class ListArraySorted<T extends Comparable<T>> extends DynamicArray<T> implements RootList<T> {

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListArraySorted() {
		super(5);
	}

	public ListArraySorted(final int capacity) {
		super(Fast.max(5, capacity));
	}

	/**
	 * This constructor passes the array created for the vararg at runtime
	 * into the super constructor for maximum performance. Then the value
	 * array is sorted to finish initialization.
	 * 
	 * @param array
	 */
	@SafeVarargs
	public ListArraySorted(final T... array) {
		super(array);
		Arrays.sort(values);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean add(final T t) {
		if (size == values.length) {
			resize(size << 1);
		}

		int i = indexOf(t);
		if (i < 0) {
			i = ~i;
		}

		if (i < size) {
			System.arraycopy(values, i, values, i+1, size-i);
		}
		size++;

		values[i] = t;

		return true;
	}

	@Override
	public final void add(final int index, final T t) {
		throw new UnsupportedOperationException("Use the add(T) function to insert an element into a ListArraySorted");
	}

	@Override
	@SafeVarargs
	public final void addAll(final T... array) {
		if (array != null && array.length > 0) {
			final int newSize = size + array.length;

			if (newSize > values.length) {
				// TODO: Propagate this resize logic to any other method that takes collections of data to add
				resize(newSize + (newSize >> 1));
			}

			System.arraycopy(array, 0, values, size, array.length);
			size = newSize;
			Arrays.sort(values);
		}
	}

	@Override
	public final boolean addAll(final Collection<? extends T> c) {
		if (c != null && c.size() > 0) {
			final int newSize = size + c.size();

			if (newSize > values.length) {
				// TODO: Propagate this resize logic to any other method that takes collections of data to add
				resize(newSize + (newSize >> 1));
			}

			for (T t : c) {
				values[size++] = t;
			}
			Arrays.sort(values);

			return true;
		}

		return false;
	}

	@Override
	public final boolean addAll(final int index, final Collection<? extends T> c) {
		throw new UnsupportedOperationException("Use the addAll(Collection<? extends T>) function to insert elements into a ListArraySorted");
	}

	@Override
	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	@Override
	public final boolean contains(final Object obj) {
		return indexOf(obj) >= 0;
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... array) {
		for (T t : array) {
			if (indexOf(t) < 0) {
				return false;
			}
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		for (Object obj : c) {
			if (indexOf(obj) < 0) {
				return false;
			}
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... array) {
		for (T t : array) {
			if (indexOf(t) >= 0) {
				return true;
			}
		}

		return false;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		for (T t : c) {
			if (indexOf(t) >= 0) {
				return true;
			}
		}

		return false;
	}

	@Override
	public final T echo(final T t) {
		// TODO Auto-generated method stub
		return null;
	}

	public final T get(final T key) {
		final int i = indexOf(key);

		return (i < 0) ? null : values[i];
	}

	public final T greaterThan(final T value) {
		int i = indexOf(value);

		for (i = (i < 0) ? ~i : i+1; i < size; i++) {
			if (values[i].compareTo(value) > 0) {
				return values[i];
			}
		}

		return null;
	}

	@Override
	public final int indexOf(final Object obj) {
		final T t = (T) obj;
		int mid, low = 0, high = size;

		while (low < high) {
			mid = (low + high) >>> 1;

			if (Safe.equals(values[mid], obj)) {
				return mid;
			} else if (values[mid].compareTo(t) < 0) {
		    	low = mid + 1;
			} else {
		    	high = mid;
			}
		}

		// TODO: Test this method out extensively to make sure the overall logic is sound
		return (low < size && values[low].equals(t)) ? low : ~low;
	}

	@Override
	public final void insert(final int i, final T o) {
		throw new UnsupportedOperationException("Use the add(T) function to insert an element into a ListArraySorted");
	}

	@Override
	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListArraySorted");
	}

	@Override
	public final void insertAll(final int i, final Itemizable<? extends T> c) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListArraySorted");
	}

	@Override
	public final void insertAll(final int i, final Iterable<? extends T> c) {
		throw new UnsupportedOperationException("Use the addAll(T) function to insert elements into a ListArraySorted");
	}

	@Override
	public final int lastIndexOf(final Object obj) {
		int i = indexOf(obj);

		if (i < 0) {
			return -1;
		}

		while (++i < size && Safe.equals(values[i], obj));

		return i-1;
	}

	@Override
	public final ListItemizer<T> listIterator() {
		return new ListArraySortedItemizer(0);
	}

	@Override
	public final ListItemizer<T> listIterator(final int index) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		return new ListArraySortedItemizer(index);
	}

	@Override
	public final boolean remove(final Object obj) {
		final int i = indexOf(obj);

		if (i < 0) {
			return false;
		}

		System.arraycopy(values, i+1, values, i, size-i);
		values[--size] = null;

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		int i, j;
		for (T t : a) {
			i = indexOf(t);

			if (i >= 0) {
				j = i+1;
				System.arraycopy(values, j, values, i, size-j);
				values[--size] = null;
			}
		}

		return origSize != size;
	}

	@Override
	public final boolean removeAll(final Collection<?> c) {
		final int origSize = size;

		int i, j;
		for (Object obj : c) {
			i = indexOf(obj);

			if (i >= 0) {
				j = i+1;
				System.arraycopy(values, j, values, i, size-j);
				values[--size] = null;
			}
		}

		return origSize != size;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		final int oi = indexOf(o);

		if (oi < 0) {
			return false;
		}

		int ni = indexOf(n);
		if (ni < 0) {
			ni = ~ni;
		}

		if (oi < ni) {
			System.arraycopy(values, oi+1, values, oi, --ni-oi);
		} else {
			System.arraycopy(values, ni, values, ni+1, oi-ni);
		}

		values[ni] = n;

		return true;
	}

	@Override
	public final T set(final int i, final T t) {
		throw new UnsupportedOperationException("Use the add(T) function to put an element into a ListArraySorted");
	}

	@Override
	public final void shuffle() {
		throw new UnsupportedOperationException("Cannot shuffle the elements of a ListArraySorted");
	}

	@Override
	public final ListArraySorted<T> subList(final int fromIndex) {
		return subList(fromIndex, size);
	}

	@Override
	public final ListArraySorted<T> subList(final int from, final int to) {
		if (from >= to || from < 0) {
			// TODO: This needs to be range out of bounds exception
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			// TODO: This needs to be range out of bounds exception
			throw new IndexOutOfBoundsException(to, size);
		}

		final int len = to - from;
		final ListArraySorted<T> a = new ListArraySorted<T>(len);

		System.arraycopy(values, from, a.values, 0, len);
		a.size = len;

		return a;
	}

	@Override
	public final SetHashed<T> subset(final int fromIndex) {
		return subset(fromIndex, size);
	}

	@Override
	public SetHashed<T> subset(final int fromIndex, final int toIndex) {
		if (fromIndex >= toIndex || fromIndex < 0) {
			throw new IndexOutOfBoundsException(fromIndex, toIndex);
		}

		if (toIndex > size) {
			throw new IndexOutOfBoundsException(toIndex, size);
		}

		final SetHashed<T> s = new SetHashed<T>(toIndex-fromIndex);

		for (int i=fromIndex; i < toIndex; i++) {
			s.add(values[i]);
		}

		return s;
	}

	@Override
	public final SetHashed<T> toSet() {
		return subset(0, size);
	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	private final class ListArraySortedItemizer implements ListItemizer<T> {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private int currentPos;
		private final int startingPoint;

		// <><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><>

		private ListArraySortedItemizer(final int startingPoint) {
			currentPos = startingPoint;
			this.startingPoint = startingPoint;
		}

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		@Override
		public final void add(final T t) {
			throw new UnsupportedOperationException("Cannot add(T t) into a ListArraySorted at the current position");
		}

		@Override
		public final int getIndex() {
			return currentPos-1;
		}

		@Override
		public final int getSize() {
			return size;
		}

		@Override
		public final boolean hasNext() {
			return currentPos < size;
		}

		@Override
		public final boolean hasPrevious() {
			return currentPos > 0;
		}

		@Override
		public final ListItemizer<T> iterator() {
			return this;
		}

		@Override
		public final T next() {
			if (currentPos == size) {
				throw new NoSuchElementException();
			}

			return values[currentPos++];
		}

		@Override
		public final int nextIndex() {
			return currentPos;
		}

		@Override
		public final T previous() {
			if (currentPos == 0) {
				throw new NoSuchElementException();
			}

			return values[--currentPos];
		}

		@Override
		public final int previousIndex() {
			return currentPos-1;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final void reset() {
			currentPos = startingPoint;
		}

		@Override
		public final void set(final T t) {
			throw new UnsupportedOperationException("Cannot set(T t) into a ListArraySorted at the current position");
		}

	}	// End ListArraySortedItemizer

}	// End ListArraySorted
