/*
 * DynamicArray.java
 */
package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;
import root.util.Random;
import root.util.Safe;

/**
 * - Check https://github.com/RuedigerMoeller/fast-serialization before
 *   going on an Externalizable kick
 *   	+ http://java-is-the-new-c.blogspot.com/2013/10/still-using-externalizable-to-get.html
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
abstract class DynamicArray<T> implements java.util.Collection<T>, Itemizable<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	protected int	size;
	protected T[]	values;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	protected DynamicArray(final int capacity) {
		values = Clean.newArray(capacity);
	}

	protected DynamicArray(final T[] a) {
		values = a;
		size = a.length;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		for (int i=0; i < size; i++) {
			values[i] = null;
		}

		size = 0;
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof Iterable)) {
			return false;
		}

		final Iterable<?> i = (Iterable<?>) o;

		int j = 0;
		for (Object t : i) {
			if (j == size) {
				return false;
			}

			if (Safe.notEqual(values[j++], t)) {
				return false;
			}
		}

		return j == size;
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	public final T get(final int i) {
		return values[i];
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Descend();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		return Safe.hashCode(values, size);
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	public final T last() {
		return (size > 0) ? values[size - 1] : null;
	}

	public final T random() {
		return values[Random.nextIndex(size)];
	}

	public final T remove(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		final T oldVal = values[i];
		System.arraycopy(values, i+1, values, i, size-i);
		values[--size] = null;

		return oldVal;
	}

	@Override
	public final boolean retainAll(final Collection<?> c) {
		if (c != null && c.size() > 0) {
			final T[] retainedValues = Clean.newArray(values.length);
			final int origSize = size;
			int j = 0;
			T t;

			for (int i=0; i < size; i++) {
				t = values[i];

				if (c.contains(t)) {
					retainedValues[j++] = t;
				}
			}

			if (origSize != j) {
				values = retainedValues;
				size = j;
				return true;
			}
		}

		return false;
	}

	@Override
	public final int size() {
		return size;
	}

	@Override
	public final T[] toArray() {
		final T[] array = Clean.newArray(size);

		System.arraycopy(values, 0, array, 0, size);

		return array;
	}

	@Override
	public final <E> E[] toArray(final E[] arrayParam) {
		final E[] array = Clean.newArray(arrayParam, size);

		System.arraycopy(values, 0, array, 0, size);

		return array;
	}

	@Override
	public String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		for (int i=0; i < size; i++) {
			builder.separator(1).append(values[i]);
		}
		builder.append(']');

		return builder.toString();
	}

	// <><><><><><><><><><><><><>< Protected Methods <><><><><><><><><><><><><>

	protected final void resize(final int newCapacity) {
		final T[] t = Clean.newArray(newCapacity);
		System.arraycopy(values, 0, t, 0, size);
		values = t;
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Public Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//	public void compact() {
//		if (values.length > size) {
//			final T[] t = (T[]) new Object[size];
//			System.arraycopy(values, 0, t, 0, size);
//			values = t;
//		}
//	}
//
//	// TODO: Why is there this version, a SubList.join() version, and a Safe.toString() version? 
//	public String join(final String sep) {
//		if (size == 0)
//			return "[]";
//
//		Object o;
//		int strLen = 2;
//		final String[] strs = new String[size];
//		for (int i=0; i < size; i++) {
//			o = values[i];
//			strs[i] = (o == null) ? Safe.NULL : o.toString();
//			strLen += strs[i].length();
//		}
//
//		final int sepLen = sep.length();
//		final char[] c = new char[strLen + ((size - 1) * sepLen)];
//		strLen = strs[0].length();
//
//		c[0] = '[';
//		strs[0].getChars(0, strLen, c, 1);
//		int j = strLen + 1;
//		for (int i=1; i < size; i++) {
//			sep.getChars(0, sepLen, c, j);
//			j += sepLen;
//			strLen = strs[i].length();
//			strs[i].getChars(0, strLen, c, j);
//			j += strLen;
//		}
//		c[j] = ']';
//
//		return new String(c);
//	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	private final class Ascend implements Itemizer<T> {

		private int i;

		@Override
		public final boolean hasNext() {
			return i < size;
		}

		@Override
		public final T next() {
			if (i == size) {
				throw new NoSuchElementException();
			}

			return values[i++];
		}

		@Override
		public final void remove() {
			final int index = i-1;
			System.arraycopy(values, i, values, index, size-index);
			values[--size] = null;
		}

		@Override
		public final int getIndex() {
			return i-1;
		}

		@Override
		public final int getSize() {
			return size;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
		}

	}	// End Ascend

	private class Descend implements Itemizer<T> {

		private int i = size;

		@Override
		public final boolean hasNext() {
			return i > 0;
		}

		@Override
		public final T next() {
			if (i == 0) {
				throw new NoSuchElementException();
			}

			return values[--i];
		}

		@Override
		public final void remove() {
			final int index = i+1;
			System.arraycopy(values, index+1, values, index, size-index);
			values[--size] = null;
		}

		@Override
		public final int getIndex() {
			return i;
		}

		@Override
		public final int getSize() {
			return size;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = size;
		}

	}	// End Descend

}	// End DynamicArray
