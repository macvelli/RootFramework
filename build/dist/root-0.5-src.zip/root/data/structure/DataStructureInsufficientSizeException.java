/*
 * DataStructureInsufficientSizeException.java
 * 
 * Last Modified: 02/24/2016
 */
package root.data.structure;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class DataStructureInsufficientSizeException extends RuntimeException {

	// Constants

	private static final long serialVersionUID = 6651809755110426230L;

	// Constructors

	public DataStructureInsufficientSizeException(final int requested, final int available) {
		// TODO: Replace StringBuilder with faster Root implementation
		super(new StringBuilder(90)
			.append("Attempt to remove ")
			.append(requested)
			.append(" elements from a data structure of size ")
			.append(available)
			.append(" failed")
			.toString());
	}
	
}	// End DataStructureInsufficientSizeException
