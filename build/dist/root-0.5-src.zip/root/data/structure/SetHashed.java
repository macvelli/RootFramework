/*
 * SetHashed.java
 */
package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Characters;
import root.lang.Immutable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;
import root.util.Fast;
import root.util.Safe;

/**
 * TODO
 * 		+ http://en.wikipedia.org/wiki/Set_(abstract_data_type)
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public class SetHashed<T> implements RootSet<T>, Cloneable, Immutable {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	protected int size;
	private int capacity;
	protected SetEntry<T>[] table;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public SetHashed() {
		capacity = 8;
		table = SetEntry.newArray(8);
	}

	public SetHashed(final int capacity) {
		this.capacity = Fast.max(capacity, 8);
		table = SetEntry.newArray(this.capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean add(final T o) {
		final int h = Safe.hashCode(o);
		int i = h % table.length;

		for (SetEntry<T> n = table[i]; n != null; n = n.next) {
			if (Safe.equals(n.key, o)) {
				return false;
			}
		}

		if (size++ == capacity) {
			i = resize(h);
		}

		table[i] = new SetEntry<T>(o, h, table[i]);

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean addAll(final T... a) {
		final int origSize = size;

		for (T t : a) {
			add(t);
		}

		return origSize != size;
	}

	@Override
	public final boolean addAll(final Collection<? extends T> c) {
		final int origSize = size;

		for (T t : c) {
			add(t);
		}

		return origSize != size;
	}

	@Override
	public final boolean addAll(final Iterable<? extends T> c) {
		final int origSize = size;

		for (T t : c) {
			add(t);
		}

		return origSize != size;
	}

	@Override
	public final void clear() {
		SetEntry<T> n, next;

		for (int i=0, j=0; j < size; i++) {
			for (n = table[i]; n != null; n = next) {
				next = n.next;
				n.next = null;
				j++;
			}
			table[i] = null;
		}

		size = 0;
	}

	@Override
	public final SetHashed<T> clone() {
		final SetHashed<T> set = new SetHashed<>(capacity);

		set.addAll(this);

		return set;
	}

	@Override
	public final boolean contains(final Object obj) {
		for (SetEntry<T> n = table[Safe.hashCode(obj) % table.length]; n != null; n = n.next) {
			if (Safe.equals(n.key, obj)) {
				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... a) {
		SetEntry<T> n;

items:	for (T t : a) {
			for (n = table[Safe.hashCode(t) % table.length]; n != null; ) {
				if (Safe.equals(n.key, t)) {
					n = n.next;
					continue items;
				}

				return false;
			}
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		SetEntry<T> n;

items:	for (Object o : c) {
			for (n = table[Safe.hashCode(o) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, o)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Iterable<? extends T> c) {
		SetEntry<T> n;

items:	for (T t : c) {
			for (n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... a) {
		SetEntry<T> n;

		for (T t : a) {
			for (n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		SetEntry<T> n;

		for (T t : c) {
			for (n = table[Safe.hashCode(t) % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final SetHashed<T> difference(final Iterable<? extends T> c) {
		final SetHashed<T> set = new SetHashed<>(size);

		for (T t : c) {
			if (!this.contains(t)) {
				set.add(t);
			}
		}

		return set;
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof SetHashed)) {
			return false;
		}

		final SetHashed<?> s = (SetHashed<?>) o;
		if (s.size != size) {
			return false;
		}

objs:	for (SetEntry<?> e : s.getSetEntryItemizer()) {
			for (SetEntry<T> n = table[e.hash % table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, e.key)) {
					continue objs;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final T get(final T e) {
		int i = Safe.hashCode(e) % table.length;

		for (SetEntry<T> n = table[i]; n != null; n = n.next) {
			if (Safe.equals(n.key, e)) {
				return n.key;
			}
		}

		return null;
	}

	@Override
	public final Collection<T> getCollection() {
		// TODO I think this method can go away when all Itemizable classes implement the Java Collections API
		return this;
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new StackArray<>(this).iterator();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		SetEntry<T> e;
		int h = size;

		for (int i=0, j=0; j < size; i++) {
			for (e = table[i]; e != null; e = e.next) {
				h ^= e.hash;
				h <<= 1;
				j++;
			}
		}

		return h;
	}

	@Override
	public final SetHashed<T> intersect(final Iterable<? extends T> c) {
		final SetHashed<T> set = new SetHashed<>(size);

		for (T t : c) {
			if (this.contains(t)) {
				set.add(t);
			}
		}

		return set;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	@Override
	public final boolean remove(final Object obj) {
		final int i = Safe.hashCode(obj) % table.length;
		SetEntry<T> n, prev = null;

		for (n = table[i]; n != null; prev = n, n = n.next) {
			if (Safe.equals(n.key, obj)) {
				if (prev == null) {
					table[i] = n.next;
				} else {
					prev.next = n.next;
				}

				n.next = null;
				size--;
				return true;
			}
		}

		return false;
	}

	/**
	 * 
	 * @param a
	 * @return
	 */
	@Override
	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		for (T t : a) {
			remove(t);
		}

		return origSize != size;
	}

	/**
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public final boolean removeAll(final Collection<?> c) {
		final int origSize = size;

		for (Object o : c) {
			remove(o);
		}

		return origSize != size;
	}

	/**
	 * 
	 * @param c
	 * @return
	 */
	@Override
	public final boolean removeAll(final Iterable<? extends T> c) {
		final int origSize = size;

		for (T t : c) {
			remove(t);
		}

		return origSize != size;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		return remove(o) && add(n);
	}

	@Override
	public final boolean retainAll(final Collection<?> c) {
		SetEntry<T> n, prev = null;
		final int origSize = size;

		for (int i=0, j=0; j < size; i++) {
			for (n = table[i]; n != null; prev = n, n = n.next) {
				if (!c.contains(n.key)) {
					if (prev == null) {
						table[i] = n.next;
					} else {
						prev.next = n.next;
					}

					n.next = null;
					size--;
				}

				j++;
			}
		}

		return origSize != size;
	}

	@Override
	public final int size() {
		return size;
	}

	@Override
	public final T[] toArray() {
		final T[] array = Clean.newArray(size);
		SetEntry<T> n;

		for (int i=0, j=0; j < size; i++) {
			for (n = table[i]; n != null; n = n.next) {
				array[j++] = n.key;
			}
		}

		return array;
	}

	@Override
	public final <E> E[] toArray(final E[] arrayParam) {
		final E[] array = Clean.newArray(arrayParam, size);
		SetEntry<T> n;

		for (int i=0, j=0; j < size; i++) {
			for (n = table[i]; n != null; n = n.next) {
				array[j++] = Clean.cast(n.key);
			}
		}

		return array;
	}

	@Override
	public final ListArray<T> toList() {
		final ListArray<T> list = new ListArray<>(size);
		SetEntry<T> n;

		for (int i=0, j=0; j < size; i++) {
			for (n = table[i]; n != null; n = n.next) {
				list.values[j++] = n.key;
			}
		}

		return list;
	}

	@Override
	public final SetHashed<T> union(final Iterable<? extends T> c) {
		final SetHashed<T> set = new SetHashed<>(size);

		set.addAll(this);
		set.addAll(c);

		return set;
	}

	@Override
	public final SetImmutable<T> toImmutable() {
		return new SetImmutable<>(this.clone());
	}

	@Override
	public String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		if (size == 0) {
			builder.append(Characters.emptyArray);
		} else {
			SetEntry<T> e;

			builder.append('[');
			for (int i=0, j=0; j < size; i++) {
				for (e = table[i]; e != null; e = e.next) {
					builder.separator(1).append(e.key);
					j++;
				}
			}
			builder.append(']');
		}

		return builder.toString();
	}

	// <><><><><><><><><><><><><><> Package Methods <><><><><><><><><><><><><><

	Itemizer<SetEntry<T>> getSetEntryItemizer() {
		return new SetEntryItemizer();
	}

	// <><><><><><><><><><><><><><> Private Methods <><><><><><><><><><><><><><

	private int resize(final int h) {
		final SetEntry<T>[] oldTable = table;
		capacity = (capacity << 1) - (capacity >> 2);
		table = SetEntry.newArray(capacity);

		SetEntry<T> n, next;
		for (int i=0, j=0; i < oldTable.length; i++) {
			for (n = oldTable[i]; n != null; n = next) {
				next = n.next;
				j = n.hash % table.length;
				n.next = table[j];
				table[j] = n;
			}
			oldTable[i] = null;
		}

		return h % table.length;
	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	private final class Ascend implements Itemizer<T> {

		private int i, j;
		private SetEntry<T> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = table[i++];
			}

			return e.key;
		}

		@Override
		public final void remove() {
			SetHashed.this.remove(e.key);
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}

		@Override
		public final int getSize() {
			return size;
		}
		
	}	// End Ascend

	private final class SetEntryItemizer implements Itemizer<SetEntry<T>> {

		private int i, j;
		private SetEntry<T> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final SetEntry<T> next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = table[i++];
			}

			return e;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final Itemizer<SetEntry<T>> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End SetEntryItemizer

}	// End SetHashed
