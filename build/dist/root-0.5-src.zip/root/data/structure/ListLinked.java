/*
 * ListLinked.java
 * 
 * Last Modified: 04/28/2016
 */
package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.util.Clean;
import root.util.Random;
import root.util.Safe;

/**
 * Cannot call this a HeapList because of this:
 * 
 * 	http://en.wikipedia.org/wiki/Heap_(data_structure)
 * 
 * One benefit for not implementing List<T> directly is that you
 * are required to use the specific List implementation which also
 * means you have access to any methods unique to the implementation.
 * 
 * TODO:
 * 		+ Add final designation to every non-private method
 * 		+ Add final designation to every method argument that is not used as a local variable
 * 		+ Put Itemizer<T> methods for addAll(), insertAll(), etc
 * 		+ Remove @Override annotations from List<T> methods
 * 		+ Implement Cloneable in all data structures!! (done here)
 * 
 * @author Edward Smith
 * @version 1.0
 *
 * @param <T>
 */
public class ListLinked<T> implements RootList<T>, Cloneable {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int		size;
	private Node<T>	head;
	private Node<T>	tail;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListLinked() {
		// No-op default constructor
	}

	public ListLinked(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean add(final T o) {
		final Node<T> node = new Node<T>(o);

		if (tail == null) {
			head = node;
		} else {
			tail.next = node;
		}

		tail = node;
		size++;

		return true;
	}

	@Override
	public final void add(final int index, final T t) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		final Node<T> node = new Node<T>(t);

		if (index == size) {
			if (tail == null) {
				head = node;
			} else {
				tail.next = node;
			}

			tail = node;
		} else if (index == 0) {
			node.next = head;
			head = node;
		} else {
			Node<T> prev = head;
			for (int j=1; j < index; j++, prev = prev.next);

			node.next = prev.next;
			prev.next = node;
		}

		size++;
	}

	@Override
	@SafeVarargs
	public final void addAll(final T... array) {
		if (array != null && array.length > 0) {
			Node<T> node = new Node<T>(array[0]);

			if (tail == null) {
				head = node;
			} else {
				tail.next = node;
				tail = node;
			}

			for (int i=1; i < array.length; i++) {
				node = new Node<T>(array[i]);
				tail.next = node;
				tail = node;
			}

			size += array.length;
		}
	}

	@Override
	public final boolean addAll(final Collection<? extends T> c) {
		for (T t : c) {
			add(t);
		}

		return true;
	}

	@Override
	public final boolean addAll(final int index, final Collection<? extends T> c) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		Node<T> collHead = null, collTail = null, node;
		for (T t : c) {
			node = new Node<T>(t);

			if (collTail == null) {
				collHead = node;
			} else {
				collTail.next = node;
			}

			collTail = node;
		}

		if (index == size) {
			if (tail == null) {
				head = collHead;
			} else {
				tail.next = collHead;
			}

			tail = collTail;
		} else if (index == 0) {
			collTail.next = head;
			head = collHead;
		} else {
			Node<T> prev = head;
			for (int j=1; j < index; j++, prev = prev.next);

			collTail.next = prev.next;
			prev.next = collHead;
		}

		size += c.size();
		return true;
	}

	@Override
	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			add(t);
		}
	}

	@Override
	public final void clear() {
		Node.clear(head);

		head = null;
		tail = null;
		size = 0;
	}

	@Override
	public final ListLinked<T> clone() {
		return new ListLinked<>(this);
	}

	@Override
	public final boolean contains(final Object o) {
		for (Node<T> n = head; n != null; n = n.next) {
			if (Safe.equals(n.data, o)) {
				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... l) {
		Node<T> n;

items:	for (T t : l) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		Node<T> n;

items:	for (Object obj : c) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, obj)) {
					continue items;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... l) {
		Node<T> n;

		for (T t : l) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		Node<T> n;

		for (T t : c) {
			for (n = head; n != null; n = n.next) {
				if (Safe.equals(n.data, t)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final T echo(final T o) {
		add(o);
		return o;
	}

	@Override
	public final boolean equals(final Object o) {
		return Node.equals(o, head);
	}

	@Override
	public final T get(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		return n.data;
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Node.Descend<>(head, size);
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		return Node.hashCode(head, size);
	}

	@Override
	public final int indexOf(final Object obj) {
		int i=0;

		for (Node<T> n = head; n != null; n = n.next, i++) {
			if (Safe.equals(n.data, obj)) {
				return i;
			}
		}

		return -1;
	}

	/**
	 * TODO: What happens with the tail when I insert at size-1?
	 */
	@Override
	public final void insert(final int index, final T t) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		final Node<T> node = new Node<T>(t);

		if (index == size) {
			if (tail == null) {
				head = node;
			} else {
				tail.next = node;
			}

			tail = node;
		} else if (index == 0) {
			node.next = head;
			head = node;
		} else {
			Node<T> prev = head;
			for (int j=1; j < index; j++, prev = prev.next);

			node.next = prev.next;
			prev.next = node;
		}

		size++;
	}

	@Override
	@SafeVarargs
	public final void insertAll(final int i, final T... a) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		if (a.length > 0) {
			Node<T> first, prev, current;

			first = new Node<T>(a[0]);
			prev = first;
			for (int j=1; j < a.length; j++) {
				current = new Node<T>(a[j]);
				prev.next = current;
				prev = current;
			}
	
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += a.length;
		}
	}

	/**
	 * TODO: Test c.getSize() == 1, i=0, i=size-1
	 */
	@Override
	public final void insertAll(int i, final Itemizable<? extends T> c) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		if (c.getSize() > 0) {
			Node<T> first = null, prev = null, current;

			for (T t : c) {
				current = new Node<T>(t);

				if (first == null) {
					first = current;
				} else {
					prev.next = current;
				}

				prev = current;
			}
	
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += c.getSize();
		}
	}

	/**
	 * TODO: Test c.isEmpty() == true, i=0, i=size-1
	 */
	@Override
	public final void insertAll(final int i, final Iterable<? extends T> c) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> first = null, prev = null, current;
		int iterableSize = 0;

		for (T t : c) {
			current = new Node<T>(t);

			if (first == null) {
				first = current;
			} else {
				prev.next = current;
			}

			prev = current;
			iterableSize++;
		}

		if (iterableSize > 0) {
			if (i == 0) {
				prev.next = head;
				head = first;
			} else if (i == size) {
				tail.next = first;
				tail = first;
			} else {
				current = head;
				for (int j=1; j < i; j++, current = current.next);

				prev.next = current.next;
				current.next = first;
			}

			size += iterableSize;
		}
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Node.Ascend<T>(head, size);
	}

	public final String join(final String sep) {
		// TODO: Why are we using StringBuilder instead of ParamStrBuilder?
		final StringBuilder builder = new StringBuilder((size << 4) + 2);

		builder.append('[');
		if (head != null) {
			builder.append(head.data);
			for (Node<T> node = head.next; node != null; node = node.next) {
				builder.append(sep).append(node.data);
			}
		}

		return builder.append(']').toString();
	}

	@Override
	public final T last() {
		return (tail == null) ? null : tail.data;
	}

	@Override
	public final int lastIndexOf(final Object obj) {
		Node<T> node = head;
		int lastIndex = -1;

		for (int i=0; node != null; i++, node = node.next) {
			if (Safe.equals(node.data, obj)) {
				lastIndex = i;
			}
		}

		return lastIndex;
	}

	@Override
	public final ListItemizer<T> listIterator() {
		return new ListLinkedItemizer(0);
	}

	@Override
	public final ListItemizer<T> listIterator(final int index) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		return new ListLinkedItemizer(index);
	}

	/**
	 * TODO: Evaluate the use of a global Random class as a potential bottleneck
	 */
	@Override
	public final T random() {
		final int i = Random.nextIndex(size);

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		return n.data;
	}

	/**
	 * TODO: This implementation looks fishy to me...test the hell out of it
	 */
	@Override
	public final T remove(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> prev = null, node = head;
		for (int j=0; j < i; j++, prev = node, node = node.next);

		if (head == node) {
			head = head.next;
		}
		if (tail == node) {
			tail = prev;
			tail.next = null;
		}
		if (prev != null) {
			prev.next = node.next;
		}

		final T oldVal = node.data;
		node.data = null;
		node.next = null;
		node = null;
		size--;

		return oldVal;
	}

	@Override
	public final boolean remove(final Object obj) {
		for (Node<T> prev = null, node = head; node != null; prev = node, node = node.next) {
			if (Safe.equals(node.data, obj)) {
				if (head == node) {
					head = head.next;
				} else if (tail == node) {
					tail = prev;
					tail.next = null;
				} else {
					prev.next = node.next;
				}

				node.data = null;
				node.next = null;
				node = null;
				size--;

				return true;
			}
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final T... a) {
		final int origSize = size;

		for (T t : a) {
			remove(t);
		}

		return origSize != size;
	}

	@Override
	public final boolean removeAll(final Collection<?> c) {
		final int origSize = size;

		for (Object obj : c) {
			remove(obj);
		}

		return origSize != size;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		for (Node<T> i = head; i != null; i = i.next) {
			if (Safe.equals(i.data, o)) {
				i.data = n;
				return true;
			}
		}

		return false;
	}

	@Override
	public final boolean retainAll(final Collection<?> c) {
		if (c != null && c.size() > 0) {
			final int origSize = size;
			Node<T> toDelete;

			for (Node<T> prev = null, node = head; node != null; ) {
				if (!c.contains(node.data)) {
					toDelete = node;

					if (head == node) {
						head = head.next;
						node = head;
					} else if (tail == node) {
						tail = prev;
						tail.next = null;
					} else {
						prev.next = node.next;
						node = node.next;
					}

					toDelete.data = null;
					toDelete.next = null;
					toDelete = null;
					size--;
				} else {
					prev = node;
					node = node.next;
				}
			}

			return origSize != size;
		}

		return false;
	}

	@Override
	public final T set(final int i, final T t) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		Node<T> n = head;
		for (int j=0; j < i; j++, n = n.next);

		final T oldValue = n.data;
		n.data = t;
		return oldValue;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final void shuffle() {
		if (size > 1) {
			int i=0;

			// 1. Create an array of Nodes to make this easier to implement
			final Node<T>[] nodes = new Node[size];
			for (Node<T> z = head; z != null; z = z.next) {
				nodes[i++] = z;
			}

			// 2. Shuffle the data elements
			for (i=0; i < size; i++) {
				final int j = Random.nextIndex(size);
				final T t = nodes[i].data;
				nodes[i].data = nodes[j].data;
				nodes[j].data = t;
			}
		}
	}

	@Override
	public final int size() {
		return size;
	}

	@Override
	public final ListLinked<T> subList(final int from) {
		return subList(from, size);
	}

	@Override
	public final ListLinked<T> subList(final int from, final int to) {
		if (from >= to || from < 0 || to < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final ListLinked<T> l = new ListLinked<T>();

		int j=0;
		Node<T> n = head;
		for (; j < from; j++, n = n.next);

		for (; j < to; j++, n = n.next) {
			l.add(n.data);
		}

		return l;
	}

	@Override
	public final SetHashed<T> subset(final int from) {
		return subset(from, size);
	}

	@Override
	public final SetHashed<T> subset(final int from, final int to) {
		if (from >= to || from < 0 || to < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		final SetHashed<T> s = new SetHashed<T>(to-from);

		int j=0;
		Node<T> n = head;
		for (; j < from; j++, n = n.next);

		for (; j < to; j++, n = n.next) {
			s.add(n.data);
		}

		return s;
	}

	@Override
	public final T[] toArray() {
		final T[] array = Clean.newArray(size);
		Node<T> node = head;

		for (int i=0; i < size; i++, node = node.next) {
			array[i] = node.data;
		}

		return array;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final <E> E[] toArray(final E[] arrayParam) {
		final E[] array = Clean.newArray(arrayParam, size);
		Node<T> node = head;

		for (int i=0; i < size; i++, node = node.next) {
			array[i] = (E) node.data;
		}

		return array;
	}

	@Override
	public final SetHashed<T> toSet() {
		return subset(0, size);
	}

	@Override
	public final String toString() {
		return Node.toString(head, size);
	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	private final class ListLinkedItemizer implements ListItemizer<T> {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private int currentIndex;
		private Node<T> currentPos;
		private final int startingPoint;
		private final Node<T> startingNode;

		// <><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><>

		private ListLinkedItemizer(final int startingPoint) {
			currentIndex = startingPoint;
			this.startingPoint = startingPoint;

			Node<T> node = head;
			for (int i=1; i < startingPoint; i++, node = node.next);

			this.currentPos = node;
			this.startingNode = node;
		}

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		@Override
		public final void add(final T t) {
			ListLinked.this.add(currentIndex++, t);
		}

		@Override
		public final int getIndex() {
			return currentIndex-1;
		}

		@Override
		public final int getSize() {
			return size;
		}

		@Override
		public final boolean hasNext() {
			return currentIndex < size;
		}

		@Override
		public final boolean hasPrevious() {
			throw new UnsupportedOperationException("Cannot traverse a ListLinked in reverse");
		}

		@Override
		public final ListItemizer<T> iterator() {
			return this;
		}

		@Override
		public final T next() {
			if (currentIndex == size) {
				throw new NoSuchElementException();
			}

			final Node<T> node = currentPos;
			currentPos = currentPos.next;
			currentIndex++;

			return node.data;
		}

		@Override
		public final int nextIndex() {
			return currentIndex;
		}

		@Override
		public final T previous() {
			throw new UnsupportedOperationException("Cannot traverse a ListLinked in reverse");
		}

		@Override
		public final int previousIndex() {
			return currentIndex;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final void reset() {
			currentIndex = startingPoint;
			currentPos = startingNode;
		}

		@Override
		public final void set(final T t) {
			currentPos.data = t;
		}

	}	// End ListLinkedItemizer

}	// End ListLinked
