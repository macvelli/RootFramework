/*
 * QueueBoundedByte.java
 * 
 * Last Modified: 02/24/2016
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Itemizer;

/**
 * 	- TODO Covert every method in this class to use the primitive byte instead of the object Byte
 * 	- TODO Everything needs to implement Externalizable where possible
 * 	- TODO Take the incHead() and incTail() methods to all other array-based data structures that use inc()
 * 	- TODO Put braces around all one-line statements
 * 	- TODO Add isFull() method to other existing bounded implementations
 * 	- TODO Convert other bounded implementations to use new exception classes that are uses in here
 * 
 * @author esmith
 * @version 1.0
 */
public class QueueBoundedByte implements Bounded, RootQueue<Byte> {

	// Attributes

	private int head;
	private int tail;
	private int size;

	private final byte[] queue;

	// Constructors

	public QueueBoundedByte(final int capacity) {
		this.queue = new byte[capacity];
	}

	// Public Methods

	@Override
	public final void clear() {
		head = 0;
		tail = 0;
		size = 0;
	}

	@Override
	public final Byte dequeue() {
		if (size == 0) {
			throw new DataStructureEmptyException();
		}

		final byte b = queue[head];
		incHead();
		size--;

		return b;
	}

	/**
	 * 
	 * 
	 * @param byteArray
	 * @throws DataStructureInsufficientSizeException
	 */
	public final void dequeue(final byte[] byteArray) {
		if (size < byteArray.length) {
			throw new DataStructureInsufficientSizeException(byteArray.length, size);
		}

		int newHead = head + byteArray.length;

		if (newHead < queue.length) {
			System.arraycopy(queue, head, byteArray, 0, byteArray.length);
		} else {
			final int firstCopyLen = queue.length - head;
			newHead = byteArray.length - firstCopyLen;

			System.arraycopy(queue, head, byteArray, 0, firstCopyLen);
			System.arraycopy(queue, 0, byteArray, firstCopyLen, newHead);
		}

		head = newHead;
		size -= byteArray.length;
	}

	@Override
	public final void enqueue(final Byte b) {
		if (size == queue.length) {
			throw new DataStructureFullException();
		}

		queue[tail] = b;
		incTail();
		size++;
	}

	/**
	 * 
	 * 
	 * @param i
	 * @throws DataStructureInsufficientCapacityException
	 */
	public final void enqueue(final int i) {
		if (4 > getCapacity()) {
			throw new DataStructureInsufficientCapacityException(4, getCapacity());
		}

		if ((queue.length - tail) < 4) {
			queue[tail] = (byte)(i >>> 24);
			incTail();
			queue[tail] = (byte)(i >>> 16);
			incTail();
			queue[tail] = (byte)(i >>> 8);
			incTail();
		} else {
			queue[tail++] = (byte)(i >>> 24);
			queue[tail++] = (byte)(i >>> 16);
			queue[tail++] = (byte)(i >>> 8);
		}

		// Can always increment tail directly for last byte
		queue[tail++] = (byte)i;

		size += 4;		
	}

	/**
	 * 
	 * 
	 * @param byteArray
	 * @throws DataStructureInsufficientCapacityException
	 */
	public final void enqueue(final byte[] byteArray) {
		if (byteArray.length > getCapacity()) {
			throw new DataStructureInsufficientCapacityException(byteArray.length, getCapacity());
		}

		int newTail = tail + byteArray.length;

		if (newTail < queue.length) {
			System.arraycopy(byteArray, 0, queue, tail, byteArray.length);
		} else {
			final int firstCopyLen = queue.length - tail;
			newTail = byteArray.length - firstCopyLen;

			System.arraycopy(byteArray, 0, queue, tail, firstCopyLen);
			System.arraycopy(byteArray, firstCopyLen, queue, 0, newTail);
		}

		tail = newTail;
		size += byteArray.length;		
	}

	/**
	 * 
	 * 
	 * @param intArray
	 * @throws DataStructureInsufficientCapacityException
	 */
	public final void enqueue(final int[] intArray) {
		final int numBytesToEnqueue = intArray.length << 2;
		if (numBytesToEnqueue > getCapacity()) {
			throw new DataStructureInsufficientCapacityException(numBytesToEnqueue, getCapacity());
		}

		for (int i : intArray) {
			if ((queue.length - tail) < 4) {
				queue[tail] = (byte)(i >>> 24);
				incTail();
				queue[tail] = (byte)(i >>> 16);
				incTail();
				queue[tail] = (byte)(i >>> 8);
				incTail();
			} else {
				queue[tail++] = (byte)(i >>> 24);
				queue[tail++] = (byte)(i >>> 16);
				queue[tail++] = (byte)(i >>> 8);
			}

			// Can always increment tail directly for last byte
			queue[tail++] = (byte)i;
		}

		size += numBytesToEnqueue;
	}

	public final int getCapacity() {
		return queue.length-size;
	}

	@Override
	public final Collection<Byte> getCollection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final Itemizer<Byte> getDescending() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final boolean isFull() {
		return size == queue.length;
	}

	@Override
	public Itemizer<Byte> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final Byte peek() {
		if (size == 0) {
			throw new DataStructureEmptyException();
		}

		return queue[head];
	}

	// Private Methods

	private void incHead() {
		if (++head == queue.length) {
			head = 0;
		}
	}

	private void incTail() {
		if (++tail == queue.length) {
			tail = 0;
		}
	}

}	// End QueueBoundedByte
