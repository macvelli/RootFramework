package root.data.structure;

import root.lang.Builder;

public final class MapBuilder<K, V> implements Builder {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final MapHashed<K, V> map;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public MapBuilder() {
		map = new MapHashed<>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final MapImmutable<K, V> build() {
		return new MapImmutable<>(map.clone());
	}

	public final MapBuilder<K, V> put(final K key, final V value) {
		map.put(key, value);
		return this;
	}

}
