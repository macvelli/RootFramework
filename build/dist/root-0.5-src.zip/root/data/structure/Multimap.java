package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * Not quite a faithful implementation of root.data.structure.Map but gets
 * the job done for a Multimap.
 * 
 * TODO
 * 		+ Implement Cloneable
 * 		+ Compare to Guava (done)
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public class Multimap<K, V> implements Itemizable<MapEntry<K, ListArray<V>>> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 3222099690647925468L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private int	size;
	private final MapHashed<K, ListArray<V>> map;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Multimap() {
		map = new MapHashed<>();
	}

	public Multimap(final int capacity) {
		map = new MapHashed<>(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		MapEntry<K, ListArray<V>> next;

		for (int i=0; i < map.table.length; i++) {
			for (MapEntry<K, ListArray<V>> e = map.table[i]; e != null; e = next) {
				next = e.next;
				e.value.clear();
				e.value = null;
				e.next = null;
			}
			map.table[i] = null;
		}

		size = 0;
	}

	@Override
	public final Collection<MapEntry<K, ListArray<V>>> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<MapEntry<K, ListArray<V>>> getDescending() {
		return map.getDescending();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<MapEntry<K, ListArray<V>>> iterator() {
		return map.iterator();
	}

	public final boolean containsKey(final K key) {
		return map.containsKey(key);
	}

	public final boolean containsValue(final V value) {
		for (int i=0; i < map.table.length; i++) {
			for (MapEntry<K, ListArray<V>> e = map.table[i]; e != null; e = e.next) {
				if (e.value.contains(value)) {
					return true;
				}
			}
		}

		return false;
	}

	public final boolean containsValue(final K key, final V value) {
		for (MapEntry<K, ListArray<V>> e = map.table[Safe.hashCode(key) % map.table.length]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				return e.value.contains(value);
			}
		}

		return false;
	}

	@Override
	public final boolean equals(final Object o)  {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof Multimap)) {
			return false;
		}

		final Multimap<?, ?> m = (Multimap<?, ?>) o;
		if (m.size != size) {
			return false;
		}

		return m.map.equals(map);
	}

	public final ListArray<V> get(final K key) {
		return map.get(key);
	}

	public final V get(final K key, final int index) {
		final ListArray<V> list = map.get(key);

		return (list == null) ? null : list.get(index);
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (MapEntry<K, ListArray<V>> e : this) {
			h ^= e.hash;
			h ^= e.value.hashCode();
			h <<= 1;
		}

		return h;
	}

	public final void put(final K key, final V value) {
		ListArray<V> list = map.get(key);

		if (list == null) {
			list = new ListArray<>();
			map.put(key, list);
		}

		list.add(value);
		size++;
	}

	public final void put(final K key, final Iterable<? extends V> value) {
		ListArray<V> list = map.get(key);

		if (list == null) {
			list = new ListArray<>();
			map.put(key, list);
		}

		for (V v : value) {
			list.add(v);
			size++;
		}
	}

	public final ListArray<V> remove(final K key) {
		final ListArray<V> list = map.remove(key);

		if (list != null) {
			size -= list.size;
		}

		return list;
	}

	public final boolean remove(final K key, final V value) {
		final ListArray<V> list = map.get(key);

		if (list != null && list.remove(value)) {
			if (list.isEmpty()) {
				map.remove(key);
			}
			size--;

			return true;
		}

		return false;
	}

	@Override
	public String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('{');
		if (size > 0) {
			for (int i=0; i < map.table.length; i++) {
				for (MapEntry<K, ListArray<V>> e = map.table[i]; e != null; e = e.next) {
					builder.separator(1).append(e.key).append('=');
					builder.append('[');
					final int start = builder.getLength();
					for (int j=0; j < e.value.size; j++) {
						builder.separator(start).append(e.value.values[j]);
					}
					builder.append(']');
				}
			}
		}
		builder.append('}');

		return builder.toString();
	}

}
