/*
 * Graph.java
 */
package root.data.structure;

import root.data.validation.InvalidParameterException;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * http://www.dreamincode.net/forums/topic/377473-graph-data-structure-tutorial/
 * 
 * This class models a directed graph. Vertices are identified uniquely by
 * their labels, and only unique vertices are allowed. At most one {@link Edge}
 * per vertex pair is allowed in this {@link Graph}.
 * <p>
 * An {@link Edge} defines an origin vertex, a destination vertex, and a
 * weight. If you want to define a reflexive path between two verticies, you
 * must add an edge in each direction.
 * <p>
 * Note that the {@link Graph} is designed to manage the {@link Edge}s. You
 * should not attempt to manually manage {@link Edge}s yourself.
 * 
 * @author Michael Levet
 * @author Edward Smith
 * @version 0.5
 */
public class Graph {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final MapHashed<String, Vertex> vertexMap;
	private final SetHashed<Edge> edgeSet;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public Graph() {
		this.vertexMap = new MapHashed<String, Vertex>();
		this.edgeSet = new SetHashed<Edge>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void addAll(final String... vertexLabels) {
		addAll(1, vertexLabels);
	}

	public final void addAll(final int weight, final String... vertexLabels) {
		if (vertexLabels != null && vertexLabels.length > 1) {
			for (int originIndex = 0, destinationIndex = 1; destinationIndex < vertexLabels.length; originIndex++, destinationIndex++) {
				addEdge(vertexLabels[originIndex], vertexLabels[destinationIndex], weight);
			}
		}
	}

	/**
	 * This method adds an {@link Edge} between the origin and destination
	 * vertices of weight 1, iff no {@link Edge} between these vertices already
	 * exists in the {@link Graph}.
	 * 
	 * @param originVertexLabel
	 *            The label for the origin {@link Vertex}
	 * @param destinationVertexLabel
	 *            The label for the destination {@link Vertex}
	 * @return true iff no {@link Edge} relating origin and destination exists
	 *         in the {@link Graph}
	 */
	public final boolean addEdge(final String originVertexLabel, final String destinationVertexLabel) {
		return addEdge(originVertexLabel, destinationVertexLabel, 1);
	}

	/**
	 * Accepts origin and destination label vertices and a weight, and adds the
	 * {@link Edge} ({origin, destination}, weight) iff no {@link Edge}
	 * relating origin and destination exists in the {@link Graph}.
	 * 
	 * @param originVertexLabel
	 *            The label for the origin {@link Vertex}
	 * @param destinationVertexLabel
	 *            The label for the destination {@link Vertex}
	 * @param weight
	 *            The weight of the {@link Edge}
	 * @return true iff no {@link Edge} relating origin and destination exists
	 *         in the {@link Graph}
	 */
	public final boolean addEdge(final String originVertexLabel, final String destinationVertexLabel, final int weight) {
		if (Safe.equals(originVertexLabel, destinationVertexLabel)) {
			return false;
		}

		Vertex originVertex = vertexMap.get(originVertexLabel);
		Vertex destinationVertex = vertexMap.get(destinationVertexLabel);

		if (originVertex == null) {
			originVertex = new Vertex(originVertexLabel);
			vertexMap.put(originVertexLabel, originVertex);
		}

		if (destinationVertex == null) {
			destinationVertex = new Vertex(destinationVertexLabel);
			vertexMap.put(destinationVertexLabel, destinationVertex);
		}

		// Ensure the Edge is not already in the Graph
		final Edge e = new Edge(originVertex, destinationVertex, weight);
		if (edgeSet.contains(e)) {
			return false;
		}

		edgeSet.add(e);
		originVertex.addEdge(e);
		destinationVertex.addEdge(e);
		return true;
	}

	/**
	 * TODO: I don't see the value in this method
	 *  
	 * This method removes the specified Edge from the Graph, including as each
	 * vertex's incidence neighborhood.
	 * 
	 * @param e
	 *            The Edge to remove from the Graph
	 */
	public final void removeEdge(final Edge e) {
		e.remove();
		this.edgeSet.remove(e);
	}

	/**
	 * 
	 * @param label
	 *            The specified {@link Vertex} label
	 * @return The {@link Vertex} associated with the specified label
	 */
	public final Vertex getVertex(final String label) {
		return vertexMap.get(label);
	}

	/**
	 * 
	 * @param label
	 *            The label of the {@link Vertex} to remove
	 */
	public final void removeVertex(final String label) {
		final Vertex v = vertexMap.remove(label);

		if (v != null) {
			v.clearEdges();
		}
	}

	/**
	 * 
	 * @param vertex
	 *            The {@link Vertex} to remove
	 */
	public final void removeVertex(final Vertex vertex) {
		if (vertex != null) {
			removeVertex(vertex.label);
		}
	}

	/**
	 * This class models a {@link Vertex} in a {@link Graph}. For ease of the
	 * reader, a label for this {@link Vertex} is required. Note that the
	 * {@link Graph} object only accepts one {@link Vertex} per label, so
	 * uniqueness of labels is important. A {@link Vertex} keeps track of all
	 * origin and destination {@link Edge}s associated with it.
	 * 
	 * @author Michael Levet
	 * @author Edward Smith
	 */
	public class Vertex {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private final String label;
		private final ListArray<Edge> originList;
		private final ListArray<Edge> destinationList;

		// <><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><>

		/**
		 * 
		 * @param label
		 *            The unique label associated with this {@link Vertex}
		 */
		private Vertex(final String label) {
			this.label = label;
			this.originList = new ListArray<Edge>();
			this.destinationList = new ListArray<Edge>();
		}

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		/**
		 * 
		 * @return The {@link Itemizer} of destination {@link Edge}s
		 */
		public final Itemizer<Edge> getDestinationEdges() {
			return destinationList.iterator();
		}

		/**
		 * 
		 * @param weight
		 * @return The destination {@link Edge} with the specified <code>weight</code>
		 */
		public final Edge getDestinationEdgeWithWeight(final int weight) {
			for (Edge e : destinationList) {
				if (e.weight == weight) {
					return e;
				}
			}

			return null;
		}

		/**
		 * 
		 * @return The label of this {@link Vertex}
		 */
		public final String getLabel() {
			return this.label;
		}

		/**
		 * 
		 * @return The {@link Itemizer} of origin {@link Edge}s
		 */
		public final Itemizer<Edge> getOriginEdges() {
			return originList.iterator();
		}

		/**
		 * 
		 * @param weight
		 * @return The origin {@link Edge} with the specified <code>weight</code>
		 */
		public final Edge getOriginEdgeWithWeight(final int weight) {
			for (Edge e : originList) {
				if (e.weight == weight) {
					return e;
				}
			}

			return null;
		}

		/**
		 * TODO: This needs to show all the edges where this Vertex is origin as well as all edges where this Vertex is destination
		 * 
		 * @return A {@link String} representation of this {@link Vertex}
		 */
		public final String toString() {
			return "Vertex: " + label;
		}

		/**
		 * 
		 * @return The hash code of this {@link Vertex}
		 */
		public final int hashCode() {
			return Safe.hashCode(this.label);
		}

		/**
		 * 
		 * @param other
		 *            The {@link Object} to compare
		 * @return <code>true</code> iff other is a {@link Vertex} and other
		 *         has the same label as this {@link Vertex}
		 */
		public final boolean equals(final Object other) {
			if (Safe.notEqual(other, Vertex.class)) {
				return false;
			}

			final Vertex v = (Vertex) other;
			return Safe.equals(this.label, v.label);
		}

		// <><><><><><><><><><><><><> Private Methods ><><><><><><><><><><><><>

		/**
		 * This method adds an {@link Edge} to this {@link Vertex} of the
		 * {@link Graph} iff the {@link Edge} is not already present on this
		 * {@link Vertex}.
		 * 
		 * @param edge
		 *            The {@link Edge} to add
		 */
		private void addEdge(final Edge edge) {
			if (Safe.equals(edge.origin, this)) {
				originList.add(edge);
			} else if (Safe.equals(edge.destination, this)) {
				destinationList.add(edge);
			} else {
				throw new InvalidParameterException("addEdge", "Edge", "edge", "This Vertex {" + this.label + "} is neither an origin nor destination for Edge " + edge);
			}
		}

		/**
		 * Clears all {@link Edge}s related to this {@link Vertex}.
		 */
		private void clearEdges() {
			originList.clear();
			destinationList.clear();
		}

	} // End Vertex

	/**
	 * This class models a directed {@link Edge} in the {@link Graph}
	 * implementation. An {@link Edge} contains two vertices and a weight.
	 * <p>
	 * This class also deviates from the expectations of the {@link Comparable}
	 * interface in that a return value of <code>0</code> does not indicate
	 * that <code>this.equals(other)</code>. The <code>equals()</code> method
	 * only compares the vertices, while the <code>compareTo()</code> method
	 * compares the edge weights. This provides more efficient implementation
	 * for checking uniqueness of edges, as well as the fact that two edges of
	 * equal weight should be considered equitably in a path-finding or
	 * spanning tree algorithm.
	 * 
	 * @author Michael Levet
	 * @author Edward Smith
	 */
	public class Edge implements Comparable<Edge> {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private final Vertex origin, destination;
		private int weight;

		// <><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><>

		/**
		 * 
		 * @param originVertex
		 *            The origin vertex in the {@link Edge}
		 * @param destinationVertex
		 *            The destination vertex in the {@link Edge}
		 * @param weight
		 *            The weight of this {@link Edge}
		 */
		private Edge(final Vertex originVertex, final Vertex destinationVertex, final int weight) {
			this.origin = originVertex;
			this.destination = destinationVertex;
			this.weight = weight;
		}

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		/**
		 * 
		 * @return The destination {@link Vertex} of this {@link Edge}
		 */
		public final Vertex getDestination() {
			return this.destination;
		}

		/**
		 * 
		 * @return The origin {@link Vertex} of this {@link Edge}
		 */
		public final Vertex getOrigin() {
			return this.origin;
		}

		/**
		 * 
		 * @return The weight of this {@link Edge}
		 */
		public final int getWeight() {
			return this.weight;
		}

		/**
		 * 
		 * @param weight
		 *            The weight to assign to this {@link Edge}
		 */
		public final void setWeight(final int weight) {
			this.weight = weight;
		}

		/**
		 * Note that the <code>compareTo()</code> method deviates from the
		 * specifications in the {@link Comparable} interface. A return value
		 * of <code>0</code> does not indicate that <code>this.equals(other)</code>.
		 * The <code>equals()</code> method checks the {@link Vertex} endpoints,
		 * while the <code>compareTo()</code> is used to compare {@link Edge}
		 * weights.
		 * 
		 * @param other
		 *            The {@link Edge} to compare against this {@link Edge}
		 * @return <code>this.weight - other.weight</code>
		 */
		public final int compareTo(final Edge other) {
			if (Safe.notEqual(this.origin, other.origin) && Safe.notEqual(this.destination, other.destination)) {
				throw new InvalidParameterException("compareTo", "Edge", "other", "This Edge " + this + " has neither a common origin or destination Vertex for Edge " + other);
			}

			return this.weight - other.weight;
		}

		/**
		 * 
		 * @return A {@link String} representation of this {@link Edge}
		 */
		public final String toString() {
			return new ParamStrBuilder(20 + origin.label.length() + destination.label.length())
					.append('(','{').append(origin.label)
					.append(',',' ').append(destination.label)
					.append('}',',',' ').append(weight).append(')').toString();
		}

		/**
		 * 
		 * @return The hash code for this {@link Edge}
		 */
		public final int hashCode() {
			return Safe.hashCode(origin) ^ Safe.hashCode(destination);
		}

		/**
		 * 
		 * @param other
		 *            The {@link Object} to compare against this {@link Edge}
		 * @return <code>true</code> iff other is an {@link Edge} with the same
		 *         vertices as this {@link Edge}
		 */
		public final boolean equals(final Object other) {
			if (Safe.notEqual(other, Edge.class)) {
				return false;
			}

			final Edge e = (Edge) other;
			return Safe.equals(this.origin, e.origin) && Safe.equals(this.destination, e.destination);
		}

		// <><><><><><><><><><><><><> Private Methods ><><><><><><><><><><><><>

		/**
		 * This method removes the {@link Edge} from both the origin and
		 * destination verticies.
		 */
		private void remove() {
			origin.originList.remove(this);
			destination.destinationList.remove(this);
		}

	} // End Edge

	public static void main(String[] args) {
		final Graph navigationGraph = new Graph();

		// Add all prequal.purchase.workflow.screens
		navigationGraph.addAll("borrowerinfo","propertyinfo","pricing","pricingproduct","login","addressinfo","legalconsent","ssninfo","creditpullesignature","creditpullesignatureconfirmation","creditreportpayment","creditreportpaymentconfirmation","assets","expensessummary","income","appproduct","hmda","declaration","reo","employmentinfo","employmentsummary","personaldetails","addresshistory","subjectpropertydetails","subjectpropertyclosing","subjectpropertytransaction","dashboard");

		// Add all application.purchase.workflow.screens TODO: These need weights specific to application purchase navigation
		navigationGraph.addEdge("creditreportpaymentconfirmation","appproduct");
		navigationGraph.addEdge("declaration","assets");
		navigationGraph.addEdge("income","reo");

		// Add all application.refinance.workflow.screens TODO: These need weights specific to application refinance navigation
		navigationGraph.addEdge("creditreportpaymentconfirmation","hmda");
//		navigationGraph.addEdge("declaration","assets");	// TODO: This is covered by previous navigation flow, but might need weight specific to this logical navigation condition (or business rules can derive the correct weight for the given context)
//		navigationGraph.addEdge("income","reo");			// TODO: This is covered by previous navigation flow, but might need weight specific to this logical navigation condition (or business rules can derive the correct weight for the given context)
		navigationGraph.addEdge("subjectpropertyclosing","dashboard");

		Vertex currentScreen = navigationGraph.getVertex("pricing");
		Itemizer<Edge> possibleNextScreens = currentScreen.getOriginEdges();
		if (possibleNextScreens.getSize() == 1) {
			System.out.println(possibleNextScreens.next());
		}
	}

}	// End Graph
