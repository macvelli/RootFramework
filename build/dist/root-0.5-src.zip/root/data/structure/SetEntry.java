/*
 * SetEntry.java
 */
package root.data.structure;

import root.util.Fast;

/**
 * 
 * @author Edward Smith
 * @version 0.5
 * 
 * @param <K>
 */
class SetEntry<K> {

	// <><><><><><><><><><><><><><> Static Methods <><><><><><><><><><><><><><>

	@SuppressWarnings("unchecked")
	static final <T> SetEntry<T>[] newArray(final int capacity) {
		return new SetEntry[Fast.hashTableSize(capacity)];
	}

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	final K key;
	final int hash;
	SetEntry<K> next;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	SetEntry(final K key, final int h, final SetEntry<K> next) {
		this.key = key;
		this.hash = h;
		this.next = next;
	}

}	// End SetEntry
