package root.data.structure;

class MapEntry<K, V> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 8847867060549351982L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	final K key;
	V value;
	final int hash;
	MapEntry<K, V> next;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	MapEntry(final K key, final V value, final int h, final MapEntry<K, V> next) {
		this.key = key;
		this.value = value;
		this.hash = h;
		this.next = next;
	}

	public final K getKey() {
		return key;
	}

	public final V getValue() {
		return value;
	}

}
