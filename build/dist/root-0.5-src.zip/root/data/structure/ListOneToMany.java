/*
 * ListOneToMany.java
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Affiliate;
import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;

/**
 * Only useful for situations where you have domain objects auto-generated
 * with a default constructor yet you still want to wire the class on the 
 * 1-side of the relationship to the affiliate class on the N-side.
 * 
 * TODO
 * 		+ Implement equals() and hashCode() motherfucker
 * 
 * @author esmith
 *
 * @param <O>
 * @param <M>
 */
public class ListOneToMany<O, M extends Affiliate<O>> implements RootList<M> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final O one;
	private final ListArray<M> list;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ListOneToMany(final O one) {
		this.one = one;
		this.list = new ListArray<>();
	}

	public ListOneToMany(final O one, final int capacity) {
		this.one = one;
		this.list = new ListArray<>(capacity);
	}

	private ListOneToMany(final O one, final ListArray<M> list) {
		this.one = one;
		this.list = list;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean add(final M m) {
		m.associate(one);
		list.add(m);
		return true;
	}

	@Override
	public final void add(final int index, final M m) {
		m.associate(one);
		list.add(index, m);
	}

	@Override
	@SafeVarargs
	public final void addAll(final M... a) {
		for (M m : a) {
			m.associate(one);
		}

		list.addAll(a);
	}

	@Override
	public final boolean addAll(final Collection<? extends M> c) {
		for (M m : c) {
			m.associate(one);
		}

		return list.addAll(c);
	}

	@Override
	public final boolean addAll(final int index, final Collection<? extends M> c) {
		for (M m : c) {
			m.associate(one);
		}

		return list.addAll(index, c);
	}

	/**
	 * This is a prime example of why it is good to know how your data
	 * structures operate.  There is no benefit to call list.addAll()
	 * in this situation so we just go ahead and call list.add() when
	 * processing M objects.
	 */
	@Override
	public final void addAll(final Iterable<? extends M> c) {
		for (M m : c) {
			m.associate(one);
			list.add(m);
		}
	}

	@Override
	public final void clear() {
		list.clear();
	}

	@Override
	public final boolean contains(final Object obj) {
		return list.contains(obj);
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final M... a) {
		return list.containsAll(a);
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		return list.containsAll(c);
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final M... a) {
		return list.containsAny(a);
	}

	@Override
	public final boolean containsAny(final Iterable<? extends M> c) {
		return list.containsAny(c);
	}

	@Override
	public final M echo(final M m) {
		m.associate(one);
		return list.echo(m);
	}

	@Override
	public final boolean equals(final Object o) {
		throw new UnsupportedOperationException();
	}

	@Override
	public final M get(final int i) {
		return list.get(i);
	}

	@Override
	public final Collection<M> getCollection() {
		return list.getCollection();
	}

	@Override
	public final Itemizer<M> getDescending() {
		return list.getDescending();
	}

	@Override
	public final int getSize() {
		return list.getSize();
	}

	@Override
	public final int hashCode() {
		throw new UnsupportedOperationException();
	}

	@Override
	public final int indexOf(final Object obj) {
		return list.indexOf(obj);
	}

	@Override
	public final void insert(final int i, final M m) {
		list.insert(i, m);
		m.associate(one);
	}

	@Override
	@SafeVarargs
	public final void insertAll(final int i, final M... a) {
		list.insertAll(i, a);
		for (M m : a) {
			m.associate(one);
		}
	}

	@Override
	public final void insertAll(final int i, final Itemizable<? extends M> c) {
		list.insertAll(i, c);
		for (M m : c) {
			m.associate(one);
		}
	}

	@Override
	public final void insertAll(final int i, final Iterable<? extends M> c) {
		list.insertAll(i, c);
		for (M m : c) {
			m.associate(one);
		}
	}

	@Override
	public final boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public final Itemizer<M> iterator() {
		return list.iterator();
	}

	@Override
	public final M last() {
		return list.last();
	}

	@Override
	public final int lastIndexOf(final Object obj) {
		return list.lastIndexOf(obj);
	}

	@Override
	public final ListItemizer<M> listIterator() {
		return list.listIterator();
	}

	@Override
	public final ListItemizer<M> listIterator(final int index) {
		return list.listIterator(index);
	}

	@Override
	public final M random() {
		return list.random();
	}

	@Override
	public final M remove(final int i) {
		return list.remove(i);
	}

	@Override
	public final boolean remove(final Object obj) {
		return list.remove(obj);
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final M... array) {
		return list.removeAll(array);
	}

	@Override
	public final boolean removeAll(final Collection<?> c) {
		return list.removeAll(c);
	}

	@Override
	public final boolean replace(final M o, final M n) {
		final boolean success = list.replace(o, n);

		if (success) {
			n.associate(one);
		}

		return success;
	}

	@Override
	public final boolean retainAll(final Collection<?> c) {
		return list.retainAll(c);
	}

	@Override
	public final M set(final int i, final M m) {
		final M oldValue = list.set(i, m);
		m.associate(one);
		return oldValue;
	}

	@Override
	public final void shuffle() {
		list.shuffle();
	}

	@Override
	public final int size() {
		return list.size;
	}

	@Override
	public final ListOneToMany<O, M> subList(final int from) {
		return new ListOneToMany<O, M>(one, list.subList(from));
	}

	@Override
	public final ListOneToMany<O, M> subList(final int from, final int to) {
		return new ListOneToMany<O, M>(one, list.subList(from, to));
	}

	@Override
	public final SetHashed<M> subset(final int from) {
		return list.subset(from);
	}

	@Override
	public final SetHashed<M> subset(final int from, final int to) {
		return list.subset(from, to);
	}

	@Override
	public final M[] toArray() {
		return list.toArray();
	}

	@Override
	public final <E> E[] toArray(final E[] array) {
		return list.toArray(array);
	}

	@Override
	public final SetHashed<M> toSet() {
		return list.subset(0, list.size);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(list.size << 4);

		builder.append(one).append('\n');
		builder.append('[');
		final int start = builder.getLength();
		for (int i=0; i < list.size; i++) {
			builder.separator(start).append(list.values[i]);
		}
		builder.append(']');

		return builder.toString();
	}

}	// End ListOneToMany
