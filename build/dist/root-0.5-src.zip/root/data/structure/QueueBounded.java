package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Remove @Override annotations from Queue<T> methods (done)
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 * 		+ Check http://math.hws.edu/eck/cs124/javanotes3/c11/s3.html out for some ideas
 * 		+ http://en.wikipedia.org/wiki/Queue_(data_structure)
 * 		+ http://en.wikipedia.org/wiki/Circular_buffer
 * 		+ Make a BoundedQueue implementation as a circular buffer. The difference is that the buffer is fixed in size.
 * 
 * @author Edward Smith
 * @verison 1.0
 * @date April 28, 2016
 *
 * @param <T>
 */
public class QueueBounded<T> implements Bounded, RootQueue<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int	head;
	private int	tail;
	private int	size;
	private final T[] queue;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public QueueBounded(final int capacity) {
		queue = Clean.newArray(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		for (int j=0; j < size; incHead(), j++) {
			queue[head] = null;
		}

		head = tail = size = 0;
	}

	public final T dequeue() {
		if (size == 0) {
			throw new DataStructureEmptyException();
		}

		final T t = queue[head];
		queue[head] = null;
		incHead();
		size--;

		return t;
	}

	public final void enqueue(final T t) {
		if (size == queue.length) {
			throw new DataStructureFullException();
		}

		queue[tail] = t;
		incTail();
		size++;
	}

	public final int getCapacity() {
		return queue.length-size;
	}

	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Descend();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final boolean isFull() {
		return size == queue.length;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	public final T peek() {
		return queue[head];
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		for (int i=head, j=0; j < size; i = inc(i), j++) {
			builder.separator(1).append(queue[i]);
		}
		builder.append(']');

		return builder.toString();
	}

	// <><><><><><><><><><><><><><> Private Methods ><><><><><><><><><><><><><>

	private void incHead() {
		if (++head == queue.length) {
			head = 0;
		}
	}

	private void incTail() {
		if (++tail == queue.length) {
			tail = 0;
		}
	}

	private int inc(int i) {
		return (++i == queue.length) ? 0 : i;
	}

	// <><><><><><><><><><><><><><> Private Classes ><><><><><><><><><><><><><>

	private class Ascend implements Itemizer<T> {

		private int i = head, j;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			final T t = queue[i];
			i = inc(i);
			j++;

			return t;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		public final int getIndex() {
			return j;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = head;
			j = 0;
		}

		@Override
		public final int getSize() {
			return size;
		}
		
	}	// End Ascend

	private class Descend implements Itemizer<T> {

		private int i = tail, j;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final T next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			final T t = queue[i];
			i = (--i < 0) ? queue.length-1 : i;
			j++;

			return t;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return j;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = tail;
			j = 0;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Descend

}	// End QueueBounded
