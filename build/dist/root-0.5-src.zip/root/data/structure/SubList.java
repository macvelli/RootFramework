/*
 * SubList.java
 */
package root.data.structure;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.util.Clean;
import root.util.Random;

/**
 * TODO
 * 		+ First, this thing won't work once I take List<T> away from all the list
 * 		  implementations
 * 		+ Second, this thing is fucked up
 * 		+ Third, what can I do for a sub-list view?
 * TODO: This needs a lot of work as some things just won't work properly the way this is currently implemented
 * 
 * @author Edward Smith
 * @version 0.5
 * 
 * @param <T>
 */
class SubList<T> implements RootList<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int size;
	private final int offset;
	private final RootList<T> l;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	SubList(final RootList<T> list, final int fromIndex, final int toIndex) {
//		TODO: Make sure these checks are done before this constructor is called

//		if (fromIndex < 0)
//			throw new IllegalArgumentException("fromIndex = " + fromIndex);
//		if (toIndex > list.getSize())
//			throw new IndexOutOfBoundsException(toIndex, list.getSize());
//		if (fromIndex > toIndex)
//			throw new IllegalArgumentException("fromIndex(" + fromIndex + ") > toIndex(" + toIndex + ")");

        l = list;
        offset = fromIndex;
        size = toIndex - fromIndex;
    }

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean add(final T t) {
		l.insert(size+offset, t);
		size++;
		return true;
	}

	@Override
	public final void add(final int index, final T t) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		l.add(index+offset, t);
		size++;
	}

	@Override
	@SafeVarargs
	public final void addAll(final T... array) {
		if (array != null && array.length > 0) {
			l.insertAll(size+offset, array);
			size += array.length;
		}
	}

	@Override
	public final boolean addAll(final Collection<? extends T> c) {
		if (c != null && c.size() > 0) {
			l.addAll(size+offset, c);
			size += c.size();
			return true;
		}

		return false;
	}

	@Override
	public final boolean addAll(final int index, final Collection<? extends T> c) {
		if (index > size || index < 0) {
			throw new IndexOutOfBoundsException(index, size);
		}

		if (c != null && c.size() > 0) {
			l.addAll(index+offset, c);
			size += c.size();
			return true;
		}

		return false;
	}

	@Override
	public final void addAll(final Iterable<? extends T> c) {
		for (T t : c) {
			l.insert(size+offset, t);
			size++;
		}
	}

	@Override
	public final void clear() {
		for (int i=0; i < size; i++) {
			l.remove(offset);
		}

		size = 0;
	}

	@Override
	public final boolean contains(final Object obj) {
		final int index = l.indexOf(obj);

		return (index >= offset && index < size+offset);
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... array) {
		final int endpoint = size+offset;
		int index;

		for (T t : array) {
			index = l.indexOf(t);

			if (index < offset || index >= endpoint) {
				return false;
			}
		}

		return true;
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		final int endpoint = size+offset;
		int index;

		for (Object obj : c) {
			index = l.indexOf(obj);

			if (index < offset || index >= endpoint) {
				return false;
			}
		}

		return true;
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... array) {
		boolean b = false;

		for (int i=0; i < array.length && !b; i++) {
			b = contains(array[i]);
		}

		return b;
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		boolean b = false;

		for (Iterator<? extends T> i = c.iterator(); i.hasNext() && !b;) {
			b = contains(i.next());
		}

		return b;
	}

	public final Itemizer<T> descending() {
		// TODO: What is this supposed to be?
		return new Descend();
	}

	@Override
	public final T echo(final T e) {
		l.insert(size+offset, e);
		size++;
		return e;
	}

	@Override
	public final T get(final int i) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

        return l.get(i+offset);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public Itemizer<T> getDescending() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int indexOf(final Object obj) {
		final int index = l.indexOf(obj) - offset;

		return (index < 0 || index >= size) ? -1 : index;
	}

	@Override
	public final void insert(final int i, final T t) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		l.insert(i+offset, t);
		size++;
	}

	@Override
	@SafeVarargs
	public final void insertAll(int i, final T... array) {
		for (T t : array) {
			// TODO: There should be a better implementation than this...
			insert(i++, t);
		}
	}

	@Override
	public void insertAll(int i, Iterable<? extends T> c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertAll(int i, Itemizable<? extends T> c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	@Override
	public final T last() {
		return l.get(size+offset);
	}

	@Override
	public final int lastIndexOf(final Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public final ListItemizer<T> listIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final ListItemizer<T> listIterator(final int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final T random() {
        return l.get(Random.nextIndex(size)+offset);
	}

	@Override
	public final T remove(final int i) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		T t = l.remove(i+offset);
		size--;

		return t;
	}

	@Override
	public final boolean remove(final Object obj) {
		// TODO: I don't think this implementation is correct
		final int index = indexOf(obj);

		if (index >= 0) {
			l.remove(index+offset);
			size--;
			return true;
		}

		return false;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(final T... array) {
		boolean b = false;

		for (T t : array) {
			b = b || remove(t);
		}

		return b;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public final boolean replace(final T o, final T n) {
		int i = indexOf(o);

		if (i >= 0) {
			return l.replace(o, n);
		}

		return false;
	}

	@Override
	public final boolean retainAll(final Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public final T set(final int i, final T t) {
		if (i >= size || i < 0) {
			throw new IndexOutOfBoundsException(i, size);
		}

		return l.set(i+offset, t);
	}

	@Override
	public final void shuffle() {
		int i=0, j;
		T z;

		// 1. Create an array of T elements to make this easier to implement
		final T[] elements = Clean.newArray(size);
		for (j = offset; i < size; i++) {
			elements[i] = l.get(j++);
		}

		// 2. Shuffle the element array
		// TODO: Standardize the logic for shuffling an array of elements and put this in Safe/Clean/Fast
		for (i = size; i > 1;) {
			j = Random.nextIndex(i--);
			z = elements[j];
			elements[j] = elements[i];
			elements[i] = z;
		}

		// 3. Reorder the underlying list
		for (i=0, j=offset; i < size; i++) {
			l.set(j++, elements[i]);
		}
	}

	@Override
	public final int size() {
		return size;
	}

	@Override
	public final RootList<T> subList(final int from) {
		return l.subList(from+offset, size+offset);
	}

	@Override
	public final RootList<T> subList(final int from,final int to) {
		return l.subList(from+offset, to+offset);
	}

	public final SubList<T> subListView(final int from) {
		return new SubList<T>(this.l, from+offset, size);
	}

	public final SubList<T> subListView(final int from, final int to) {
		return new SubList<T>(this.l, from+offset, to+offset);
	}

	@Override
	public final RootSet<T> subset(final int from) {
		return subset(from, size);
	}

	@Override
	public final RootSet<T> subset(final int from, final int to) {
		if (from >= to || from < 0) {
			throw new IndexOutOfBoundsException(from, to);
		}

		if (to > size) {
			throw new IndexOutOfBoundsException(to, size);
		}

		// TODO: See if I can create the SetHashed using a SubList Itemizer instead
		final RootSet<T> s = new SetHashed<T>(to-from);

		for (int i=from; i < to; i++) {
			s.add(l.get(i+offset));
		}

		return s;
	}

	@Override
	public final T[] toArray() {
		final T[] array = Clean.newArray(size);
		int i=0, j=0;

		for (T t : l) {
			if (i++ >= offset && j < size) {
				array[j++] = t;
			}
		}

		return array;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final <E> E[] toArray(final E[] arrayParam) {
		final E[] array = Clean.newArray(arrayParam, size);
		int i=0, j=0;

		for (T t : l) {
			if (i++ >= offset && j < size) {
				array[j++] = (E) t;
			}
		}

		return array;
	}

	@Override
	public final RootSet<T> toSet() {
		return subset(0, size);
	}

	@Override
	public final String toString() {
		// TODO: Come up with an appropriate implementation for a SubList
		return super.toString();
	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	private final class Ascend implements Itemizer<T> {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private int i = offset;
		private int endpoint = size+offset;

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		@Override
		public final boolean hasNext() {
			return i < endpoint;
		}

		@Override
		public final T next() {
			if (i == endpoint) {
				throw new NoSuchElementException();
			}

			return l.get(i++);
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return i - offset - 1;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = offset;
			endpoint = size+offset;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Ascend

	private final class Descend implements Itemizer<T> {

		// <><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><>

		private int i;
		private int startpoint;

		// <><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><>

		private Descend() {
			this.i = size+offset;
			this.startpoint = this.i-1;
		}

		// <><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><>

		@Override
		public final boolean hasNext() {
			return i > offset;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final T next() {
			if (i == offset) {
				throw new NoSuchElementException();
			}

			return l.get(--i);
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return startpoint-i;
		}

		@Override
		public final void reset() {
			this.i = size+offset;
			this.startpoint = i-1;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Descend

}	// End SubList
