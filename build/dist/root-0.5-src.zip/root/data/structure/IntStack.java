package root.data.structure;

/**
 * - One problem with primitive type data structures is that you cannot
 *   iterate or itemize over them since Java Generics don't take primitives
 *   as type parameters.
 * 
 * @author esmith
 */
public class IntStack {

	private int head;

	private int[] values;

	public IntStack() {
		head = 8;
		values = new int[8];
	}

	public IntStack(final int capacity) {
		head = (capacity < 8) ? 8 : capacity;
		values = new int[head];
	}

	public void clear() {
		head = values.length;
	}

	public int pop() {
		return values[head++];
	}

	public void push(final int item) {
		if (head == 0) {
			resize();
		}

		values[--head] = item;
	}

	public boolean isEmpty() {
		return head == values.length;
	}

	public int getSize() {
		return values.length - head;
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private void resize() {
		final int[] i = new int[values.length + (values.length >> 1)];
		head = i.length - values.length;
		System.arraycopy(values, 0, i, head, values.length);
		values = i;
	}

}	// End IntStack
