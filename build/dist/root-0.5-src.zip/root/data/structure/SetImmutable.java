/*
 * SetImmutable.java
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Itemizer;
import root.util.Safe;

/**
 * TODO:
 * 		+ See about pulling a SetImmutable out of a SetHashed, though SetHashed is going
 * 		  to need to implement Cloneable in order for it to work properly
 * TODO: What about supporting other types of Sets besides SetHashed (i.e. SetMultiKey)?
 * TODO: This needs a lot of work
 * 
 * @author Edward Smith
 * @version 0.5
 * 
 * @param <T>
 */
public class SetImmutable<T> implements RootSet<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final SetHashed<T> set;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	SetImmutable(final SetHashed<T> set) {
		// TODO: This should call set.clone() right?
		this.set = set;
	}

	@SafeVarargs
	public SetImmutable(final T... a) {
		set = new SetHashed<>(a.length);
		set.addAll(a);
	}

	public SetImmutable(final Iterable<? extends T> c) {
		set = new SetHashed<>();
		set.addAll(c);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public void clear() {
		// TODO DELETE
	}

	@Override
	public boolean add(T e) {
		// TODO DELETE
		return false;
	}

	@Override
	@SafeVarargs
	public final boolean addAll(T... array) {
		// TODO DELETE
		return false;		
	}

	@Override
	public boolean addAll(Collection<? extends T> c) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean addAll(Iterable<? extends T> c) {
		// TODO DELETE
		return false;
	}

	public final boolean contains(final Object obj) {
		return set.contains(obj);
	}

	@Override
	@SafeVarargs
	public final boolean containsAll(final T... a) {
		return set.containsAll(a);
	}

	@Override
	public final boolean containsAll(final Collection<?> c) {
		return set.containsAll(c);
	}

	@Override
	public final boolean containsAll(final Iterable<? extends T> c) {
		return set.containsAll(c);
	}

	@Override
	@SafeVarargs
	public final boolean containsAny(final T... a) {
		return set.containsAny(a);
	}

	@Override
	public final boolean containsAny(final Iterable<? extends T> c) {
		return set.containsAny(c);
	}

	@Override
	public final SetHashed<T> difference(final Iterable<? extends T> c) {
		return set.difference(c);
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof SetImmutable)) {
			return false;
		}

		final SetImmutable<?> s = (SetImmutable<?>) o;
		if (s.set.size != set.size) {
			return false;
		}

objs:	for (SetEntry<?> e : s.set.getSetEntryItemizer()) {
			for (SetEntry<T> n = set.table[e.hash % set.table.length]; n != null; n = n.next) {
				if (Safe.equals(n.key, e.key)) {
					continue objs;
				}
			}

			return false;
		}

		return true;
	}

	@Override
	public final T get(final T e) {
		return set.get(e);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new ImmutableItemizer<>(set.getDescending());
	}

	@Override
	public final int getSize() {
		return set.size;
	}

	@Override
	public final int hashCode() {
		return set.hashCode();
	}

	@Override
	public final SetHashed<T> intersect(final Iterable<? extends T> c) {
		return set.intersect(c);
	}

	@Override
	public final boolean isEmpty() {
		return set.isEmpty();
	}

	@Override
	public final Itemizer<T> iterator() {
		return new ImmutableItemizer<>(set.iterator());
	}

	public boolean remove(Object obj) {
		// TODO DELETE
		return false;
	}

	@Override
	@SafeVarargs
	public final boolean removeAll(T... array) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean removeAll(Iterable<? extends T> c) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean replace(T o, T n) {
		// TODO DELETE
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO DELETE
		return false;
	}

	@Override
	public final int size() {
		return set.size;
	}

	@Override
	public final T[] toArray() {
		return set.toArray();
	}

	@Override
	public final <E> E[] toArray(final E[] array) {
		return set.toArray(array);
	}

	public final ListArray<T> toList() {
		return set.toList();
	}

	public final SetHashed<T> union(final Iterable<? extends T> c) {
		return set.union(c);
	}

	@Override
	public final String toString() {
		return set.toString();
	}

}	// End SetImmutable
