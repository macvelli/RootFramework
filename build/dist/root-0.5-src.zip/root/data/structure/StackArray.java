package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;
import root.util.Fast;
import root.util.Safe;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Remove @Override annotations from Stack<T> methods (done)
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 * 		+ Check http://math.hws.edu/eck/cs124/javanotes3/c11/s3.html out for some ideas
 * 
 * @author esmith
 *
 * @param <T>
 */
public class StackArray<T> implements RootStack<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	protected int head;
	protected int size;
	protected T[] values;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public StackArray() {
		head = 8;
		values = Clean.newArray(8);
	}

	public StackArray(final int capacity) {
		head = Fast.max(capacity, 8);
		values = Clean.newArray(head);
	}

	public StackArray(final Itemizable<? extends T> c) {
		head = Fast.max(c.getSize(), 8);
		values = Clean.newArray(head);

		for (T t : c) {
			values[--head] = t;
		}
		size = c.getSize();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		for (int i=head; i < values.length; i++) {
			values[i] = null;
		}

		head = values.length;
		size = 0;
	}

	public final T oldest() {
		return (size == 0) ? null : values[values.length-1];
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof Iterable)) {
			return false;
		}

		final Iterable<?> i = (Iterable<?>) o;

		int index = head;
		for (Object t : i) {
			if (index == values.length) {
				return false;
			}

			if (Safe.notEqual(values[index], t)) {
				return false;
			}

			index++;
		}

		return index == values.length;
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<T>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Descend();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (int i=head; i < values.length; i++) {
			if (values[i] != null) {
				h ^= values[i].hashCode();
			}
			h <<= 1;
		}

		return h;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Ascend();
	}

	public final T peek() {
		return (size == 0) ? null : values[head];
	}

	public final T pop() {
		if (size == 0) {
			throw new NoSuchElementException();
		}

		final T t = values[head];
		values[head++] = null;
		size--;

		return t;
	}

	public final void push(final T item) {
		if (head == 0) {
			// resize
			final T[] a = Clean.newArray(values.length << 1);
			head = a.length - values.length;
			System.arraycopy(values, 0, a, head, values.length);
			values = a;
		}

		values[--head] = item;
		size++;
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);
		builder.append(values, head, size);
		return builder.toString();
	}

	//  <><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><><>

	private final class Ascend implements Itemizer<T> {

		private int i = head;

		@Override
		public final boolean hasNext() {
			return i < values.length;
		}

		@Override
		public final T next() {
			if (i == values.length) {
				throw new NoSuchElementException();
			}

			return values[i++];
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = head;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Ascend

	private final class Descend implements Itemizer<T> {

		private int i = values.length;

		@Override
		public final boolean hasNext() {
			return i > head;
		}

		@Override
		public final T next() {
			if (i == head) {
				throw new NoSuchElementException();
			}

			return values[--i];
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = values.length;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Descend

}	// End StackArray
