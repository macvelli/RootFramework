package root.data.structure;

import java.util.NoSuchElementException;

import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * TODO:
 * 		+ Implement a Descend Itemizer that uses a Stack to get the values
 * 		  in descending order. Use this idea elsewhere such as Maps and Sets.
 * 		+ Make sure on every Itemizer class in every data structure that the
 * 		  public methods are made final
 * 
 * @author esmith
 *
 * @param <T>
 */
class Node<T> {

	// <><><><><><><><><><><><> Static Artifacts <><><><><><><><><><><><><><><>

	static final void clear(Node<?> head) {
		for (Node<?> next; head != null; head = next) {
			next = head.next;
			head.data = null;
			head.next = null;
		}
	}

	static final boolean equals(final Object o, final Node<?> head) {
		if (o == null || !(o instanceof Iterable)) {
			return false;
		}

		final Iterable<?> i = (Iterable<?>) o;

		Node<?> n = head;
		for (Object t : i) {
			if (n == null) {
				return false;
			}

			if (Safe.notEqual(n.data, t)) {
				return false;
			}

			n = n.next;
		}

		return n == null;
	}

	static final int hashCode(Node<?> head, final int size) {
		int h = size;
		for (; head != null; head = head.next) {
			if (head.data != null) {
				h ^= head.data.hashCode();
			}
			h <<= 1;
		}

		return h;
	}

	static final String toString(Node<?> head, final int size) {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('[');
		for (; head != null; head = head.next) {
			builder.separator(1).append(head.data);
		}
		builder.append(']');

		return builder.toString();
	}

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	T		data;
	Node<T>	next;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	Node(final T data) {
		this.data = data;
	}

	// <><><><><><><><><><><><><><> Package Classes <><><><><><><><><><><><><><

	static class Ascend<T> implements Itemizer<T> {

		private Node<T> cursor;
		private int index;

		private final Node<T> head;
		private final int size;

		Ascend(final Node<T> head, final int size) {
			this.cursor = head;
			this.head = head;
			this.index = -1;
			this.size = size;
		}

		@Override
		public final boolean hasNext() {
			return cursor != null;
		}

		@Override
		public final T next() {
			if (cursor == null) {
				throw new NoSuchElementException();
			}

			final T t = cursor.data;
			cursor = cursor.next;
			index++;

			return t;
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final int getIndex() {
			return index;
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			this.cursor = this.head;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Ascend

	static class Descend<T> implements Itemizer<T> {

		private final Itemizer<T> itr;

		Descend(final Node<T> head, final int size) {
			final StackArray<T> stack = new StackArray<>(size);

			for (Node<T> n = head; n != null; n = n.next) {
				stack.push(n.data);
			}

			itr = stack.iterator();
		}

		@Override
		public final boolean hasNext() {
			return itr.hasNext();
		}

		@Override
		public final T next() {
			return itr.next();
		}

		@Override
		public final void remove() {
			itr.remove();
		}

		@Override
		public final int getIndex() {
			return itr.getIndex();
		}

		@Override
		public final Itemizer<T> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			itr.reset();
		}

		@Override
		public final int getSize() {
			return itr.getSize();
		}

	}	// End Descend

}	// End Node
