/*
 * DataStructureFullException.java
 * 
 * Last Modified: 02/24/2016
 */
package root.data.structure;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class DataStructureFullException extends RuntimeException {

	// Constants

	private static final long serialVersionUID = 252630709529084060L;

	// Constructors

	public DataStructureFullException() {
		super("Attempt to add element to a full data structure failed");
	}

}	// End DataStructureFullException
