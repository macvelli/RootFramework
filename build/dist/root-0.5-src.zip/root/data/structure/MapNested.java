/*
 * MapNested.java
 * 
 * Last Modified: 04/28/2016
 */
package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * 
 * @author Edward Smith
 * @version 1.0
 * @date April 28, 2016
 *
 * @param <K1>
 * @param <K2>
 * @param <V>
 */
public class MapNested<K1, K2, V> implements Itemizable<MapEntry<K1, MapHashed<K2, V>>>, Cloneable {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int size;
	private final MapHashed<K1, MapHashed<K2, V>> nestedMap;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public MapNested() {
		nestedMap = new MapHashed<>();
	}

	public MapNested(final int capacity) {
		nestedMap = new MapHashed<>(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		MapEntry<K1, MapHashed<K2, V>> next;

		for (int i=0; i < nestedMap.table.length; i++) {
			for (MapEntry<K1, MapHashed<K2, V>> e = nestedMap.table[i]; e != null; e = next) {
				next = e.next;
				e.value.clear();
				e.value = null;
				e.next = null;
			}
			nestedMap.table[i] = null;
		}

		nestedMap.size = 0;
		size = 0;
	}

	@Override
	public final MapNested<K1, K2, V> clone() {
		final MapNested<K1, K2, V> map = new MapNested<>(nestedMap.capacity);

		for (MapEntry<K1, MapHashed<K2, V>> e : nestedMap) {
			for (MapEntry<K2, V> f : e.value) {
				map.put(e.key, f.key, f.value);
			}
		}

		return map;
	}

	public final boolean containsKey(final K1 key) {
		return nestedMap.containsKey(key);
	}

	public final boolean containsKeys(final K1 key1, final K2 key2) {
		for (MapEntry<K1, MapHashed<K2, V>> e = nestedMap.table[Safe.hashCode(key1) % nestedMap.table.length]; e != null; e = e.next) {
			if (Safe.equals(e.key, key1)) {
				return e.value.containsKey(key2);
			}
		}

		return false;
	}

	public final boolean containsValue(final V value) {
		for (int i=0; i < nestedMap.table.length; i++) {
			for (MapEntry<K1, MapHashed<K2, V>> e = nestedMap.table[i]; e != null; e = e.next) {
				if (e.value.containsValue(value)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public final boolean equals(final Object o)  {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof MapNested)) {
			return false;
		}

		final MapNested<?, ?, ?> m = (MapNested<?, ?, ?>) o;
		if (m.size != size) {
			return false;
		}

objs:	for (MapEntry<?, ?> e : m) {
			for (MapEntry<K1, MapHashed<K2, V>> f = nestedMap.table[e.hash % nestedMap.table.length]; f != null; f = f.next) {
				if (Safe.equals(e.key, f.key) && Safe.equals(e.value, f.value)) {
					continue objs;
				}
			}

			return false;
		}

        return true;
	}

	public final MapHashed<K2, V> get(final K1 key1) {
		return nestedMap.get(key1);
	}

	public final V get(final K1 key1, final K2 key2) {
		final MapHashed<K2, V> map = nestedMap.get(key1);

		return (map == null) ? null : map.get(key2);
	}

	@Override
	public final Collection<MapEntry<K1, MapHashed<K2, V>>> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<MapEntry<K1, MapHashed<K2, V>>> getDescending() {
		return new StackArray<>(this).iterator();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (MapEntry<K1, MapHashed<K2, V>> e : this) {
			h ^= e.hash;
			h ^= e.value.hashCode();
		}

		return h;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<MapEntry<K1, MapHashed<K2, V>>> iterator() {
		return new Ascend();
	}

	public final V put(final K1 key1, final K2 key2, final V value) {
		MapHashed<K2, V> map = nestedMap.get(key1);

		if (map == null) {
			map = new MapHashed<>();
			nestedMap.put(key1, map);
		}

		final int beginSize = map.size;
		final V oldValue = map.put(key2, value);
		size += (map.size - beginSize);

		return oldValue;
	}

	public final MapHashed<K2, V> remove(final K1 key1) {
		final MapHashed<K2, V> map = nestedMap.remove(key1);

		if (map != null) {
			size -= map.size;
		}

		return map;
	}

	public final V remove(final K1 key1, final K2 key2) {
		final MapHashed<K2, V> map = nestedMap.get(key1);
		V value = null;

		if (map != null) {
			final int beginSize = map.size;
			value = map.remove(key2);
			size -= (beginSize - map.size);

			if (map.isEmpty()) {
				nestedMap.remove(key1);
			}
		}

		return value;
	}


	@Override
	public String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('{');
		if (size > 0) {
			for (int i=0; i < nestedMap.table.length; i++) {
				for (MapEntry<K1, MapHashed<K2, V>> e = nestedMap.table[i]; e != null; e = e.next) {
					builder.separator(1).append(e.key).append('=');

					builder.append('{');
					final int start = builder.getLength();
					for (int j=0; j < e.value.table.length; j++) {
						for (MapEntry<K2, V> f = e.value.table[j]; f != null; f = f.next) {
							builder.separator(start).append(f.key).append('=').append(f.value);
						}
					}
					builder.append('}');
				}
			}
		}
		builder.append('}');

		return builder.toString();
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	private final class Ascend implements Itemizer<MapEntry<K1, MapHashed<K2, V>>> {

		private int i, j;
		private MapEntry<K1, MapHashed<K2, V>> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final MapEntry<K1, MapHashed<K2, V>> next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = nestedMap.table[i++];
			}

			return e;
		}

		@Override
		public final void remove() {
			MapNested.this.remove(e.key);
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final Itemizer<MapEntry<K1, MapHashed<K2, V>>> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}

		@Override
		public final int getSize() {
			return size;
		}
		
	}	// End Ascend

}	// End MapNested
