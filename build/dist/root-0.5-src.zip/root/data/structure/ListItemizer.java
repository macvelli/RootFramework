/*
 * ListItemizer.java
 */
package root.data.structure;

import java.util.ListIterator;

import root.lang.Itemizer;

public interface ListItemizer<T> extends Itemizer<T>, ListIterator<T> {

	void add(T t);

	int getIndex();

	int getSize();

	boolean hasNext();

	boolean hasPrevious();

	ListItemizer<T> iterator();

	T next();

	int nextIndex();

	T previous();

	int previousIndex();

	void remove();

	void reset();

	void set(T t);

}	// End ListItemizer
