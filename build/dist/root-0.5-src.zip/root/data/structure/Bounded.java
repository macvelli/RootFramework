/*
 * Bounded.java
 * 
 * Last Modified: 02/24/2016
 */
package root.data.structure;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public interface Bounded {

	public boolean isFull();

}	// End Bounded
