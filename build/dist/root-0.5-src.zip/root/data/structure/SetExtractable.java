/*
 * SetExtractable.java
 */
package root.data.structure;

import root.lang.Characters;
import root.lang.Extractable;
import root.lang.ParamStrBuilder;

/**
 * TODO: Find a way to get String, Integer, Float, etc to fit into an Extractable implementation
 * 
 * @author Edward Smith
 * @version 0.5
 * 
 * @param <T>
 */
public final class SetExtractable<T extends Extractable<Characters>> extends SetHashed<T> implements Extractable<Characters> {

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public SetExtractable() {
		super();
	}

	public SetExtractable(final int capacity) {
		super(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		if (size == 0) {
			chars.append(Characters.emptyArray);
		} else {
			SetEntry<T> e;

			chars.append('[');
			final int start = chars.getLength();
			for (int i=0, j=0; j < size; i++) {
				for (e = table[i]; e != null; e = e.next) {
					chars.separator(start).append(e.key);
					j++;
				}
			}
			chars.append(']');
		}
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);
		extract(builder);
		return builder.toString();
	}

}	// End SetExtractable
