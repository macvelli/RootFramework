package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;
import root.util.Fast;
import root.util.Safe;

/**
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public class MapBidirectional<K, V> implements Itemizable<MapEntry<K, V>>, Cloneable {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 5404888434082080468L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final MapHashed<K, V> keyValueMap;
	private final MapHashed<V, K> valueKeyMap;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public MapBidirectional() {
		keyValueMap = new MapHashed<>();
		valueKeyMap = new MapHashed<>();
	}

	public MapBidirectional(int capacity) {
		capacity = Fast.max(capacity, 8);
		keyValueMap = new MapHashed<>(capacity);
		valueKeyMap = new MapHashed<>(capacity);
	}

	private MapBidirectional(final MapBidirectional<K, V> map) {
		keyValueMap = map.keyValueMap.clone();
		valueKeyMap = map.valueKeyMap.clone();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		keyValueMap.clear();
		valueKeyMap.clear();
	}

	@Override
	public final MapBidirectional<K, V> clone() {
		return new MapBidirectional<>(this);
	}

	public final boolean containsKey(final K key) {
		return keyValueMap.containsKey(key);
	}

	public final boolean containsValue(final V value) {
		return valueKeyMap.containsKey(value);
	}

	@Override
	public final boolean equals(final Object o)  {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof MapBidirectional)) {
			return false;
		}

		final MapBidirectional<?, ?> m = (MapBidirectional<?, ?>) o;

		return Safe.equals(m.keyValueMap, keyValueMap) && Safe.equals(m.valueKeyMap, valueKeyMap);
	}

	public final K getKey(final V value) {
		return valueKeyMap.get(value);
	}

	public final V getValue(final K key) {
		return keyValueMap.get(key);
	}

	@Override
	public final Collection<MapEntry<K, V>> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<MapEntry<K, V>> getDescending() {
		return new StackArray<>(this).iterator();
	}

	@Override
	public final int getSize() {
		return keyValueMap.size;
	}

	@Override
	public final int hashCode() {
		return keyValueMap.hashCode() ^ valueKeyMap.hashCode();
	}

	@Override
	public final boolean isEmpty() {
		return keyValueMap.isEmpty();
	}

	@Override
	public final Itemizer<MapEntry<K, V>> iterator() {
		return keyValueMap.iterator();
	}

	public final V put(final K key, final V value) {
		final V oldValue = keyValueMap.put(key, value);

		if (oldValue != null) {
			valueKeyMap.remove(oldValue);
		}

		valueKeyMap.put(value, key);

		return oldValue;
	}

	public final V remove(final K key) {
		final V oldValue = keyValueMap.remove(key);

		if (oldValue != null) {
			valueKeyMap.remove(oldValue);
		}

		return oldValue;
	}

	@Override
	public final String toString() {
		return keyValueMap.toString();
	}

}
