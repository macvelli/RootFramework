/*
 * CompositeKey.java
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * TODO: Test before putting a DONE stamp on it
 * 
 * @author Edward Smith
 * @version 0.5
 */
public class CompositeKey {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final Object[] key;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public CompositeKey(final Object... key) {
		this.key = key;
	}

	public CompositeKey(final Itemizable<?> key) {
		this.key = new Object[key.getSize()];

		int i=0;
		for (Object k : key) {
			this.key[i++] = k;
		}
	}

	public CompositeKey(final Collection<?> key) {
		this.key = new Object[key.size()];

		int i=0;
		for (Object k : key) {
			this.key[i++] = k;
		}
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * 
	 * @return
	 */
	public final Object[] getKey() {
		return key;
	}

	@Override
	public final boolean equals(final Object obj) {
		if (this != obj) {
			if (Safe.notEqual(obj, CompositeKey.class)) {
				return false;
			}

			return Safe.equals(this.key, ((CompositeKey) obj).key);
		}

        return true;
	}

	@Override
	public final int hashCode() {
		return Safe.hashCode(key, key.length);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(key.length << 4);
		chars.append(key);
		return chars.toString();
	}

}	// End CompositeKey
