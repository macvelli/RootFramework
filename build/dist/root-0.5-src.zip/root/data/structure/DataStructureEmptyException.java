/*
 * DataStructureEmptyException.java
 */
package root.data.structure;

/**
 * 
 * 
 * @author Edward Smith
 * @version 1.0
 */
public class DataStructureEmptyException extends RuntimeException {

	// <><><><><><><><><><><><><><><> Constants <><><><><><><><><><><><><><><><

	private static final long serialVersionUID = -1657859853859488360L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public DataStructureEmptyException() {
		super("Attempt to remove element from an empty data structure failed");
	}

}	// End DataStructureEmptyException
