/*
 * ImmutableItemizer.java
 * 
 * Last Modified: 04/28/2016
 */
package root.data.structure;

import root.lang.Itemizer;

/**
 * 
 * 
 * @author Edward Smith
 * @version 1.0
 *
 * @param <T>
 */
public final class ImmutableItemizer<T> implements Itemizer<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final Itemizer<? extends T> i;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public ImmutableItemizer(final Itemizer<? extends T> i) {
		this.i = i;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final boolean hasNext() {
		return i.hasNext();
	}

	@Override
	public final T next() {
		return i.next();
	}

	@Override
	public final void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public final int getIndex() {
		return i.getIndex();
	}

	@Override
	public final Itemizer<T> iterator() {
		return this;
	}

	@Override
	public final void reset() {
		i.reset();
	}

	@Override
	public final int getSize() {
		return i.getSize();
	}

}	// End ImmutableItemizer
