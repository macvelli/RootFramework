package root.data.structure;

import java.util.NoSuchElementException;

import root.lang.Itemizer;

/**
 * TODO: Clean up for/if/while/etc braces
 * 
 * @author Ed Smith
 */
public class CharArrayCollector implements Collector<char[]> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int			size;
	private char[][]	values;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public CharArrayCollector() {
		values = new char[5][];
	}

	public CharArrayCollector(final int capacity) {
		values = new char[capacity][];
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public void add(final char[] c) {
		if (size == values.length) {
			resize();
		}

		values[size++] = c;
	}

	public void add(final String s) {
		if (size == values.length) {
			resize();
		}

		// TODO: Make this Fast!
		values[size++] = s.toCharArray();
	}

	public void add(final CharSequence charSeq) {
		if (size == values.length) {
			resize();
		}

		char[] c = new char[charSeq.length()];
		for (int i=0; i < c.length; i++) {
			c[i] = charSeq.charAt(i);
		}

		values[size++] = c;
	}

	public char[] get(final int index) {
		return values[index];
	}

	public Itemizer<char[]> iterator() {
		return new Itr();
	}

	public char[][] toArray() {
		final char[][] a = new char[size][];
		System.arraycopy(values, 0, a, 0, size);
		return a;
	}

	// <><><><><><><><><><><><><><> Private Methods <><><><><><><><><><><><><><

	private void resize() {
		final char[][] c = new char[size << 1][];
		System.arraycopy(values, 0, c, 0, size);
		values = c;
	}

	// <><><><><><><><><><><><><><> Private Classes <><><><><><><><><><><><><><

	// TODO: Consolidate all array Itemizers into one ArrayItr implementation
	private class Itr implements Itemizer<char[]> {

		private int i;

		@Override
		public final boolean hasNext() {
			return i < size;
		}

		@Override
		public final char[] next() {
			if (i == size) {
				throw new NoSuchElementException();
			}

			return values[i++];
		}

		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final Itemizer<char[]> iterator() {
			return this;
		}

		@Override
		public final int getIndex() {
			return i-1;
		}

		@Override
		public final void reset() {
			i = 0;
		}

		@Override
		public final int getSize() {
			return size;
		}

	}	// End Itr

}	// End CharArrayCollector
