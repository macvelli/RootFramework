/*
 * IndexOutOfBoundsException.java
 */
package root.data.structure;

import root.lang.ParamStr;

/**
 * 
 * 
 * @author Edward Smith
 * @version 0.5
 */
public class IndexOutOfBoundsException extends RuntimeException {

	// <><><><><><><><><><><><><><><> Constants <><><><><><><><><><><><><><><><

	private static final long serialVersionUID = 8930543884997274522L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public IndexOutOfBoundsException(final int index, final int size) {
		super(ParamStr.format("Index: {P}, Size: {P}", index, size));
	}

}	// End IndexOutOfBoundsException
