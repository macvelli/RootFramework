/*
 * DataStructureInsufficientCapacityException.java
 * 
 * Last Modified: 02/24/2016
 */
package root.data.structure;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class DataStructureInsufficientCapacityException extends RuntimeException {

	// Constants

	private static final long serialVersionUID = 7442619868863922768L;

	// Constructors

	public DataStructureInsufficientCapacityException(final int offered, final int capacity) {
		// TODO: Replace StringBuilder with faster Root implementation
		super(new StringBuilder(100)
			.append("Attempt to add ")
			.append(offered)
			.append(" elements to a data structure with available capacity of ")
			.append(capacity)
			.append(" failed")
			.toString());
	}
	
}	// End DataStructureInsufficientCapacityException
