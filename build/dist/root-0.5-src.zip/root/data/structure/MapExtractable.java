package root.data.structure;

import root.lang.Characters;
import root.lang.Extractable;
import root.lang.ParamStrBuilder;

/**
 * TODO: Find a way to get String, Integer, etc to fit into this bitch...
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public class MapExtractable<K extends Extractable, V extends Extractable> extends MapHashed<K, V> implements Extractable {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 6252178362235507637L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public MapExtractable() {
		super();
	}

	public MapExtractable(final int capacity) {
		super(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append('{');
		if (size > 0) {
			final int start = chars.getLength();
			for (int i=0; i < table.length; i++) {
				for (MapEntry<K, V> e = table[i]; e != null; e = e.next) {
					chars.separator(start).append(e.key).append('=').append(e.value);
				}
			}
		}
		chars.append('}');
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);
		extract(builder);
		return builder.toString();
	}

}
