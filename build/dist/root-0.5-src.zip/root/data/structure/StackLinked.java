/*
 * StackLinked.java
 * 
 * Last Modified: 04/28/2016
 */
package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;

/**
 * TODO:
 * 		+ Add final designation to every non-private method (done)
 * 		+ Add final designation to every method argument that is not used as a local variable (done)
 * 		+ Remove @Override annotations from Stack<T> methods (done)
 * 		+ Implement Cloneable in all data structures!!
 * 		+ Create unit test and ensure all methods and corner cases within each method are tested
 * 		+ Check http://math.hws.edu/eck/cs124/javanotes3/c11/s3.html out for some ideas
 * 
 * @author Edward Smith
 * @version 1.0
 *
 * @param <T>
 */
public class StackLinked<T> implements RootStack<T> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int		size;
	private Node<T> head;

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		Node.clear(head);

		head = null;
		size = 0;
	}

	public final T oldest() {
		if (size == 0) {
			return null;
		}

		Node<T> n = head;

		for (; n.next != null; n = n.next);

		return n.data;
	}

	@Override
	public final boolean equals(final Object o) {
		return Node.equals(o, head);
	}

	@Override
	public final Collection<T> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<T> getDescending() {
		return new Node.Descend<>(head, size);
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		return Node.hashCode(head, size);
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<T> iterator() {
		return new Node.Ascend<>(head, size);
	}

	public final T peek() {
		return (head == null) ? null : head.data;
	}

	public final T pop() {
		if (size == 0) {
			throw new NoSuchElementException();
		}

		final Node<T> n = head;
		head = head.next;

		final T t = n.data;
		n.data = null;
		n.next = null;
		size--;

		return t;
	}

	public final void push(final T item) {
		final Node<T> node = new Node<T>(item);
		node.next = head;
		head = node;
		size++;
	}

	@Override
	public final String toString() {
		return Node.toString(head, size);
	}

}	// End StackLinked
