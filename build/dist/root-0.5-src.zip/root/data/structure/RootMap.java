package root.data.structure;

import root.lang.Itemizable;

/**
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public interface RootMap<K, V> extends Itemizable<MapEntry<K, V>> {

	boolean containsKey(K key);

	boolean containsValue(V value);

	V get(K key);

	V get(K key, V defaultVal);

	V get(K key, Class<V> clazz);

	V put(K key, V value);

	V remove(K key);

}
