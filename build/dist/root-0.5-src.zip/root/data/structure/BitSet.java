package root.data.structure;

import root.lang.Characters;
import root.lang.Extractable;
import root.lang.ParamStrBuilder;

/**
 * 
 * @author esmith
 */
public final class BitSet implements Extractable {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final long serialVersionUID = 6279128929702805469L;

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private int flags;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public BitSet() {}

	public BitSet(final int flags) {
		this.flags = flags;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void clear() {
		flags = 0;
	}

	public final void clear(final int i) {
		flags &= ~(1 << i);
	}

	public final boolean contains(final int i) {
		return (flags & i) == i;
	}

	public final boolean containsAny(final int i) {
		return (flags & i) != 0;
	}

	public final boolean equals(final int i) {
		return flags == i;
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || !(o instanceof BitSet)) {
			return false;
		}

		return ((BitSet) o).flags == flags;
	}

	@Override
	public final int hashCode() {
		return flags;
	}

	public final boolean get(final int i) {
		return (flags & (1 << i)) != 0;
	}

	public final int getValue() {
		return flags;
	}

	public final BitSet intersect(final BitSet b) {
		return new BitSet(flags & b.flags);
	}

	public final boolean isEmpty() {
		return flags == 0;
	}

	public final void set(final int i) {
		flags |= (1 << i);
	}

	public final void set(final int i, final boolean e) {
		if (e) {
			flags |= (1 << i);
		} else {
			flags &= ~(1 << i);
		}
	}

	public final BitSet union(final BitSet b) {
		return new BitSet(flags | b.flags);
	}

	@Override
	public final void extract(final Characters chars) {
		final char[] c = new char[] {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
		int f = flags, i = 32;

		while (f > 0) {
			c[--i] = Characters.digits[f & 1];
			f >>>= 1;
		}

		chars.append(c);
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(32);
		extract(chars);
		return chars.toString();
	}

}
