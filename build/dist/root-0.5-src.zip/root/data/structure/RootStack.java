package root.data.structure;

import root.lang.Itemizable;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface RootStack<T> extends Itemizable<T> {

	T oldest();

	T peek();

	T pop();

	void push(T item);

}
