package root.data.structure;

import java.util.Collection;
import java.util.NoSuchElementException;

import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Clean;
import root.util.Fast;
import root.util.Safe;

/**
 * Run the following in a normal HashMap and you get:
 * <code> 
 * 	public static void main(String[] args) {
 *		HashMap<String[], String> map = new HashMap<>();
 *
 *		map.put(new String[] {"FOO", "BAR"}, "WHEE!");
 *
 *		System.out.println(map.contains(new String[] {"FOO", "BAR"}));
 *		System.out.println(map.get(new String[] {"FOO", "BAR"}));
 *	}
 *
 * false
 * null
 * </code>
 * 
 * @author esmith
 *
 * @param <K>
 * @param <V>
 */
public class MapMultiKey<K, V> implements RootMap<K[], V> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private int size;
	private int capacity;
	private MapEntry<K[], V>[] table;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public MapMultiKey() {
		capacity = 8;
		table = newArray(11);
	}

	public MapMultiKey(final int capacity) {
		this.capacity = Fast.max(capacity, 8);
		table = newArray(this.capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void clear() {
		MapEntry<K[], V> next;

		for (int i=0; i < table.length; i++) {
			for (MapEntry<K[], V> e = table[i]; e != null; e = next) {
				next = e.next;
				e.value = null;
				e.next = null;
			}
			table[i] = null;
		}

		size = 0;
	}

	@Override
	public final boolean containsKey(final K[] key) {
		for (MapEntry<K[], V> e = table[Safe.hashCode(key) % table.length]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public final boolean containsValue(final V value) {
		for (int i=0; i < table.length; i++) {
			for (MapEntry<K[], V> e = table[i]; e != null; e = e.next) {
				if (Safe.equals(e.value, value)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final boolean equals(final Object o)  {
		if (o == this) {
			return true;
		}

		if (o == null || !(o instanceof MapMultiKey)) {
			return false;
		}

		final MapMultiKey<K, ?> m = (MapMultiKey<K, ?>) o;
		if (m.size != size) {
			return false;
		}

objs:	for (MapEntry<K[], ?> e : m) {
			for (MapEntry<K[], V> f = table[e.hash % table.length]; f != null; f = f.next) {
				if (Safe.equals(e.key, f.key) && Safe.equals(e.value, f.value)) {
					continue objs;
				}
			}

			return false;
		}

        return true;
	}

	@Override
	public final V get(final K[] key) {
		for (MapEntry<K[], V> e = table[Safe.hashCode(key) % table.length]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				return e.value;
			}
		}

		return null;
	}

	@Override
	public final V get(final K[] key, final V defaultVal) {
		for (MapEntry<K[], V> e = table[Safe.hashCode(key) % table.length]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				return e.value;
			}
		}

		return defaultVal;
	}

	@Override
	public final V get(final K[] key, final Class<V> clazz) {
		final int h = Safe.hashCode(key);
		int i = h % table.length;

		for (MapEntry<K[], V> e = table[i]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				return e.value;
			}
		}

		if (size++ == capacity) {
			i = resize(h);
		}

		table[i] = new MapEntry<K[], V>(key, Clean.newInstance(clazz), h, table[i]);

		return table[i].value;
	}

	@Override
	public final Collection<MapEntry<K[], V>> getCollection() {
		return new ItemizableDelegate<>(this);
	}

	@Override
	public final Itemizer<MapEntry<K[], V>> getDescending() {
		return new StackArray<>(this).iterator();
	}

	@Override
	public final int getSize() {
		return size;
	}

	@Override
	public final int hashCode() {
		int h = size;
		for (MapEntry<K[], V> e : this) {
			h ^= e.hash;
			h <<= 1;
		}

		return h;
	}

	@Override
	public final boolean isEmpty() {
		return size == 0;
	}

	@Override
	public final Itemizer<MapEntry<K[], V>> iterator() {
		return new Ascend();
	}

	@Override
	public final V put(final K[] key, final V value) {
		final int h = Safe.hashCode(key);
		int i = h % table.length;

		for (MapEntry<K[], V> e = table[i]; e != null; e = e.next) {
			if (Safe.equals(e.key, key)) {
				final V v = e.value;
				e.value = value;
				return v;
			}
		}

		if (size++ == capacity) {
			i = resize(h);
		}

		table[i] = new MapEntry<K[], V>(key, value, h, table[i]);

		return null;
	}

	@Override
	public final V remove(final K[] key) {
		final int i = Safe.hashCode(key) % table.length;

		for (MapEntry<K[], V> e = table[i], prev = null; e != null; prev = e, e = e.next) {
			if (Safe.equals(e.key, key)) {
				if (prev == null)
					table[i] = e.next;
				else
					prev.next = e.next;

				final V v = e.value;
				e.value = null;
				e.next = null;
				size--;
				return v;
			}
		}

		return null;
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(size << 4);

		builder.append('{');
		if (size > 0) {
			for (int i=0; i < table.length; i++) {
				for (MapEntry<K[], V> e = table[i]; e != null; e = e.next) {
					builder.separator(1).append(e.key).append('=').append(e.value);
				}
			}
		}
		builder.append('}');

		return builder.toString();
	}

	//  <><><><><><><><><><><><><>< Private Methods ><><><><><><><><><><><><><>

	@SuppressWarnings("unchecked")
	private MapEntry<K[], V>[] newArray(final int capacity) {
		return new MapEntry[Fast.hashTableSize(capacity)];
	}

	private int resize(final int h) {
		final MapEntry<K[], V>[] oldTable = table;
		capacity = (capacity << 1) - (capacity >> 2);
		table = newArray(capacity);

		MapEntry<K[], V> next;
		for (int i=0, j=0; i < oldTable.length; i++) {
			for (MapEntry<K[], V> e = oldTable[i]; e != null; e = next) {
				next = e.next;
				j = e.hash % table.length;
				e.next = table[j];
				table[j] = e;
			}
			oldTable[i] = null;
		}

		return h % table.length;
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	private final class Ascend implements Itemizer<MapEntry<K[], V>> {

		private int i, j;
		private MapEntry<K[], V> e;

		@Override
		public final boolean hasNext() {
			return j < size;
		}

		@Override
		public final MapEntry<K[], V> next() {
			if (j == size) {
				throw new NoSuchElementException();
			}

			j++;

			if (e != null) {
				e = e.next;
			}

			while (e == null) {
				e = table[i++];
			}

			return e;
		}

		@Override
		public final void remove() {
			MapMultiKey.this.remove(e.key);
		}

		@Override
		public final int getIndex() {
			return j-1;
		}

		@Override
		public final int getSize() {
			return size;
		}

		@Override
		public final Itemizer<MapEntry<K[], V>> iterator() {
			return this;
		}

		@Override
		public final void reset() {
			i = 0;
			j = 0;
			e = null;
		}

	}	// End Ascend

}	// End MapMultiKey
