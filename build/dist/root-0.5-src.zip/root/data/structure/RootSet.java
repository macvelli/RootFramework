/*
 * RootSet.java
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;

/**
 * 
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public interface RootSet<T> extends java.util.Set<T>, Itemizable<T> {

	boolean add(T t);

	@SuppressWarnings("unchecked")
	boolean addAll(T... array);

	boolean addAll(Collection<? extends T> c);

	boolean addAll(Iterable<? extends T> c);

	void clear();

	boolean contains(Object o);

	@SuppressWarnings("unchecked")
	boolean containsAll(T... array);

	boolean containsAll(Collection<?> c);

	boolean containsAll(Iterable<? extends T> c);

	@SuppressWarnings("unchecked")
	boolean containsAny(T... array);

	boolean containsAny(Iterable<? extends T> c);

	RootSet<T> difference(Iterable<? extends T> c);

	T get(T t);

	Collection<T> getCollection();

	Itemizer<T> getDescending();

	int getSize();

	RootSet<T> intersect(Iterable<? extends T> c);

	boolean isEmpty();

	Itemizer<T> iterator();

	boolean remove(Object o);

	@SuppressWarnings("unchecked")
	boolean removeAll(T... array);

	boolean removeAll(Collection<?> c);

	boolean removeAll(Iterable<? extends T> c);

	boolean replace(T o, T n);

	boolean retainAll(Collection<?> c);

	int size();

	Object[] toArray();

	<E> E[] toArray(E[] arrayParam);

	RootList<T> toList();

	RootSet<T> union(Iterable<? extends T> c);

}	// End RootSet
