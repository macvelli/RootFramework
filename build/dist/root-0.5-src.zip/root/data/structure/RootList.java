/*
 * RootList.java
 */
package root.data.structure;

import java.util.Collection;

import root.lang.Itemizable;
import root.lang.Itemizer;

/**
 * TODO:
 * 		+ Remove public designation from method declarations (done)
 * 		+ Rename generic type E to generic type T (done)
 * 		+ Seems like Extractable should only be implemented when the generic
 * 		  types enforce elements to extend it since it's useless otherwise
 * 		+ TODO: Where the hell did the default methods come from and what do they mean?
 * TODO: This interface needs to extend java.util.List
 * TODO: Should this interface also define methods that are already defined in the Java Collections API?
 * 
 * @author Edward Smith
 * @version 0.5
 *
 * @param <T>
 */
public interface RootList<T> extends java.util.List<T>, Itemizable<T>, Cloneable {

	boolean add(T t);

	void add(int index, T t);

	@SuppressWarnings("unchecked")
	void addAll(T... array);

	boolean addAll(Collection<? extends T> c);

	boolean addAll(int index, Collection<? extends T> c);

	void addAll(Iterable<? extends T> c);

	void clear();

	boolean contains(Object obj);

	@SuppressWarnings("unchecked")
	boolean containsAll(T... array);

	boolean containsAll(Collection<?> c);

	@SuppressWarnings("unchecked")
	boolean containsAny(T... array);

	boolean containsAny(Iterable<? extends T> c);

	T echo(T t);

	T get(int index);

	Collection<T> getCollection();

	Itemizer<T> getDescending();

	int getSize();

	int indexOf(Object obj);

	void insert(int i, T t);

	@SuppressWarnings("unchecked")
	void insertAll(int i, T... array);

	void insertAll(int i, Itemizable<? extends T> c);

	void insertAll(int i, Iterable<? extends T> c);

	boolean isEmpty();

	Itemizer<T> iterator();

	T last();

	int lastIndexOf(Object obj);

	ListItemizer<T> listIterator();

	ListItemizer<T> listIterator(int index);

	T random();

	T remove(int index);

	boolean remove(Object obj);

	@SuppressWarnings("unchecked")
	boolean removeAll(T... array);

	boolean removeAll(Collection<?> c);

	boolean replace(T o, T n);

	boolean retainAll(Collection<?> c);

	T set(int index, T t);

	void shuffle();

	int size();

	/**
	 * TODO: Should this just go ahead and return a SubList?
	 * 
	 * @param fromIndex
	 * @return
	 */
	RootList<T> subList(int fromIndex);

	/**
	 * TODO: Should this just go ahead and return a SubList?
	 *  
	 * @param fromIndex
	 * @param toIndex
	 * @return
	 */
	RootList<T> subList(int fromIndex, int toIndex);

	RootSet<T> subset(int fromIndex);

	RootSet<T> subset(int fromIndex, int toIndex);

	Object[] toArray();

	<E> E[] toArray(E[] array);

	RootSet<T> toSet();

}	// End RootList
