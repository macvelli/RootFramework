package root.data.validation;

import java.util.Map;

import root.data.structure.ListArray;
import root.data.structure.RootList;

public class Request {

	private final Map<String, String[]> data;
	private final ListArray<FieldError>	errors;

	public Request(final Map<String, String[]> data) {
		this.data = data;
		errors = new ListArray<FieldError>();
	}

	public void addError(final String fieldName, final String errorMsg) {
		errors.add(new FieldError(fieldName, errorMsg));
	}

	public RootList<FieldError> getErrors() {
		return errors;
	}

	public String[] get(final String name) {
		return data.get(name);
	}

}	// End Request
