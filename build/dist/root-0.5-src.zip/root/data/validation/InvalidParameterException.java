/*
 * InvalidParameterException.java
 * 
 * Last Modified: 04/21/2016
 */
package root.data.validation;

import root.lang.ParamStrBuilder;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class InvalidParameterException extends RuntimeException {

	// <><><><><><><><><><><><><><><> Constants ><><><><><><><><><><><><><><><>

	private static final long serialVersionUID = -3576232050732201866L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public InvalidParameterException(final String methodName, final String paramType, final String paramName, final String msg) {
		super(new ParamStrBuilder(5 + methodName.length() + paramType.length() + paramName.length() + msg.length())
				.append(methodName).append('(').append(paramType).append(' ').append(paramName).append(')',':',' ')
				.append(msg).toString());
	}

}	// End InvalidParameterException
