package root.data.validation;

public class Field {

	private boolean		required;
	private Validation	validations;

	private final String name;
	private final String term;

	Field(final String name, final String term) {
		this.name = name;
		this.term = term;
	}

	@Override
	public boolean equals(final Object obj) {
		try {
			return name.equals(((Field) obj).name);
		} catch (Exception e) {
			return false;
		}
	}

	public String getName() {
		return name;
	}

	public String getTerm() {
		return term;
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	Field required() {
		required = true;

		return this;
	}

	void validate(final Request request) {
		final String[] values = request.get(name);
		final boolean empty = (values == null || values.length == 0 || values[0] == null || values[0].length() == 0);

		if (required && empty)
			request.addError(name, term + " is required");
		else if (!empty) {

		}
	}

}	// End Field
