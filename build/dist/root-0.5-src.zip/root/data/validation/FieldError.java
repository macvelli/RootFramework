package root.data.validation;

public class FieldError {

	private final String name;
	private final String msg;

	public FieldError(final String name, final String msg) {
		this.name = name;
		this.msg = msg;
	}

	public String getName() {
		return name;
	}

	public String getMsg() {
		return msg;
	}

}	// End FieldError
