/*
 * NullParameterException.java
 * 
 * Last Modified: 04/10/2016
 */
package root.data.validation;

import root.lang.ParamStr;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class NullParameterException extends RuntimeException {

	// <><><><><><><><><><><><><><><> Constants ><><><><><><><><><><><><><><><>

	private static final long serialVersionUID = 7897180480326920037L;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public NullParameterException(final Class<?> clazz) {
		super(ParamStr.format("Expected parameter of type {P} but received null", clazz));
	}

}	// End NullParameterException
