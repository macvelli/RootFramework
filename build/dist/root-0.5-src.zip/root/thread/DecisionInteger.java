package root.thread;

import java.util.concurrent.atomic.AtomicInteger;

public class DecisionInteger extends AtomicInteger {

	private static final long serialVersionUID = -9183379255448983014L;

	public final boolean isEqualIncrement(final int value) {
		int i;
		do {
			i = get();
			if (i == value)
				return true;
		} while (!compareAndSet(i, i+1));

		return false;
	}

	public final boolean isZeroDecrement() {
		int i;
		do {
			i = get();
			if (i == 0)
				return true;
		} while (!compareAndSet(i, i-1));

		return false;
	}

}	// End DecisionInteger
