/* Copyright 2010 Edward Smith
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package root.pool;

import java.util.NoSuchElementException;

import root.data.structure.QueueBounded;
import root.log.Log;
import root.thread.Sync;

/**
 * A generic resource pool that cooperates with a {@link Factory} interface
 * implementation to manage the creation, validation, and destruction of
 * pooled objects.
 * 
 * TODO:
 * 		+ Just drop a Queue implementation in here and be done with it (done)
 * 
 * @author esmith
 *
 * @param <T>
 */
public final class PoolConcurrent<T> {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final Log log = new Log(PoolConcurrent.class);

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	/** The size of the {@link PoolConcurrent}.													*/
	private int						size;

	/** The maximum number of nanoseconds to wait for an object to return to the pool.	*/
	private long					maxWait;

	/** The {@link Factory} implementation for this {@link PoolConcurrent}.						*/
	private final Factory<T>		factory;

	/** Manages synchronization efforts between all {@link Thread}s that use the pool.	*/
	private final Sync				sync;

	/** The bounded queue that stores idle objects in the {@link PoolConcurrent}.					*/
	private final QueueBounded<T>	queue;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * Creates an empty pool with a fixed capacity and managed by the provided
	 * {@link Factory} implementation.
	 *
	 * @param capacity	The capacity of the pool.
	 * @param factory	The {@link Factory} implementation to use.
	 */
	public PoolConcurrent(final int capacity, final Factory<T> factory) {
		maxWait = Long.MAX_VALUE;
		this.factory = factory;
		sync = new Sync();
		queue = new QueueBounded<>(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * Acquires an object from the pool according to the following algorithm:
	 * <ul>
	 * <li>If the size of the pool is at capacity and no objects are present
	 *     then wait up to <code>maxWait</code> for an object to become
	 *     available.
	 * <li>Any pooled objects are validated by the {@link Factory}.
	 *     Invalid objects are destroyed and removed from the pool until
	 *     either the pool is purged or a valid object is found and returned.
	 * <li>Otherwise if the pool is empty, a new object is created from
	 *     the {@link Factory} and returned, which increments the size of
	 *     the pool.
	 * </ul>
	 *
	 * @return An instance of a pooled object.
	 * @throws Exception Occurs for various reasons.
	 */
	public final T acquire() throws Exception {
		long timeout = maxWait;

		log.debug("Acquiring an object from the pool");
		sync.lock();
		try {
			while (size == queue.getCapacity() && queue.isEmpty()) {
				if (timeout > 0) {
					timeout = sync.awaitNanos(timeout);
				} else {
					log.throwRuntimeException(new NoSuchElementException("Cannot acquire object from the pool"));
				}
			}

			while (!queue.isEmpty() && !factory.validate(queue.peek())) {
				log.debug("Removing invalid object from the pool");
				factory.destroy(queue.dequeue());
				size--;
			}

			if (queue.isEmpty()) {
				log.debug("Creating new object from the factory");
				size++;
				return factory.create();
			}

			return queue.dequeue();
		} finally {
			sync.unlock();
		}
	}

	/**
	 * Returns the abandoned object to the pool making it immediately
	 * available for reacquisition. 
	 * <p>
	 * If any threads are waiting to acquire an object from the pool, one
	 * waiting thread will be notified about the object availability.
	 * 
	 * @param t	The object to abandon and return to the pool.
	 */
	public final void abandon(final T t) {
		log.debug("Returning object to the pool");

		sync.lock();
		try {
			queue.enqueue(t);

			sync.signal();
		} finally {
			sync.unlock();
		}
	}

	/**
	 * Clears the pool by destroying every idle object.
	 */
	public final void clear() {
		sync.lock();
		try {
			while (!queue.isEmpty()) {
				factory.destroy(queue.dequeue());
			}
			size = 0;
		} finally {
			sync.unlock();
		}
	}

	public final int getCapacity() {
		return queue.getCapacity();
	}

	/**
	 * Returns the maximum wait time in milliseconds for an object to become
	 * available in the pool before throwing a {@link NoSuchElementException}.
	 *
	 * @return the maximum wait time for an object to become available.
	 */
	public final long getMaxWait() {
		return maxWait / 1000000;
	}

	/**
	 * Sets the maximum wait time in milliseconds for an object to become
	 * available in the pool.
	 *
	 * @param maxWait The maximum millisecond wait time value to set.
	 */
	public final void setMaxWait(final int maxWait) {
		this.maxWait = maxWait * 1000000L;
	}

}
