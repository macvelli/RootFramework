/*
 * PoolSimple.java
 * 
 * Last Modified: 03/12/2016
 */
package root.pool;

import root.data.structure.QueueBounded;
import root.log.Log;

/**
 * A simple, non-thread-safe, generic object pool that cooperates with a
 * {@link root.pool.Factory} interface implementation to manage the creation,
 * validation, and destruction of pooled objects.
 * 
 * @author esmith
 * @version 1.0
 * 
 * @param <T>
 */
public final class PoolSimple<T> {

	// <><><><><><><><><><><><><><><> Constants ><><><><><><><><><><><><><><><>

	private static final Log log = new Log(PoolSimple.class);

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	/** The size of the {@link PoolSimple}.										*/
	private int						size;

	/** The capacity of this simple pool.										*/
	private final int				capacity;

	/** The {@link Factory} implementation for this {@link PoolSimple}.			*/
	private final Factory<T>		factory;

	/** The bounded queue that stores idle objects in the {@link PoolSimple}.	*/
	private final QueueBounded<T>	queue;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * Creates an empty pool with a fixed capacity and managed by the provided
	 * {@link Factory} implementation.
	 *
	 * @param capacity	The capacity of the pool.
	 * @param factory	The {@link Factory} implementation to use.
	 */
	public PoolSimple(final int capacity, final Factory<T> factory) {
		this.capacity = capacity;
		this.factory = factory;
		this.queue = new QueueBounded<>(capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * Acquires an object from the pool according to the following algorithm:
	 * <ul>
	 * <li>If the size of the pool is at capacity and no objects are present
	 *     then wait up to <code>maxWait</code> for an object to become
	 *     available.
	 * <li>Any pooled objects are validated by the {@link Factory}.
	 *     Invalid objects are destroyed and removed from the pool until
	 *     either the pool is purged or a valid object is found and returned.
	 * <li>Otherwise if the pool is empty, a new object is created from
	 *     the {@link Factory} and returned, which increments the size of
	 *     the pool.
	 * </ul>
	 *
	 * @return An instance of a pooled object.
	 * @throws Exception Occurs for various reasons.
	 */
	public final T acquire() {
		// 1. If the pool is full but the queue is empty, throw an exception
		if (size == capacity && queue.isEmpty()) {
			log.throwRuntimeException(new IllegalStateException("PoolSimple is full but queue is empty"));
		}

		log.debug("Acquiring an object from the pool");
		while (!queue.isEmpty() && !factory.validate(queue.peek())) {
			log.debug("Removing invalid object from the pool");
			factory.destroy(queue.dequeue());
			size--;
		}

		if (queue.isEmpty()) {
			log.debug("Creating new object from the factory");
			size++;
			return factory.create();
		}

		return queue.dequeue();
	}

	/**
	 * Returns the abandoned object to the pool making it immediately
	 * available for reacquisition. 
	 * <p>
	 * If any threads are waiting to acquire an object from the pool, one
	 * waiting thread will be notified about the object availability.
	 * 
	 * @param t	The object to abandon and return to the pool.
	 */
	public final void abandon(final T t) {
		log.debug("Returning object to the pool");
		queue.enqueue(t);
	}

	/**
	 * Clears the pool by destroying every idle object.
	 */
	public final void clear() {
		while (!queue.isEmpty()) {
			factory.destroy(queue.dequeue());
		}
		size = 0;
	}

	public final int getCapacity() {
		return capacity-size;
	}

}	// End PoolSimple
