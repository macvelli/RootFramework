/* Copyright 2010 Edward Smith
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package root.pool;

/**
 * An object lifecycle management interface specifically designed to work
 * with the {@link PoolConcurrent}.  An implementation of this interface must exist
 * in order for the pool to properly manage object instances.
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface Factory<T> {

	/**
	 * Creates a new object instance for the pool.
	 * 
	 * @return a new object instance for the pool.
	 */
	public T create();

	/**
	 * Destroys a pooled object.  Normally called by the {@link PoolConcurrent} when
	 * a <code>validate()</code> method call returns <code>false</code>.
	 * 
	 * @param o the pooled object to destroy.
	 */
	public void destroy(T o);

	/**
	 * Validates a pooled object to ensure it is still in an acceptable
	 * state before allowing the {@link PoolConcurrent} to release it for use.
	 * 
	 * @param o the pooled object to validate
	 * @return <code>true</code> if the object is valid, <code>false</code> otherwise.
	 */
	public boolean validate(T o);

}
