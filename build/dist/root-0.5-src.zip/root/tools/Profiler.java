package root.tools;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Profiler {

	// TODO: Should we also have a Profiler name?
	private final int numTestRepetitions;
	private final int numIterationsPerTest;
	private final List<Test> tests;

	public Profiler(final int numTestRepetitions, final int numIterationsPerTest) {
		this.numTestRepetitions = numTestRepetitions;
		this.numIterationsPerTest = numIterationsPerTest;
		this.tests = new ArrayList<Test>();
	}

	public void add(final Test test) {
		test.timings = new long[numTestRepetitions];
		tests.add(test);
	}

	public void runTests() throws Exception {
		for (int i=0; i < numTestRepetitions; i++) {
			for (Test t : tests) {
				t.execute(numIterationsPerTest);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		for (Test t : tests) {
			if (builder.length() > 0) {
				builder.append('\n');
			}
			builder.append(t);
		}

		return builder.toString();
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Inner Classes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public abstract class Test {

		private int iteration;
		private int minIndex;
		private int maxIndex;
		private long elapsedTime;
		private long totalElapsedTime;
		private long[] timings;
		private final String name;

		protected Test(final String name) {
			this.name = name;
		}

		protected void start() {
			elapsedTime = System.nanoTime();
		}

		protected void end() {
			elapsedTime = System.nanoTime()-elapsedTime;
			totalElapsedTime += elapsedTime;

			if (iteration > 0) {
				if (timings[minIndex] > elapsedTime) {
					minIndex = iteration;
				} else if (timings[maxIndex] < elapsedTime) {
					maxIndex = iteration;
				}
			}

			timings[iteration++] = elapsedTime;
		}

		protected abstract void execute(int numIterations) throws Exception;

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();

			builder.append(name).append(':');
			// TODO: StringBuilder only supports appending single instances, not arrays of values
			builder.append("\n\tTimings: ").append(Arrays.toString(timings));
			builder.append("\n\tMin:     ").append(timings[minIndex]);
			builder.append("\n\tMax:     ").append(timings[maxIndex]);
			builder.append("\n\tTotal:   ").append(totalElapsedTime);
			builder.append("\n\tAverage: ").append(getAverage());

			return builder.toString();
		}

		private BigDecimal getAverage() {
			BigDecimal average = new BigDecimal(totalElapsedTime - timings[minIndex] - timings[maxIndex]);
			average = average.divide(new BigDecimal(1000000000.0));

			return average.divide(new BigDecimal(numTestRepetitions - 2), 6, RoundingMode.HALF_UP);
		}

	}	// End Test

}	// End Profiler
