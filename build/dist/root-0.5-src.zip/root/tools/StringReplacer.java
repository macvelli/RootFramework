package root.tools;

import root.data.structure.CharArrayCollector;
import root.lang.Characters;
import root.lang.Itemizer;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * TODO: Need static methods to replace/remove in a single call w/out building up an entire <code>StringReplacer</code> object
 * 
 * @author Ed Smith
 */
public class StringReplacer {

	private final CharArrayCollector targets;
	private final CharArrayCollector replacements;

	public StringReplacer() {
		targets = new CharArrayCollector();
		replacements = new CharArrayCollector();
	}

	public void replace(final String target, final char... replacement) {
		targets.add(target);
		replacements.add(Safe.notEmpty(replacement) ? replacement : Characters.empty);
	}

	public void replace(final String target, final String replacement) {
		targets.add(target);
		if (Safe.notEmpty(replacement)) {
			replacements.add(replacement);
		} else {
			replacements.add(Characters.empty);
		}
	}

	public void replace(final CharSequence target, final CharSequence replacement) {
		targets.add(target);
		if (Safe.notEmpty(replacement)) {
			replacements.add(replacement);
		} else {
			replacements.add(Characters.empty);
		}
	}

	public void remove(final char... target) {
		targets.add(target);
		replacements.add(Characters.empty);
	}

	public void remove(final String target) {
		targets.add(target);
		replacements.add(Characters.empty);
	}

	public void remove(final CharSequence target) {
		targets.add(target);
		replacements.add(Characters.empty);
	}

	public String process(final String s) {
		final ParamStrBuilder builder = new ParamStrBuilder(s.length());
		final Itemizer<char[]> i = targets.iterator();
		// TODO: Make this Fast!
		final char[] c = s.toCharArray();
		char[] t, r;

		// Build the replacement String
		int k, l, offset = 0;
		for (int j=0; j < c.length; j++) {
			for (i.reset(); i.hasNext();) {
				t = i.next();
				if (c.length >= (t.length + j)) {
					for (k=j, l=0; l < t.length && c[k++] == t[l]; l++);
					if (l == t.length) {
						// Found match
						if (offset < j) {
							builder.append(c, offset, j-offset);
						}
						r = replacements.get(i.getIndex());
						if (r != Characters.empty) {
							builder.append(r);
						}
						offset = k;
						j = k-1;
						break;
					}
				}
			}
		}

		// Return the original String if no replacements were made
		if (offset == 0) {
			return s;
		}

		// Add the end of the String since the last replacement
		if (offset < c.length) {
			builder.append(c, offset, c.length-offset);
		}

		return builder.toString();
	}

	public static void main(String[] args) {
		StringReplacer replacer = new StringReplacer();
		replacer.replace("Foo", "BarWilly");
		replacer.replace("ABC", "Don't Hate the Playa");
		replacer.replace("123", "789");
		replacer.remove('\'');

		System.out.println(replacer.process("This has nothing to replace"));
		System.out.println(replacer.process("This has Foo to replace"));
		System.out.println(replacer.process("This has Foo to replace as well as ABC"));
		System.out.println(replacer.process("This has Foo to replace, ABC to replace, and 123 to replace"));
		System.out.println(replacer.process("This has Foo, ABC, and 123 to replace AB12Fo"));
		System.out.println(replacer.process("ABC123FooWoah"));
		System.out.println(replacer.process("FooFooFooFoo123123123ABCFooABC123"));
		System.out.println(replacer.process("Zaxby's"));
	}

}	// End StringReplacer
