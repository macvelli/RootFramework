package root.log;

import java.io.PrintStream;
import java.util.logging.ErrorManager;
import java.util.logging.Filter;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;

public class SysoutHandler extends Handler {

	private Level		level;
	private Filter		filter;
	private Formatter	formatter;

	private final PrintStream out;

	public SysoutHandler() {
		out = System.out;
		level = Level.ALL;

        final LogManager manager = LogManager.getLogManager();
        final String formatter = manager.getProperty(getClass().getName()+ ".formatter");
    	try {
			this.formatter = (formatter == null) ? new EchoFormatter() : (Formatter) getClass().getClassLoader().loadClass(formatter).newInstance();
		} catch (Throwable t) {}
	}

	@Override
	public Filter getFilter() {
		return filter;
	}

	@Override
	public void setFilter(final Filter newFilter) throws SecurityException {
		filter = newFilter;
	}

	@Override
	public Formatter getFormatter() {
		return formatter;
	}

	@Override
	public void setFormatter(final Formatter newFormatter) throws SecurityException {
		newFormatter.getClass();
		formatter = newFormatter;
	}

	@Override
	public Level getLevel() {
		return level;
	}

	@Override
	public void setLevel(final Level newLevel) throws SecurityException {
		newLevel.getClass();
		level = newLevel;
	}

	@Override
	public void close() throws SecurityException {
		out.flush();
	}

	@Override
	public void flush() {
		out.flush();
	}

	@Override
	public void publish(final LogRecord record) {
		if (record.getLevel().intValue() >= level.intValue()
				&& (filter == null || filter.isLoggable(record))) {

			try {
				out.print(formatter.format(record));
				if (record.getThrown() != null)
					record.getThrown().printStackTrace(out);
			} catch (Exception e) {
				reportError(null, e, ErrorManager.FORMAT_FAILURE);
			}
		}
	}

}	// End SysoutHandler
