package root.log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * "java.util.logging.ConsoleHandler will only load formatter classes from the system classloader." 
 * 
 * That's nice.  How the hell do you get around that?
 * 
 * The only solution I have found is to put all your java.util.logging custom crap in a JAR under
 * the JRE's lib\ext directory.
 * 
 * @author smithed
 *
 */
public class JBossFormatter extends Formatter {

	private static final String	lineSep;

	private static final DateFormat time = new SimpleDateFormat("HH:mm:ss,SSS");

	private static final HashMap<Level, char[]>	levelMap;

	static {
		lineSep = System.getProperty("line.separator");

		levelMap = new HashMap<Level, char[]>(11);
		levelMap.put(Level.FINE,	new char[] {' ','D','E','B','U','G',' '});
		levelMap.put(Level.INFO,	new char[] {' ','I','N','F','O',' ',' '});
		levelMap.put(Level.WARNING,	new char[] {' ','W','A','R','N',' ',' '});
		levelMap.put(Level.SEVERE,	new char[] {' ','F','A','I','L',' ',' '});
		levelMap.put(Level.FINEST,	new char[] {' ','T','R','A','C','E',' '});
	}

	@Override
	public String format(final LogRecord record) {
		final StringBuilder builder = new StringBuilder(256);

		// TODO: Write my own implementation here...or just find the one I already wrote wherever it might be (notice I can use the millis directly!!)
		// TODO: HMST.format(long) should do the trick!!
		synchronized (time) {
			builder.append(time.format(new Date(record.getMillis())));
		}
		builder.append(levelMap.get(record.getLevel()));
		populateName(record.getLoggerName(), builder);
		builder.append(' ').append(record.getMessage()).append(lineSep);

		return builder.toString();
	}

	private void populateName(final String logName, final StringBuilder builder) {
		final char[] c = logName.toCharArray();
		int i = c.length;

		while (i > 0)
			if (c[--i] == '.') {
				i++;
				break;
			}

		builder.append('[').append(c, i, c.length - i).append(']');
	}

}	// End JBossFormatter
