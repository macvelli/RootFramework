package root.xml;

import root.lang.Characters;
import root.lang.ParamStrBuilder;

/**
 * TODO Incorporate this into XMLBuilder
 * 
 * @author esmith
 * @version 1.0
 */
public class Attribute extends Node<Attribute> {

	public Attribute(final String name, final String value) {
		super(name, value);
	}

	public void extract(Characters chars) {
		chars.append(name).append('=');
		chars.append('"').append(value).append('"');
	}

	@Override
	public String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(name.length() + value.length() + 3);
		extract(chars);
		return chars.toString();
	}

}	// End Attribute
