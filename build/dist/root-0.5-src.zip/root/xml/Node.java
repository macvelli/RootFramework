package root.xml;

import root.lang.Extractable;


public abstract class Node<T extends Node<T>> implements Extractable {

	protected final String name;
	protected String value;
	protected T next;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	protected Node(final String name) {
		this.name = name;
	}

	protected Node(final String name, final String value) {
		this.name = name;
		this.value = value;
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

}	// End Node
