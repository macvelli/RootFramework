package root.xml;

/**
 * 
 * @author esmith
 *
 * @param <T>
 */
public interface XML<T> {

	void marshall(XMLBuilder xmlBuilder);

	T unmarshall(XMLParser xmlParser);

}
