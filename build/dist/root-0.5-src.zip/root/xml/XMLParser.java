package root.xml;

import root.data.structure.ListLinked;
import root.lang.Constants;

public final class XMLParser {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	public static final Element parse(final String xml) {
		return parse(xml, 0);
	}

	private static final Element parse(final String xml, final int indent) {
		final Element e;
		final int startTagOpenIndex = xml.indexOf('<') + 1;

		if (startTagOpenIndex == 0) {
			throw new XMLParserException("Cannot find element tag in " + xml);
		}

		int startTagCloseIndex = xml.indexOf('>', startTagOpenIndex);

		if (xml.charAt(startTagCloseIndex - 1) == '/') {
			// Create and return an empty element
			e = new Element(xml.substring(startTagOpenIndex, startTagCloseIndex - 1), Constants.EMPTY_STRING, indent);
			e.fragmentLength = startTagCloseIndex + 1;
			return e;
		}

		final String openTagName = xml.substring(startTagOpenIndex, startTagCloseIndex);

		int endTagOpenIndex = xml.indexOf('<', ++startTagCloseIndex);
		if (endTagOpenIndex == 0) {
			throw new XMLParserException("Cannot find end tag </" + openTagName + "> from index " + startTagCloseIndex);
		}

		if (xml.charAt(endTagOpenIndex + 1) == '/') {
			final int endTagCloseIndex = xml.indexOf('>', endTagOpenIndex + 2);
			final String closeTagName = xml.substring(endTagOpenIndex + 2, endTagCloseIndex);

			if (!openTagName.equals(closeTagName)) {
				throw new XMLParserException("Open Tag Name <" + openTagName + ">/Close Tag Name </" + closeTagName + "> mismatch at index " + endTagOpenIndex);
			}

			e = new Element(openTagName, xml.substring(startTagCloseIndex, endTagOpenIndex), indent);
			e.fragmentLength = endTagCloseIndex + 1;
			return e;
		} else {
			final ListLinked<Element> children = new ListLinked<>();

			do {
				final Element child = parse(xml.substring(endTagOpenIndex), indent + 1);
				children.add(child);

				endTagOpenIndex = xml.indexOf('<', endTagOpenIndex + child.fragmentLength);
				if (endTagOpenIndex == 0) {
					throw new XMLParserException("Cannot find end tag </" + openTagName + "> from index " + startTagCloseIndex);
				}
			} while (xml.charAt(endTagOpenIndex + 1) != '/');

			final int endTagCloseIndex = xml.indexOf('>', endTagOpenIndex + 2);
			final String closeTagName = xml.substring(endTagOpenIndex + 2, endTagCloseIndex);

			if (!openTagName.equals(closeTagName)) {
				throw new XMLParserException("Open Tag Name <" + openTagName + ">/Close Tag Name </" + closeTagName + "> mismatch at index " + endTagOpenIndex);
			}

			e = new Element(openTagName, children, indent);
			e.fragmentLength = endTagCloseIndex + 1;
			return e;
		}
	}

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final String xml;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public XMLParser(final String xml) {
		this.xml = xml;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final ListLinked<XMLParser> getFragments(final String elementName) {
		final ListLinked<XMLParser> fragments = new ListLinked<>();
		final String startTag = '<' + elementName + '>';
		final String endTag = "</" + elementName + '>';
		int beginIndex, endIndex;

		beginIndex = xml.indexOf(startTag);
		while (beginIndex >= 0) {
			beginIndex += startTag.length();
			endIndex = xml.indexOf(endTag, beginIndex);

			if (endIndex < 0) {
				throw new XMLParserException("Cannot find end tag " + endTag);
			}

			fragments.add(new XMLParser(xml.substring(beginIndex, endIndex)));

			endIndex += endTag.length();
			beginIndex = xml.indexOf(startTag, endIndex);
		}

		return fragments;
	}

	public final String getString() {
		return xml;
	}

	public final String getString(final String elementName) {
		final String startTag = '<' + elementName + '>';
		final String endTag = "</" + elementName + '>';
		int beginIndex, endIndex;

		beginIndex = xml.indexOf(startTag);
		if (beginIndex >= 0) {
			beginIndex += startTag.length();
			endIndex = xml.indexOf(endTag, beginIndex);

			if (endIndex < 0) {
				throw new XMLParserException("Cannot find end tag " + endTag);
			}

			return xml.substring(beginIndex, endIndex);
		}

		return null;
	}

	@Override
	public final String toString() {
		return xml;
	}

}
