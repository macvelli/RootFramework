package root.xml;

import root.data.structure.ListLinked;
import root.lang.Characters;
import root.lang.Extractable;
import root.lang.ParamStrBuilder;
import root.util.Safe;

/**
 * 
 * @author esmith
 */
public final class Element implements Extractable {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	int fragmentLength;

	private final String name;
	private String value;

	private final int indent;
	private final ListLinked<Element> elementList;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	Element(final String name, final ListLinked<Element> children, final int indent) {
		this.name = name;
		this.indent = indent;
		elementList = children;
	}

	public Element(final String name, final int indent) {
		this.name = name;
		this.indent = indent;
		elementList = new ListLinked<>();
	}

	public Element(final String name, final String value, final int indent) {
		this.name = name;
		this.value = value;
		this.indent = indent;
		elementList = null;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void addChild(final Element e) {
		elementList.add(e);
	}

	public final Element addChild(final String name) {
		return elementList.echo(new Element(name, indent+1));
	}

	public final void addChild(final String name, final String value) {
		elementList.add(new Element(name, value, indent+1));
	}

	public final Element getFirstChild() {
		return (elementList.isEmpty()) ? null : elementList.get(0);
	}

	public final String getName() {
		return name;
	}

	public final String getValue() {
		return value;
	}

	@Override
	public final void extract(final Characters chars) {
		// 1. Indent element
		for (int i=0; i < indent; i++) {
			chars.append('\t');
		}

		// 2. Create the opening element tag
		chars.append('<').append(name);

		// 3. Either append the element value or all of its sub-elements
		if (Safe.isEmpty(value) && (elementList == null || elementList.isEmpty())) {
			chars.append('/','>','\n');
		} else {
			chars.append('>');

			if (!Safe.isEmpty(value)) {
				chars.append(value);
			} else {
				chars.append('\n');
				for (Element e : elementList) {
					chars.append(e);
				}

				for (int i=0; i < indent; i++) {
					chars.append('\t');
				}
			}

			// 4. Close off the element tag
			chars.append('<','/').append(name).append('>','\n');
		}
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(1024);
		extract(chars);
		return chars.toString();
	}

}
