package root.xml;

import root.data.structure.StackArray;
import root.lang.Constants;

/**
 * 
 * @author esmith
 */
public final class XMLBuilder {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private Element current;
	private Element root;
	private final StackArray<Element> elementStack;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public XMLBuilder() {
		elementStack = new StackArray<>();
	}

	public XMLBuilder(final String rootElementName) {
		root = new Element(rootElementName, 0);
		current = root;
		elementStack = new StackArray<Element>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void addElement(final String name, final Object value) {
		current.addChild(name, (value == null) ? Constants.EMPTY_STRING : value.toString());
	}

	public final void addElement(final String name, final String value) {
		current.addChild(name, value);
	}

	public final void addChild(final String name) {
		if (root == null) {
			root = new Element(name, 0);
			current = root;
		} else {
			final Element e = current.addChild(name);
			elementStack.push(current);
			current = e;
		}
	}

	public final void closeChild() {
		current = elementStack.pop();
	}

	public final void closeChild(final String childName) {
		do {
			current = elementStack.pop();
		} while (!current.getName().equals(childName));
	}

	public final void closeChildren() {
		current = elementStack.oldest();
		elementStack.clear();
	}

	@Override
	public final String toString() {
		return root.toString();
	}

}
