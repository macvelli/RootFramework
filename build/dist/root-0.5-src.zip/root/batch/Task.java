package root.batch;

import root.clock.Stopwatch;
import root.data.structure.ListArray;
import root.thread.Sync;

public abstract class Task<R> implements Runnable {

	private boolean executing;

	private final Sync	sync;

	protected R						result;

//	protected Log					log;

	protected final Stopwatch			t;

	protected final ListArray<TaskError>	errors;

	protected Task() {
		t = new Stopwatch();
		sync = new Sync();
//		log = new Log(getClass());
		errors = new ListArray<TaskError>();
		executing = true;
	}

	public final ListArray<TaskError> getErrors() {
		return errors;
	}

	public final R getResult() {
		sync.lock();
		while (executing)
			try { sync.await(); } catch (InterruptedException e) {}
		sync.unlock();

		return result;
	}

	public final Stopwatch getTimer() {
		sync.lock();
		while (executing)
			try { sync.await(); } catch (InterruptedException e) {}
		sync.unlock();

		return t;
	}

	public final void run() {
		t.start();
		try {
			execute();
		} catch (Throwable e) {
			t.failed();
//			log.error("A runtime error occurred", e);
		} finally {
//			log.close();
		}
		t.stop();
		sync.lock();
		try {
			executing = false;
			sync.signal();
		} finally {
			sync.unlock();
		}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~ Protected Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	protected abstract void execute() throws Throwable;

}	// End Task
