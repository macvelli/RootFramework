package root.batch;

public class TaskError {

	protected String msg;

	@Override
	public String toString() {
		return msg;
	}

}	// End TaskError
