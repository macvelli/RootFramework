package root.batch;

import java.util.logging.Formatter;
import java.util.logging.Handler;

import root.clock.Stopwatch;
import root.data.structure.ListArray;
import root.thread.ThreadPool;

public class Process<T extends Task<?>> {

	private static final ListArray<Thread>	processes = new ListArray<Thread>();

//	private final Log			log;
	private final Stopwatch			t;
	private final String		name;
	private final ListArray<T>	tasks;
	private final ListArray<T>	tasksWithErrors;
	private final ThreadPool	threadPool;

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Static Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static final void join() {
		for (Thread t : processes)
			try { t.join(); } catch (InterruptedException e) {}
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Instance Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public Process(final String name, final ThreadPool threadPool) {
		this.name = name;
		this.threadPool = threadPool;
		t = new Stopwatch();
//		log = new Log(name);
		tasks = new ListArray<T>();
		tasksWithErrors = new ListArray<T>();
	}

	public boolean hasTasksWithErrors() {
		return !tasksWithErrors.isEmpty();
	}

	public ListArray<T> getTasksWithErrors() {
		return tasksWithErrors;
	}

	public void add(final T task) {
		tasks.add(task);
	}

	public void execute() {
		final Thread proc = new Thread(new Runner());
		processes.add(proc);
		proc.start();
	}

	public void setHandler(final Handler h, final Formatter f) {
//		log.setHandler(h, f);
	}

	public String getName() {
		return name;
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private void logResults(final Stopwatch[] timers) {
//		log.info("Package Name: " + name);
//		log.info("Execution Started: " + t.getStartDate());
//		log.info("Execution Completed: " + t.getEndDate());
//		log.info("Total Execution Time: " + t.getTotal());
//
//		log.info("\n****************************************************************************");
//
//		for (Watch w : timers) {
//			log.info("\n{P} {P}", w.getName(), w.hasFailed() ? "failed" : "succeeded");
//			log.info("Execution Started: " + w.getStartDate());
//			log.info("Execution Completed: " + w.getEndDate());
//			log.info("Total Execution Time: " + w.getTotal());
//			log.info("Number of records processed: " + w.getNumProcessed());
//		}
//
//		log.info("\n****************************************************************************");
	}

//	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	private class Runner implements Runnable {

		public void run() {
			final Stopwatch[] timers = new Stopwatch[tasks.getSize()];

			try {
				t.start();

				threadPool.execute(tasks);

				int i=0;
				for (T t : tasks) {
					timers[i++] = t.getTimer();
					if (!t.errors.isEmpty())
						tasksWithErrors.add(t);
				}

				t.stop();

				logResults(timers);
			} finally {
//				log.close();
			}
		}
		
	}	// End Runner

}	// End Process
