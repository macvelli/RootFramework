/*
 * Open source license text goes here.
 */

package root.jdbc;

import java.sql.SQLException;

import root.log.Log;

/**
 * 
 * @author esmith
 */
final class TransactionLocalScope {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final Log log = new Log(TransactionLocalScope.class);

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private PooledConnection connection;
	private PooledDataSource dataSource;

	private final IsolationLevel isoLevel;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	TransactionLocalScope(final IsolationLevel isoLevel) {
		this.isoLevel = isoLevel;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	final void commit() throws SQLException {
		if (connection != null) {
			connection.commit();
		}
	}

	final PooledConnection getConnection() {
		return connection;
	}

	final PooledConnection initialize(final PooledDataSource database, final PooledConnection con) throws SQLException {
		this.dataSource = database;
		this.connection = con;
		con.initTransaction(isoLevel);
		log.debug("Initialized {P}", con);
		return con;
	}

	final boolean isBeginning() {
		return dataSource == null;
	}

	final boolean manages(final PooledDataSource dataSource) {
		return (this.dataSource == dataSource || this.dataSource.equals(dataSource));
	}

	final void rollback() throws SQLException {
		if (connection != null) {
			connection.rollback();
		}
	}

//	final Connection initialize(final PooledDataSource dataSource, final Connection con) throws SQLException {
//		this.dataSource = dataSource;
//		this.connection = new TransactionJunction(con, isoLevel);
//		log.debug("Created new {P}", con);
//		return this.connection;
//	}

}
