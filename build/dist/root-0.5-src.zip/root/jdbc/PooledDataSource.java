/*
 * Open source license text goes here.
 */

package root.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import root.lang.ParamStrBuilder;
import root.log.Log;
import root.pool.Factory;
import root.pool.PoolConcurrent;

/**
 * Why this class does not implement {@link DataSource}:
 * 		+ The only method I need is public Connection getConnection()
 * 		+ There are specific methods on this class that cannot be accessed via a {@link DataSource} reference
 * 
 * @author esmith
 */
public class PooledDataSource {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final Log log = new Log(PooledDataSource.class);

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	/** The size of the {@link PreparedStatement} cache to create on each {@link PooledConnection}	*/
	private int						stmtCacheSize;

	/** The maximum amount of time a {@link PooledConnection} may be idle before it is recycled		*/
	private long					maxIdleTime;

	/**	The URL connection string used to create a JDBC connection to the database				 	*/
	private final String			url;

	/**	The {@link Driver} used to connect to the database with the specified URL		 			*/
	private final Driver			driver;

	/**	The set of {@link Properties} used to connect to the database with the {@link Driver}		*/
	private final Properties		dbProperties;

	/**	The {@link PoolConcurrent} of {@link PooledConnection} managed by this {@link PooledDataSource}		*/
	final PoolConcurrent<PooledConnection>	pool;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * Creates a {@link PooledDataSource} using the specified driver,
	 * URL connection string, and a default pool capacity of <code>2</code>.
	 * 
	 * @param driverName	The fully qualified JDBC driver class name.
	 * @param url			The URL connection string.
	 */
	public PooledDataSource(final String driverName, final String url) {
		this(driverName, url, 2);
	}

	/**
	 * Creates a {@link PooledDataSource} using the specified JDBC driver,
	 * URL connection string, and specified pool capacity.
	 *
	 * @param driverName	The fully qualified JDBC driver class name.
	 * @param url			The URL connection string.
	 * @param capacity		The pool capacity.
	 */
	public PooledDataSource(final String driverName, final String url, final int capacity) {
		log.debug("Creating PooledDataSource from JDBC driver {P} [URL={P}]", driverName, url);

		try {
			Class.forName(driverName);
            driver = DriverManager.getDriver(url);
		} catch (Throwable t) {
			throw new DatabaseException("Cannot load JDBC driver: " + driverName, t);
		}

		dbProperties = new Properties();
		pool = new PoolConcurrent<>(capacity, new PooledConnectionFactory());
		this.url = url;
	}

	/**
	 * Creates a {@link PooledDataSource} using the specified JDBC driver,
	 * URL connection string, database username, password, and pool capacity.
	 * 
	 * TODO: Refactor this to take a Properties object since there are vendor-specific properties that can be set to improve performance
	 *
	 * @param driverName	The fully qualified JDBC driver class name.
	 * @param url			The URL connection string.
	 * @param username		The database username.
	 * @param password		The password for the database username.
	 * @param capacity		The pool capacity.
	 */
	public PooledDataSource(final String driverName, final String url, final String username, final String password, final int capacity) {
		this(driverName, url, capacity);
		if (username != null) dbProperties.put("user", username);
		if (password != null) dbProperties.put("password", password);
	}

	protected PooledDataSource(final int capacity) {
		this.dbProperties = null;
		this.driver = null;
		this.url = null;
		this.pool = new PoolConcurrent<>(capacity, getPooledConnectionFactory());
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * Gracefully closes all {@link PooledConnection} objects contained in the
	 * {@link PooledDataSource}.
	 */
	public final void close() {
		pool.clear();
	}

	/**
	 * Acquires and returns a pooled {@link Connection} from the {@link PoolConcurrent},
	 * or throws an {@link DatabaseException} if unsuccessful.
	 *
	 * @return	A JDBC connection from the pool.
	 * @throws	An {@link DatabaseException} if connection cannot be acquired.
	 */
	public final PooledConnection getConnection() {
		final TransactionLocalScope txnScope = Transaction.getLocalScope();

		try {
			if (txnScope == null || !txnScope.manages(this)) {
				return pool.acquire();
			}

			return (txnScope.isBeginning())
					? txnScope.initialize(this, pool.acquire())
					: txnScope.getConnection();
		} catch (Exception e) {
			throw new DatabaseException("Cannot acquire a connection from the pool", e);
		}
	}

	/**
	 * Returns the maximum number of seconds a connection may be idle in the
	 * pool before it is recycled.
	 *
	 * @return the maximum number of seconds a connection may be idle.
	 */
	public final long getMaxIdleTime() {
		return maxIdleTime / 1000;
	}

	/**
	 * Sets the maximum number of seconds a connection may be idle in the
	 * pool before it is recycled. A value less than or equal to zero is
	 * ignored.
	 *
	 * @param maxIdleTime The maximum number of seconds a connection may be idle.
	 */
	public final void setMaxIdleTime(final long maxIdleTime) {
		this.maxIdleTime = maxIdleTime * 1000;
	}

	/**
	 * Returns the maximum amount of time in milliseconds the pool will wait
	 * for a connection to free up before erroring out.
	 *
	 * @return the maximum amount of time the pool will wait for a connection.
	 */
	public final long getMaxWait() {
		return pool.getMaxWait();
	}

	/**
	 * Sets  the maximum amount of time in milliseconds the pool will wait
	 * for a connection to free up before erroring out. A value less than or
	 * equal to zero is ignored and the pool will wait indefinitely.
	 *
	 * @param maxWait The maximum amount of time the pool will wait for a connection.
	 */
	public final void setMaxWait(final int maxWait) {
		pool.setMaxWait(maxWait);
	}

	/**
	 * Returns the size of the {@link PreparedStatement} cache for each pooled
	 * {@link Connection}.
	 *
	 * @return the size of the {@link PreparedStatement} cache.
	 */
	public final int getStmtCacheSize() {
		return stmtCacheSize;
	}

	/**
	 * Sets the size of the {@link PreparedStatement} cache for each
	 * {@link PooledConnection}. The default is <code>0</code> where no
	 * statement cache is created.
	 * 
	 * @param stmtCacheSize the size of the {@link PreparedStatement} cache.
	 */
	public final void setStmtCacheSize(final int stmtCacheSize) {
		this.stmtCacheSize = stmtCacheSize;
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(512);

		builder.append("PooledDataSource [");
		builder.append("driver=").append(driver.getClass().getName());
		builder.append(", url=").append(url);
		builder.append(", stmt cache size=").append(stmtCacheSize);
		builder.append(", maxIdleTime=").append(maxIdleTime);
		builder.append(", maxWait=").append(pool.getMaxWait());
		builder.append(", poolCapacity=").append(pool.getCapacity());

		return builder.append(']').toString();
	}

	//  <><><><><><><><><><><><><> Protected Methods <><><><><><><><><><><><><>

	protected Factory<PooledConnection> getPooledConnectionFactory() {
		return new PooledConnectionFactory();
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	/**
	 * Defines the {@link Factory} implementation used by the {@link PoolConcurrent} for
	 * the {@link PooledConnection} objects.
	 * 
	 * @author esmith
	 */
	private class PooledConnectionFactory implements Factory<PooledConnection> {

		@Override
		public final PooledConnection create() {
			try {
				return new PooledConnection(PooledDataSource.this, driver.connect(url, dbProperties));
			} catch (SQLException e) {
				throw new DatabaseException(e);
			}
		}

		@Override
		public final void destroy(final PooledConnection c) {
			c.destroy();
		}

		@Override
		public final boolean validate(final PooledConnection c) {
			return !(c.hasError || c.t.hasExpired());
		}

	}	// End PooledConnectionFactory

}	// End PooledDataSource
