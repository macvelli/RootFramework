package root.jdbc;

import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import root.pool.Factory;
import root.pool.PoolConcurrent;

/**
 * TODO:
 * 		+ Have JndiDataSource extend PooledDataSource (done)
 * 		+ See if I can shoehorn a Factory<PooledConnection> into this where it pulls from dataSource.getConnection() instead of Driver
 * 
 * @author esmith
 */
public final class JndiDataSource extends PooledDataSource {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final DataSource dataSource;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public JndiDataSource(final String jndiName, final int capacity) {
		super(capacity);

		try {
			final InitialContext ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup("java:/comp/env/" + jndiName);
		} catch (Exception e) {
			throw new DatabaseException("JNDI lookup failed for DataSource named " + jndiName, e);
		}
	}

	//  <><><><><><><><><><><><><> Protected Methods <><><><><><><><><><><><><>

	protected final Factory<PooledConnection> getPooledConnectionFactory() {
		return new JndiPooledConnectionFactory();
	}

	//  <><><><><><><><><><><><><>< Private Classes ><><><><><><><><><><><><><>

	/**
	 * Defines the {@link Factory} implementation used by the {@link PoolConcurrent} for
	 * the {@link PooledConnection} objects.
	 * 
	 * @author esmith
	 */
	private class JndiPooledConnectionFactory implements Factory<PooledConnection> {

		@Override
		public final PooledConnection create() {
			try {
				return new PooledConnection(JndiDataSource.this, dataSource.getConnection());
			} catch (SQLException e) {
				throw new DatabaseException(e);
			}
		}

		@Override
		public final void destroy(final PooledConnection c) {
			c.destroy();
		}

		@Override
		public final boolean validate(final PooledConnection c) {
			return !(c.hasError || c.t.hasExpired());
		}

	}	// End JndiPooledConnectionFactory

}	// End JndiDataSource
