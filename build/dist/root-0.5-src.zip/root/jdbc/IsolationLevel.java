package root.jdbc;

import java.sql.Connection;

/**
 * 
 * @author esmith
 */
public enum IsolationLevel {

	DEFAULT				(-1),
	NONE				(Connection.TRANSACTION_NONE),
	READ_UNCOMMITTED	(Connection.TRANSACTION_READ_UNCOMMITTED),
	READ_COMMITTED		(Connection.TRANSACTION_READ_COMMITTED),
	REPEATABLE_READ		(Connection.TRANSACTION_REPEATABLE_READ),
	SERIALIZABLE		(Connection.TRANSACTION_SERIALIZABLE);

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final int isoLevel;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	private IsolationLevel(final int isoLevel) {
		this.isoLevel = isoLevel;
	}

	//  <><><><><><><><><><><><><>< Package Methods ><><><><><><><><><><><><><>

	final int getValue() { return isoLevel; }

	static final String toString(final int isoLevel) {
		if (isoLevel == READ_UNCOMMITTED.isoLevel) {
			return READ_UNCOMMITTED.name();
		}

		if (isoLevel == READ_COMMITTED.isoLevel) {
			return READ_COMMITTED.name();
		}

		if (isoLevel == REPEATABLE_READ.isoLevel) {
			return REPEATABLE_READ.name();
		}

		if (isoLevel == SERIALIZABLE.isoLevel) {
			return SERIALIZABLE.name();
		}

		return NONE.name(); 
	}

}
