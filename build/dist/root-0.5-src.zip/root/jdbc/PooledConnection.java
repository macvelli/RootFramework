package root.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

import root.cache.CacheLRU;
import root.clock.Timer;
import root.lang.ParamStrBuilder;
import root.log.Log;
import root.util.Jdbc;

/**
 * TODO:
 * 		+ I think there are still too many methods on this class...do a deep
 * 		  dive analysis on the methods once SQLBroker is back up and running
 * 
 * @author esmith
 */
public final class PooledConnection {

	// <><><><><><><><><><><><><>< Static Artifacts ><><><><><><><><><><><><><>

	private static final Log log = new Log(PooledConnection.class);

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	/**	Set to <code>true</code> when the underlying connection throws an {@link SQLException}								*/
	boolean hasError;

	/** Keeps track of the original transaction isolation level on the underlying connection								*/
	private Integer previousIsolationLevel;

	/** Set to <code>true</code> during a transaction when the underlying connection autoCommit value is <code>true</code>	*/
	private boolean manageAutoCommit;

	/** Set to <code>false</code> whenever a transaction is currently in progress involving this connection					*/
	private boolean noTrans;

	/** Keeps track of how long the pooled connection has been idle and if it has expired									*/
	final Timer t;

	/** {@link PreparedStatement} cache if enabled on the {@link PooledDataSource}											*/
	final CacheLRU<String, CachedPreparedStatement>	stmtCache;

	private final PooledDataSource dataSource;

	private final Connection connection;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	PooledConnection(final PooledDataSource dataSource, final Connection connection) {
		this.dataSource = dataSource;
		this.connection = connection;
		noTrans = true;
		t = new Timer(dataSource.getMaxIdleTime());
		stmtCache = (dataSource.getStmtCacheSize() == 0) ? null : new CacheLRU<String, CachedPreparedStatement>(dataSource.getStmtCacheSize());
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * TODO: This should probably be done on a periodic basis with a PooledConnection since the warnings could pile up (double-check this via Google)
	 * 
	 * @throws SQLException
	 */
	public final void clearWarnings() throws SQLException {
		try {
			connection.clearWarnings();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final void close() {
		if (noTrans) {
			dataSource.pool.abandon(this);
			t.reset();
		}
	}

	public final void commit() throws SQLException {
		try {
			connection.commit();

			if (manageAutoCommit) {
				connection.setAutoCommit(true);
			}

			if (previousIsolationLevel != null) {
				connection.setTransactionIsolation(previousIsolationLevel);
			}
		} catch (SQLException e) {
			hasError = true;
			throw e;
		} finally {
			previousIsolationLevel = null;
			noTrans = true;
			this.close();
		}
	}

	public final Statement createStatement() throws SQLException {
		try {
			return connection.createStatement();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final boolean getAutoCommit() throws SQLException {
		try {
			return connection.getAutoCommit();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final String getCatalog() throws SQLException {
		try {
			return connection.getCatalog();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final DatabaseMetaData getMetaData() throws SQLException {
		try {
			return connection.getMetaData();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final String getSchema() throws SQLException {
		try {
			return connection.getSchema();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	/**
	 * TODO Can we use the IsolationLevel enum instead here?
	 * 
	 * @return
	 * @throws SQLException
	 */
	public final int getTransactionIsolation() throws SQLException {
		try {
			return connection.getTransactionIsolation();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final SQLWarning getWarnings() throws SQLException {
		try {
			return connection.getWarnings();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final boolean isReadOnly() throws SQLException {
		try {
			return connection.isReadOnly();
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final boolean isValid(final int timeout) throws SQLException {
		try {
			return connection.isValid(timeout);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final CallableStatement prepareCall(final String sql) throws SQLException {
		try {
			return connection.prepareCall(sql);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final PreparedStatement prepareStatement(final String sql) throws SQLException {
		try {
			if (stmtCache == null) {
				return connection.prepareStatement(sql);
			}

			CachedPreparedStatement stmt = stmtCache.get(sql);

			if (stmt == null) {
				log.debug("Caching PreparedStatement {P}", sql);
				stmt = new CachedPreparedStatement(this, sql, connection.prepareStatement(sql));
				final CachedPreparedStatement old = stmtCache.put(sql, stmt);
				if (old != null) {
					Jdbc.close(old.stmt);
				}
			}

			return stmt;
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final void rollback() throws SQLException {
		try {
			connection.rollback();

			if (manageAutoCommit) {
				connection.setAutoCommit(true);
			}

			if (previousIsolationLevel != null) {
				connection.setTransactionIsolation(previousIsolationLevel);
			}
		} catch (SQLException e) {
			hasError = true;
			throw e;
		} finally {
			previousIsolationLevel = null;
			noTrans = true;
			this.close();
		}
	}

	public final void setAutoCommit(final boolean autoCommit) throws SQLException {
		try {
			connection.setAutoCommit(autoCommit);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final void setCatalog(final String catalog) throws SQLException {
		try {
			connection.setCatalog(catalog);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	/**
	 * TODO: This method cannot be called during a transaction
	 * 
	 * @param readOnly
	 * @throws SQLException
	 */
	public final void setReadOnly(final boolean readOnly) throws SQLException {
		try {
			connection.setReadOnly(readOnly);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	public final void setSchema(final String schema) throws SQLException {
		try {
			connection.setSchema(schema);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	/**
	 * TODO Can we use the IsolationLevel enum instead here?
	 * 
	 * @param level
	 * @throws SQLException
	 */
	public final void setTransactionIsolation(final int level) throws SQLException {
		try {
			connection.setTransactionIsolation(level);
		} catch (SQLException e) {
			hasError = true;
			throw e;
		}
	}

	@Override
	public final String toString() {
		final ParamStrBuilder builder = new ParamStrBuilder(128);

		builder.append("PooledConnection [");
		builder.append("hasError=").append((hasError) ? "yes" : "no");
		builder.append(", stmt cache size=").append(dataSource.getStmtCacheSize());
		builder.append(", trans=").append((noTrans) ? "no" : "yes");
		builder.append(", manageAutoCommit=").append((manageAutoCommit) ? "yes" : "no");
		builder.append(", isolation level=");
		try {
			builder.append(IsolationLevel.toString(getTransactionIsolation()));
		} catch (SQLException e) {
			builder.append("UNKNOWN");
		}

		return builder.append(']').toString();
	}

	//  <><><><><><><><><><><><><>< Package Methods ><><><><><><><><><><><><><>

	final void initTransaction(final IsolationLevel isoLevel) throws SQLException {
		if (isoLevel != IsolationLevel.DEFAULT && isoLevel.getValue() != getTransactionIsolation()) {
			previousIsolationLevel = getTransactionIsolation();
			setTransactionIsolation(isoLevel.getValue());
		}

		manageAutoCommit = getAutoCommit();
		if (manageAutoCommit) {
			setAutoCommit(false);
		}

		noTrans = false;
	}

	final void destroy() {
		if (stmtCache != null) {
			for (CachedPreparedStatement stmt = stmtCache.remove(); stmt != null; stmt = stmtCache.remove()) {
				Jdbc.close(stmt.stmt);
			}
		}

		Jdbc.close(connection);
	}

}
