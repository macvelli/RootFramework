package root.json;

import root.lang.Characters;

final class JSONString extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final String value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	JSONString(final String value) {
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		if (value == null) {
			chars.append(Characters.NULL_STRING);
		} else {
			chars.append('"').append(value).append('"');
		}
	}

}
