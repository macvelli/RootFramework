package root.json;

import root.data.structure.ListLinked;
import root.lang.Characters;
import root.lang.ParamStrBuilder;

/**
 * http://jsonformatter.curiousconcept.com/#jsonformatter
 * 
 * @author esmith
 */
public final class JSONObject extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final ListLinked<NameValuePair> nvpList;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public JSONObject() {
		nvpList = new ListLinked<>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void add(final String name, final String value) {
		nvpList.add(new NameValuePair(name, new JSONString(value)));
	}

	public final void add(final String name, final int value) {
		nvpList.add(new NameValuePair(name, new JSONInteger(value)));
	}

	public final void add(final String name, final double value) {
		nvpList.add(new NameValuePair(name, new JSONDouble(value)));
	}

	public final void add(final String name, final boolean value) {
		nvpList.add(new NameValuePair(name, new JSONBoolean(value)));
	}

	public final void add(final String name, final JSONValue value) {
		nvpList.add(new NameValuePair(name, value));
	}

	public final void add(final String name, final JSON json) {
		nvpList.add(new NameValuePair(name, (json == null) ? new JSONString(null) : json.marshall()));
	}

	@Override
	public final void extract(final Characters chars) {
		chars.append('{');

		final int start = chars.getLength();
		for (NameValuePair nvp : nvpList) {
			if (start < chars.getLength()) {
				chars.append(',');
			}
			chars.append(nvp);
		}

		chars.append('}');
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(1024);
		extract(chars);
		return chars.toString();
	}

}
