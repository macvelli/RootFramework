package root.json;

import root.data.structure.ListLinked;
import root.lang.Characters;
import root.lang.ParamStrBuilder;

public final class JSONArray extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final ListLinked<JSONValue> valueList;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public JSONArray() {
		valueList = new ListLinked<>();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final void add(final String value) {
		valueList.add(new JSONString(value));
	}

	public final void add(final int value) {
		valueList.add(new JSONInteger(value));
	}

	public final void add(final double value) {
		valueList.add(new JSONDouble(value));
	}

	public final void add(final boolean value) {
		valueList.add(new JSONBoolean(value));
	}

	public final void add(final JSONValue value) {
		valueList.add(value);
	}

	public final void add(final JSON json) {
		valueList.add((json == null) ? new JSONString(null) : json.marshall());
	}

	@Override
	public final void extract(final Characters chars) {
		chars.append('[');

		final int start = chars.getLength();
		for (JSONValue value : valueList) {
			if (start < chars.getLength()) {
				chars.append(',');
			}
			chars.append(value);
		}

		chars.append(']');
	}

	@Override
	public final String toString() {
		final ParamStrBuilder chars = new ParamStrBuilder(1024);
		extract(chars);
		return chars.toString();
	}

}
