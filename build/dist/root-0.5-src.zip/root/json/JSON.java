package root.json;

/**
 * 
 * @author esmith
 */
public interface JSON {

	JSONValue marshall();

}
