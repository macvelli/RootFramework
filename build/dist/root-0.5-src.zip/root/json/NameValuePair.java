package root.json;

import root.lang.Characters;
import root.lang.Extractable;

class NameValuePair implements Extractable {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final String name;
	private final JSONValue value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	NameValuePair(final String name, final JSONValue value) {
		this.name = name;
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append('"').append(name).append('"');
		chars.append(':');
		chars.append(value);
	}

}
