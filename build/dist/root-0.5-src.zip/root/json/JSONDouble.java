package root.json;

import root.lang.Characters;

final class JSONDouble extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final double value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	JSONDouble(final double value) {
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append(value);
	}

}
