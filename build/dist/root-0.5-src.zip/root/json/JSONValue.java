package root.json;

import root.lang.Extractable;

public abstract class JSONValue implements Extractable {

}
