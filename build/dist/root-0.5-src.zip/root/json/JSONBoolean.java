package root.json;

import root.lang.Characters;

final class JSONBoolean extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final boolean value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	JSONBoolean(final boolean value) {
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append(value);
	}

}
