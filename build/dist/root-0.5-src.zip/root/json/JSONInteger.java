package root.json;

import root.lang.Characters;

final class JSONInteger extends JSONValue {

	// <><><><><><><><><><><><><>< Class Attributes ><><><><><><><><><><><><><>

	private final int value;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	JSONInteger(final int value) {
		this.value = value;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final void extract(final Characters chars) {
		chars.append(value);
	}

}
