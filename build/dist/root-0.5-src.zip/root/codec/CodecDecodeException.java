/*
 * CodecDecodeException.java
 * 
 * Last Modified: 02/24/2016
 */
package root.codec;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class CodecDecodeException extends RuntimeException {

	// Constants

	private static final long serialVersionUID = 1877208314469404691L;

	// Constructors

	public CodecDecodeException(final char c, final int pos) {
		// TODO: Replace StringBuilder with faster Root implementation
		super(new StringBuilder(60)
			.append("Attempt to decode character ")
			.append(c)
			.append(" at position ")
			.append(pos)
			.append(" failed")
			.toString());
	}

	public CodecDecodeException(final String s) {
		// TODO: Replace StringBuilder with faster Root implementation
		super(new StringBuilder(25 + s.length())
			.append("Invalid codec input: ")
			.append(s)
			.toString());
	}

}	// End CodecDecodeException
