/*
 * CachedItemExpiry.java
 * 
 * Last Modified: 03/12/2016
 */
package root.cache;

import root.clock.Timer;

/**
 * Package class used to manage a single cached item with expiration behavior
 * within an expiring cache implementation.
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <K>
 * @param <V>
 */
final class CachedItemExpiry<K, V> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	K	key;
	V	value;
	int	index;
	CachedItemExpiry<K,V>	listNext;
	CachedItemExpiry<K,V>	listPrev;
	CachedItemExpiry<K,V>	mapNext;
	CachedItemExpiry<K,V>	mapPrev;

	final Timer itemTimer;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	CachedItemExpiry(final K key, final V value, final int index, final long expiry, final CachedItemExpiry<K,V> mapHead) {
		this.key = key;
		this.value = value;
		this.index = index;
		this.mapNext = mapHead;
		this.mapPrev = null;
		this.itemTimer = new Timer(expiry);

		if (mapHead != null) {
			mapHead.mapPrev = this;
		}
	}

	// <><><><><><><><><><><><><><> Package Methods ><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @param key
	 * @param value
	 * @param index
	 * @param currentTime
	 * @param mapHead
	 * @return
	 */
	final CachedItemExpiry<K,V> recycle(final K key, final V value, final int index, final long currentTime, final CachedItemExpiry<K,V> mapHead) {
		this.key = key;
		this.value = value;
		this.index = index;
		this.mapNext = mapHead;
		this.mapPrev = null;
		this.itemTimer.reset(currentTime);

		if (mapHead != null) {
			mapHead.mapPrev = this;
		}

		return this;
	}

}	// End CachedItemExpiry
