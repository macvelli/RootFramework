/*
 * Cache.java
 * 
 * Last Modified: 03/09/2016
 */
package root.cache;

/**
 * TODO Need an addCapacity() method for the Level 2 cache implementation 
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <K>
 * @param <V>
 */
public interface Cache<K, V> extends Iterable<V> {

	public void clear();

	public V get(K key);

	public V put(K key, V value);

	public int getCapacity();

	public V remove();

	public V remove(K key);

}	// End Cache
