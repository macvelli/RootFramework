/*
 * CachedItem.java
 * 
 * Last Modified: 03/09/2016
 */
package root.cache;

/**
 * Package class used to manage a single cached item within a cache
 * implementation.
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <K>
 * @param <V>
 */
final class CachedItem<K, V> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	K	key;
	V	value;
	int	index;
	CachedItem<K,V>	listNext;
	CachedItem<K,V>	listPrev;
	CachedItem<K,V>	mapNext;
	CachedItem<K,V>	mapPrev;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	CachedItem(final K key, final V value, final int index, final CachedItem<K,V> mapHead) {
		this.key = key;
		this.value = value;
		this.index = index;
		this.mapNext = mapHead;
		this.mapPrev = null;

		if (mapHead != null) {
			mapHead.mapPrev = this;
		}
	}

	// <><><><><><><><><><><><><><> Package Methods ><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @param key
	 * @param value
	 * @param index
	 * @param mapHead
	 * @return
	 */
	final CachedItem<K,V> recycle(final K key, final V value, final int index, final CachedItem<K,V> mapHead) {
		this.key = key;
		this.value = value;
		this.index = index;
		this.mapNext = mapHead;
		this.mapPrev = null;

		if (mapHead != null) {
			mapHead.mapPrev = this;
		}

		return this;
	}

}	// End CachedItem
