/*
 * CacheLRUConcurrent.java
 * 
 * Last Modified: 03/12/2016
 */
package root.cache;

import java.util.NoSuchElementException;
import java.util.concurrent.locks.ReentrantLock;

import root.lang.ConcurrentIterator;
import root.util.Clean;
import root.util.Fast;
import root.util.Safe;

/**
 * TODO: How should a cache entry be invalidated, or marked dirty, when an update is performed?
 * TODO: Think about a cache.update() method and what that should do
 * TODO: Also think about an CacheLRUConcurrent<K, List<V>> implementation that caches lists of data (or Sets for that matter)
 * TODO: What about cache synchronization across servers?
 * 
 * @author esmith
 * @version 1.0
 *
 * @param <K>
 * @param <V>
 */
public final class CacheLRUConcurrent<K, V> implements Cache<K, V> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private CachedItem<K,V>	listHead;
	private CachedItem<K,V>	listTail;
	private int				size;

	private final int				capacity;
	private final CachedItem<K,V>[]	cache;
	private final ReentrantLock		cacheLock;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public CacheLRUConcurrent(final int capacity) {
		this.capacity = Fast.max(capacity, 8);
		this.cache = Clean.newArray(Fast.hashTableSize(this.capacity));
		this.cacheLock = new ReentrantLock();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @see root.cache.Cache#clear()
	 */
	@Override
	public final void clear() {
		cacheLock.lock();
		try {
			if (size != 0) {
				CachedItem<K, V> e, next;

				// 1. Clear all entries from the cache
				for (int i=0, j=0; j < capacity; i++) {
					for (e = cache[i]; e != null; j++, e = next) {
						next = e.mapNext;
						e.key = null;
						e.value = null;
						e.mapNext = null;
						e.mapPrev = null;
						e.listNext = null;
						e.listPrev = null;
					}

					cache[i] = null;
				}

				// 2. Reset the listHead and listTail
				listHead = null;
				listTail = null;

				// 3. Reset the size to zero
				size = 0;
			}
		} finally {
			cacheLock.unlock();
		}
	}

	/**
	 * 
	 * 
	 * @param key
	 * @return
	 * 
	 * @see root.cache.Cache#get(K)
	 */
	@Override
	public final V get(final K key) {
		final int i = Safe.hashCode(key) % cache.length;

		cacheLock.lock();
		try {
			for (CachedItem<K,V> e = cache[i]; e != null; e = e.mapNext) {
				if (Safe.equals(e.key, key)) {
					// 1. Move the cached item to the tail of the list
					if (listTail != e) {
						if (listHead == e) {
							listHead = listHead.listNext;
							listHead.listPrev = null;
						} else {
							e.listPrev.listNext = e.listNext;
							e.listNext.listPrev = e.listPrev;
						}

						listTail.listNext = e;
						e.listPrev = listTail;
						e.listNext = null;
						listTail = e;
					}

					// 2. Return cached value
					return e.value;
				}
			}
		} finally {
			cacheLock.unlock();
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @param key
	 * @param value
	 * @return
	 * 
	 * @see root.cache.Cache#put(K, V)
	 */
	@Override
	public final V put(final K key, final V value) {
		final int i = Safe.hashCode(key) % cache.length;

		cacheLock.lock();
		try {
			CachedItem<K,V> e = cache[i];

			// 1. Check to see if the key is already mapped to the cache
			for (; e != null; e = e.mapNext) {
				if (Safe.equals(e.key, key)) {
					final V oldValue = e.value;
					e.value = value;
					return oldValue;
				}
			}

			// 2. Recycle oldest cached item object if cache is full
			if (size == capacity) {
				// a) Remove the oldest CachedItem from both the list and the cache
				final CachedItem<K,V> oldestItem = listHead;
				listHead = listHead.listNext;
				listHead.listPrev = null;

				if (oldestItem == cache[oldestItem.index]) {
					cache[oldestItem.index] = oldestItem.mapNext;
					if (oldestItem.mapNext != null) {
						oldestItem.mapNext.mapPrev = null;
					}
				} else {
					oldestItem.mapPrev.mapNext = oldestItem.mapNext;
				}

				// b) Reuse the oldest CachedItem for the new cache entry
				final V oldValue = oldestItem.value;

				cache[i] = oldestItem.recycle(key, value, i, cache[i]);

				// c) Attach recycled item to the tail of the list
				listTail.listNext = oldestItem;
				oldestItem.listPrev = listTail;
				oldestItem.listNext = null;
				listTail = oldestItem;

				// d) Return old cached value
				return oldValue;
			}

			// 3. Otherwise create new cache item and append it to the list tail
			e = cache[i] = new CachedItem<K, V>(key, value, i, cache[i]);

			if (listTail == null) {
				listHead = e;
			} else {
				listTail.listNext = e;
				e.listPrev = listTail;
			}

			listTail = e;
			size++;
		} finally {
			cacheLock.unlock();
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#getCapacity()
	 */
	@Override
	public final int getCapacity() {
		return capacity;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#remove()
	 */
	@Override
	public final V remove() {
		cacheLock.lock();
		try {
			if (size != 0) {
				// 1. Remove the oldest CachedItem from both the list and the cache
				final CachedItem<K,V> oldestItem = listHead;

				if (size == 1) {
					listHead = null;
					listTail = null;
					cache[oldestItem.index] = null;
				} else {
					listHead = listHead.listNext;
					listHead.listPrev = null;

					if (oldestItem == cache[oldestItem.index]) {
						cache[oldestItem.index] = oldestItem.mapNext;
						if (oldestItem.mapNext != null) {
							oldestItem.mapNext.mapPrev = null;
						}
					} else {
						oldestItem.mapPrev.mapNext = oldestItem.mapNext;
						if (oldestItem.mapNext != null) {
							oldestItem.mapNext.mapPrev = oldestItem.mapPrev;
						}
					}
				}

				// 2. Clean up oldestItem for garbage collection purposes
				final V oldValue = oldestItem.value;

				oldestItem.key = null;
				oldestItem.value = null;

				// 3. Decrement the size by one
				size--;

				// 4. Return old cached value
				return oldValue;
			}
		} finally {
			cacheLock.unlock();
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @param key
	 * @return
	 * 
	 * @see root.cache.Cache#remove(Object)
	 */
	@Override
	public final V remove(final K key) {
		cacheLock.lock();
		try {
			if (size != 0) {
				final int i = Safe.hashCode(key) % cache.length;
				CachedItem<K,V> foundItem;

				// 1. Find the CachedItem associated with the key
				for (foundItem = cache[i]; foundItem != null; foundItem = foundItem.mapNext) {
					if (Safe.equals(foundItem.key, key)) {
						break;
					}
				}

				if (foundItem != null) {
					// 2. Remove the found item from the cache and list
					if (size == 1) {
						listHead = null;
						listTail = null;
						cache[i] = null;
					} else {
						if (listHead == foundItem) {
							listHead = listHead.listNext;
							listHead.listPrev = null;
						} else if (listTail == foundItem) {
							listTail = foundItem.listPrev;
							listTail.listNext = null;
						} else {
							foundItem.listPrev.listNext = foundItem.listNext;
							foundItem.listNext.listPrev = foundItem.listPrev;
						}

						if (foundItem == cache[i]) {
							cache[i] = foundItem.mapNext;
							if (foundItem.mapNext != null) {
								foundItem.mapNext.mapPrev = null;
							}
						} else {
							foundItem.mapPrev.mapNext = foundItem.mapNext;
							if (foundItem.mapNext != null) {
								foundItem.mapNext.mapPrev = foundItem.mapPrev;
							}
						}						
					}
				}

				// 3. Clean up foundItem for garbage collection purposes
				final V oldValue = foundItem.value;

				foundItem.key = null;
				foundItem.value = null;

				// 4. Decrement the size by one
				size--;

				// 5. Return old cached value
				return oldValue;
			}
		} finally {
			cacheLock.unlock();
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#iterator()
	 */
	@Override
	public final ConcurrentIterator<V> iterator() {
		return new Itr();
	}

	// <><><><><><><><><><><><><><> Private Classes ><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @author esmith
	 * @version 1.0
	 */
	private class Itr implements ConcurrentIterator<V> {

		private CachedItem<K,V> cursor;

		@Override
		public final boolean hasNext() {
			return cursor != null;
		}

		@Override
		public final V next() {
			if (cursor == null) {
				throw new NoSuchElementException();
			}

			final V v = cursor.value;
			cursor = cursor.listNext;

			return v;
		}

		/**
		 * @throws UnsupportedOperationException
		 */
		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		public final void lock() {
			cacheLock.lock();
			cursor = listHead;
		}

		@Override
		public final void unlock() {
			cacheLock.unlock();
		}
		
	}	// End Itr

}	// End CacheLRUConcurrent
