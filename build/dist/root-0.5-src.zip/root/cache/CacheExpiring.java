/*
 * CacheExpiring.java
 * 
 * Last Modified: 03/12/2016
 */
package root.cache;

import java.util.Iterator;
import java.util.NoSuchElementException;

import root.data.structure.QueueBounded;
import root.util.Clean;
import root.util.Fast;
import root.util.Safe;

/**
 * TODO: http://stackoverflow.com/questions/3802370/java-time-based-map-cache-with-expiring-keys<p>
 * TODO: Need a CacheExpiringConcurrent and a CacheExpiringMultiKey implementation<p>
 * TODO: Need a Duration class so that I can say new CacheExpiring(10, Duration.minutes(10));<p>
 * 
 * This cache class is a simple implementation of an expiring item cache. There
 * are no background threads or other nonsense used to manage expired cache
 * entries. The expiring cache uses {@link root.clock.Timer} to determine when
 * cached entries have expired.
 * <p>
 * The algorithm used to manage cache entries is as follows:
 * <ul>
 * 	<li>Every time {@link #get(K)} is called, the oldest item in the cache is
 * 		checked to see if it has expired
 * 		<ul>
 * 			<li>If the oldest item in the cache has expired, maintenance is
 * 				performed to remove all expired entries from the cache</li>
 * 		</ul>
 * 	</li>
 * 	<li>If an existing cached item is updated during a {@link #put(K, V)}, its
 * 		timer is reset and it becomes the newest item in the cache</li>
 * 	<li>If a new item is being cached during a {@link #put(K, V)} and the cache
 * 		is full, LRU-based behavior is taken where the oldest cached item
 * 		(regardless of whether it has expired or not) is removed from the cache
 * 		to make room for the new item</li> 
 * </ul>
 * Because there will be fluctuations in the number of cached entries over
 * time, an internal pool is used to capture expired
 * {@link root.cache.CachedItemExpiry} objects so that they may be reused when
 * new entries are {@link #put(K, V)} into the cache. This reduces the strain
 * the cache puts onto the garbage collector during runtime.
 * 
 * @author esmith
 * @version 1.0
 * 
 * @param <K>
 * @param <V>
 */
public class CacheExpiring<K, V> implements Cache<K, V> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private CachedItemExpiry<K,V>	listHead;
	private CachedItemExpiry<K,V>	listTail;
	private int						size;

	private final int									capacity;
	private final long									expireDuration;
	private final CachedItemExpiry<K,V>[]				cache;
	private final QueueBounded<CachedItemExpiry<K,V>>	cachedItemPool;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public CacheExpiring(final int capacity, final long expireDuration) {
		this.capacity = Fast.max(capacity, 8);
		this.cache = Clean.newArray(Fast.hashTableSize(this.capacity));
		this.expireDuration = expireDuration;
		this.cachedItemPool = new QueueBounded<>(this.capacity);
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @see root.cache.Cache#clear()
	 */
	@Override
	public final void clear() {
		if (size != 0) {
			CachedItemExpiry<K, V> e, next;

			// 1. Clear all entries from the cache
			for (int i=0, j=0; j < capacity; i++) {
				for (e = cache[i]; e != null; j++, e = next) {
					// a) Clean up the CachedItemExpiry for GC
					next = e.mapNext;
					e.key = null;
					e.value = null;
					e.mapNext = null;
					e.mapPrev = null;
					e.listNext = null;
					e.listPrev = null;

					// b) Add the CachedItemExpiry to the cachedItemPool
					cachedItemPool.enqueue(e);
				}

				cache[i] = null;
			}

			// 2. Reset the listHead and listTail
			listHead = null;
			listTail = null;

			// 3. Reset the size to zero
			size = 0;
		}
	}

	/**
	 * 
	 * 
	 * @param key
	 * @return
	 * 
	 * @see root.cache.Cache#get(K)
	 */
	@Override
	public final V get(final K key) {
		if (listHead != null) {
			final int i = Safe.hashCode(key) % cache.length;
			final long currentTime = System.currentTimeMillis();

			// 1. Purge all expired entries if the listHead has expired
			if (listHead.itemTimer.hasExpired(currentTime)) {
				purgeExpiredEntries(listHead.listNext, currentTime);
			}

			// 2. Look for the cached item
			for (CachedItemExpiry<K,V> e = cache[i]; e != null; e = e.mapNext) {
				if (Safe.equals(e.key, key)) {
					// a) Return cached value
					return e.value;
				}
			}
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @param key
	 * @param value
	 * @return
	 * 
	 * @see root.cache.Cache#put(K, V)
	 */
	@Override
	public final V put(final K key, final V value) {
		final int i = Safe.hashCode(key) % cache.length;
		final long currentTime = System.currentTimeMillis();
		CachedItemExpiry<K,V> e = cache[i];

		// 1. Check to see if the key is already mapped to the cache
		for (; e != null; e = e.mapNext) {
			if (Safe.equals(e.key, key)) {
				// a) Update cached value and move to the tail of the list
				final V oldValue = e.value;
				e.value = value;
				e.itemTimer.reset(currentTime);

				if (listTail != e) {
					if (listHead == e) {
						listHead = listHead.listNext;
						listHead.listPrev = null;
					} else {
						e.listPrev.listNext = e.listNext;
						e.listNext.listPrev = e.listPrev;
					}

					listTail.listNext = e;
					e.listPrev = listTail;
					e.listNext = null;
					listTail = e;
				}

				// c) Return the old cached value
				return oldValue;
			}
		}

		// 2. Recycle oldest cached item object if cache is full
		if (size == capacity) {
			// a) Remove the oldest CachedItemExpiry from both the list and cache
			final CachedItemExpiry<K,V> oldestItem = listHead;
			listHead = listHead.listNext;
			listHead.listPrev = null;

			if (oldestItem == cache[oldestItem.index]) {
				cache[oldestItem.index] = oldestItem.mapNext;
				if (oldestItem.mapNext != null) {
					oldestItem.mapNext.mapPrev = null;
				}
			} else {
				oldestItem.mapPrev.mapNext = oldestItem.mapNext;
				if (oldestItem.mapNext != null) {
					oldestItem.mapNext.mapPrev = oldestItem.mapPrev;
				}
			}

			// b) Reuse the oldest CachedItem for the new cache entry
			final V oldValue = oldestItem.value;

			cache[i] = oldestItem.recycle(key, value, i, currentTime, cache[i]);

			// c) Attach recycled item to the tail of the list
			listTail.listNext = oldestItem;
			oldestItem.listPrev = listTail;
			oldestItem.listNext = null;
			listTail = oldestItem;

			// d) Return old cached value
			return oldValue;
		}

		// 3. Otherwise create new cache item (or reuse existing cache item) and append it to the list tail
		if (cachedItemPool.isEmpty()) {
			e = cache[i] = new CachedItemExpiry<K, V>(key, value, i, expireDuration, cache[i]);
		} else {
			e = cachedItemPool.dequeue();
			cache[i] = e.recycle(key, value, i, currentTime, cache[i]);
		}

		if (listTail == null) {
			listHead = e;
		} else {
			listTail.listNext = e;
			e.listPrev = listTail;
		}

		listTail = e;
		size++;

		return null;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#getCapacity()
	 */
	@Override
	public final int getCapacity() {
		return capacity;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#remove()
	 */
	@Override
	public final V remove() {
		if (size != 0) {
			// 1. Remove the oldest CachedItem from both the list and the cache
			final CachedItemExpiry<K,V> oldestItem = listHead;

			if (size == 1) {
				listHead = null;
				listTail = null;
				cache[oldestItem.index] = null;
			} else {
				listHead = listHead.listNext;
				listHead.listPrev = null;

				if (oldestItem == cache[oldestItem.index]) {
					cache[oldestItem.index] = oldestItem.mapNext;
					if (oldestItem.mapNext != null) {
						oldestItem.mapNext.mapPrev = null;
					}
				} else {
					oldestItem.mapPrev.mapNext = oldestItem.mapNext;
					if (oldestItem.mapNext != null) {
						oldestItem.mapNext.mapPrev = oldestItem.mapPrev;
					}
				}
			}

			// 2. Clean up oldestItem for garbage collection purposes
			final V oldValue = oldestItem.value;

			oldestItem.key = null;
			oldestItem.value = null;
			oldestItem.listNext = null;
			oldestItem.listPrev = null;
			oldestItem.mapNext = null;
			oldestItem.mapPrev = null;

			// 3. Add the oldestItem to the cachedItemPool
			cachedItemPool.enqueue(oldestItem);

			// 4. Decrement the size by one
			size--;

			// 5. Return old cached value
			return oldValue;
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @param key
	 * @return
	 * 
	 * @see root.cache.Cache#remove(Object)
	 */
	@Override
	public final V remove(final K key) {
		if (size != 0) {
			final int i = Safe.hashCode(key) % cache.length;
			CachedItemExpiry<K,V> foundItem;

			// 1. Find the CachedItem associated with the key
			for (foundItem = cache[i]; foundItem != null; foundItem = foundItem.mapNext) {
				if (Safe.equals(foundItem.key, key)) {
					break;
				}
			}

			if (foundItem != null) {
				// 2. Remove the found item from the cache and list
				if (size == 1) {
					listHead = null;
					listTail = null;
					cache[i] = null;
				} else {
					if (listHead == foundItem) {
						listHead = listHead.listNext;
						listHead.listPrev = null;
					} else if (listTail == foundItem) {
						listTail = foundItem.listPrev;
						listTail.listNext = null;
					} else {
						foundItem.listPrev.listNext = foundItem.listNext;
						foundItem.listNext.listPrev = foundItem.listPrev;
					}

					if (foundItem == cache[i]) {
						cache[i] = foundItem.mapNext;
						if (foundItem.mapNext != null) {
							foundItem.mapNext.mapPrev = null;
						}
					} else {
						foundItem.mapPrev.mapNext = foundItem.mapNext;
						if (foundItem.mapNext != null) {
							foundItem.mapNext.mapPrev = foundItem.mapPrev;
						}
					}
				}
			}

			// 3. Clean up foundItem for garbage collection purposes
			final V oldValue = foundItem.value;

			foundItem.key = null;
			foundItem.value = null;
			foundItem.listNext = null;
			foundItem.listPrev = null;
			foundItem.mapNext = null;
			foundItem.mapPrev = null;

			// 4. Add the foundItem to the cachedItemPool
			cachedItemPool.enqueue(foundItem);

			// 5. Decrement the size by one
			size--;

			// 6. Return old cached value
			return oldValue;
		}

		return null;
	}

	/**
	 * 
	 * 
	 * @return
	 * 
	 * @see root.cache.Cache#iterator()
	 */
	@Override
	public final Iterator<V> iterator() {
		return new Itr();
	}

	// <><><><><><><><><><><><><><> Private Methods ><><><><><><><><><><><><><>

	private void purgeExpiredEntries(CachedItemExpiry<K,V> lastValidEntry, final long currentTime) {
		// 1. Find the last valid entry in the list
		for (; lastValidEntry != null && lastValidEntry.itemTimer.hasExpired(currentTime); lastValidEntry = lastValidEntry.listNext);

		// 2. Manage the expired cache entries
		if (lastValidEntry == null) {
			// a) Just clear the entire cache since there are no valid entries
			clear();
		} else {
			CachedItemExpiry<K,V> e, next;

			// b) Purge all of the expired entries from listHead to lastValidEntry
			for (e = listHead; e != lastValidEntry; e = next) {
				next = e.listNext;

				// Remove the CachedItemExpiry from the cache
				if (e == cache[e.index]) {
					cache[e.index] = e.mapNext;
					if (e.mapNext != null) {
						e.mapNext.mapPrev = null;
					}
				} else {
					e.mapPrev.mapNext = e.mapNext;
					if (e.mapNext != null) {
						e.mapNext.mapPrev = e.mapPrev;
					}
				}

				// Clean up the CachedItemExpiry for GC
				e.key = null;
				e.value = null;
				e.listNext = null;
				e.listPrev = null;
				e.mapNext = null;
				e.mapPrev = null;

				// Add the CachedItemExpiry to the cachedItemPool
				cachedItemPool.enqueue(e);

				// Decrement the size by one
				size--;
			}

			// c) Reset the listHead to lastValidEntry
			listHead = lastValidEntry;
			listHead.listPrev = null;
		}
	}

	// <><><><><><><><><><><><><><> Private Classes ><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @author esmith
	 * @version 1.0
	 */
	private class Itr implements Iterator<V> {

		private CachedItemExpiry<K,V> cursor = listHead;

		@Override
		public final boolean hasNext() {
			return cursor != null;
		}

		@Override
		public final V next() {
			if (cursor == null) {
				throw new NoSuchElementException();
			}

			final V v = cursor.value;
			cursor = cursor.listNext;

			return v;
		}

		/**
		 * @throws UnsupportedOperationException
		 */
		@Override
		public final void remove() {
			throw new UnsupportedOperationException();
		}
		
	}	// End Itr

}	// End CacheExpiring
