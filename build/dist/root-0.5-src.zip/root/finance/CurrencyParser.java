/*
 * CurrencyParser.java
 * 
 * Last Modified: 04/14/2016
 */
package root.finance;

import root.data.validation.InvalidFormatException;

public class CurrencyParser {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final Currency currency;
	private final char symbol;
	private final char groupSeparator;
	private final char decimalSeparator;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	public CurrencyParser(final Currency currency) {
		this.currency = currency;
		this.symbol = currency.getSymbol();
		this.groupSeparator = currency.getGroupSeparator();
		this.decimalSeparator = currency.getDecimalSeparator();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final MoneyLong parseMoneyLong(final String moneyStr) {
//		final char[] ch = amount.toCharArray();
		if (moneyStr == null || moneyStr.length() == 0) {
			// TODO: What should a null/empty String value result in? A null MoneyLong? A zero-value MoneyLong?
		}

		final int moneyStrLen = moneyStr.length();
		boolean negative = false;
		int charPos = 0;
		long moneyLongAmt = 0L;
		char c = moneyStr.charAt(charPos++);

		if (c == '-') {
			negative = true;
			c = moneyStr.charAt(charPos++);
		}

		if (c == symbol) {
			c = moneyStr.charAt(charPos++);
		}

		if (c < '0' || c > '9') {
			throw new InvalidFormatException("Invalid money input {P} for currency {P}", moneyStr, currency);
		}

		moneyLongAmt = c - '0';		// First digit

		if (moneyStrLen > charPos) {
			c = moneyStr.charAt(charPos++);

			if (c != decimalSeparator && c != groupSeparator) {
				if (c < '0' || c > '9') {
					throw new InvalidFormatException("Invalid money input {P} for currency {P}", moneyStr, currency);
				}

				moneyLongAmt = (moneyLongAmt * 10) + c - '0';

				if (moneyStrLen > charPos) {
					c = moneyStr.charAt(charPos++);

					if (c != decimalSeparator && c != groupSeparator) {
						if (c < '0' || c > '9') {
							throw new InvalidFormatException("Invalid money input {P} for currency {P}", moneyStr, currency);
						}

						moneyLongAmt = (moneyLongAmt * 10) + c - '0';

						if (moneyStrLen > charPos) {
							c = moneyStr.charAt(charPos++);

							if (c != groupSeparator) {
								while (c != decimalSeparator) {
									if (c < '0' || c > '9') {
										throw new InvalidFormatException("Invalid money input {P} for currency {P}", moneyStr, currency);
									}

									moneyLongAmt = (moneyLongAmt * 10) + c - '0';

									if (moneyStrLen > charPos) {
										c = moneyStr.charAt(charPos++);
									} else {
										break;
									}
								}
							}
						}
					}
				}
			}
		}

		while (c == groupSeparator) {
			
		}

		return new MoneyLong(moneyLongAmt);

//		for (; i < ch.length; i++) {
//			if (ch[i] == '.') {
//				if (++d != 0)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//			} else {
//				if (d >= 0 && d++ == 2)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				if (ch[i] < '0' || ch[i] > '9')
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				this.amount = (this.amount << 3) + (this.amount << 1) + ch[i] - '0';
//			}
//		}
//
//		if (d <= 0)
//			this.amount *= 100;
//		else if (d == 1)
//			this.amount = (this.amount << 3) + (this.amount << 1);
//
//		if (neg)
//			this.amount = ~this.amount + 1;
	}

}	// End CurrencyParser
