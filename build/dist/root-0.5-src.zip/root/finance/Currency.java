/*
 * Currency.java
 */
package root.finance;

/**
 * http://www.xe.com/symbols.php
 * http://www.thefinancials.com/Default.aspx?SubSectionID=curformat
 * 
 * @author esmith
 * @version 1.0
 */
public enum Currency {

	// <><><><><><><><><><><><><><>< Enum Values <><><><><><><><><><><><><><><>

	USD("US Dollar", '$', ',', '.'),
	EUR("Euro", '�', ',', '.'),
	GBP("British Pound", '�', ',', '.'),
	CAD("Canadian Dollar", '$', ',', '.'),
	AUD("Australian Dollar", '$', ' ', '.'),
	NZD("New Zealand Dollar", '$', ',', '.'),
	JPY("Japanese Yen", '�', ',', '\u0000'),
	CNY("Chinese Yuan", '�', ',', '.');
	// RUB("Russian Ruble", '?', ',', '.'); // TODO: What to do with 3-character
	// symbol?

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final String name;
	private final char symbol;
	private final char groupSeparator;
	private final char decimalSeparator;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	private Currency(final String name, final char symbol,
			final char groupSeparator, final char decimalSeparator) {
		this.name = name;
		this.symbol = symbol;
		this.groupSeparator = groupSeparator;
		this.decimalSeparator = decimalSeparator;
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final String getCode() {
		return name();
	}

	public final String getName() {
		return name;
	}

	public final char getSymbol() {
		return symbol;
	}

	public final char getGroupSeparator() {
		return groupSeparator;
	}

	public final char getDecimalSeparator() {
		return decimalSeparator;
	}

} // End Currency
