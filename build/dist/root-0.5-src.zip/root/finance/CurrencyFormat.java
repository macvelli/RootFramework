package root.finance;

import root.lang.Characters;
import root.lang.ParamStrBuilder;

/**
 * TODO: This class needs to be deleted as it has been superseded by CurrencyFormatter
 * 
 * @author macve
 * @version 1.0
 */
public class CurrencyFormat {

	// This should be private and real formats stored as singleton classes in a HeapMap keyed by Locale
	public CurrencyFormat() {}

	public String format(final MoneyLong m) {
		return format(new ParamStrBuilder(16), m).toString();
	}

	public Characters format(final Characters chars, final MoneyLong m) {
		return chars;
//		if (m.amount == -2147483648)
//            return chars.append('(','$','2','1',',','4','7','4',',','8','3','6','.','4','8',')');
//
//		final char[] num = new char[16];
//		final boolean neg = (m.amount < 0);
//		int v = (neg) ? ~m.amount + 1 : m.amount;
//		int i = 15;
//		int q = v / 10;
//		int r = v - (q << 3) - (q << 1);
//
//		if (neg)
//			num[i--] = ')';
//
//		num[i--] = (char) (r + '0');
//
//		v = q;
//		q = v / 10;
//		r = v - (q << 3) - (q << 1);
//
//		num[i--] = (char) (r + '0');
//		num[i--] = '.';
//
//		int s = 3;
//		while (q >= 10) {
//			v = q;
//			q = v / 10;
//			r = v - (q << 3) - (q << 1);
//
//			num[i--] = (char) (r + '0');
//			if (--s == 0) {
//				num[i--] = ',';
//				s = 3;
//			}
//		}
//
//		num[i--] = (char) (q + '0');
//		num[i] = '$';
//
//		if (neg)
//			num[--i] = '(';
//
//		return chars.append(num, i, 16-i);
	}

}	// End CurrencyFormat
