/*
 * MoneyLong.java
 * 
 * Last Modified: 04/10/2016
 */
package root.finance;

import java.math.BigDecimal;

import root.codec.CodecDecodeException;
import root.data.validation.InvalidFormatException;
import root.data.validation.NullParameterException;
import root.lang.Extractable;
import root.util.Fast;

/**
 * The MoneyLong class is built to work with exact monetary values. The amount is
 * stored internally as a <code>long</code> to preserve data integrity while
 * performing financial calculations. The minimum value of a MoneyLong object is
 * -92,233,720,368,547,758.08 while the maximum value is 92,233,720,368,547,758.07
 * (inclusive). Safe to replace up to DECIMAL(17,2) with BIGINT in database
 * applications.
 * 
 * http://java-performance.info/bigdecimal-vs-double-in-financial-calculations/
 * 
 * @author esmith
 */
public final class MoneyLong implements Comparable<MoneyLong>, Extractable<CurrencyFormatter> {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	// TODO: For budget purposes, as well as data deduplication, do we need a compact "Date" class that is simply just the month and year?  Then we could store this value as part of a primary key (along with user ID) which is then referenced across all entries in the database...but if it is a simple integer-like field, it probably doesn't matter and it can just be a part of the table record
	// TODO: How can we print a Money object without the freaking monetary symbol?  Work on it...
	// TODO: Also, there are several ways to format Money objects when they represent negative values...how to implement a MoneyFormat, or format(), or whatever?
	// TODO: Might just want to do a Format class just like Date so that it can take some basic parameters and then be 'the truth' about how Money objects get printed when they go thru the Formatter
	long amount;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * Creates an instance initialized with the supplied <code>long</code>
	 * amount.
	 * 
	 * @param amount The monetary amount kept in precise <code>long</code> format.
	 */
	public MoneyLong(final long amount) {
		this.amount = amount;
	}

//	TODO: Move this functionality into a Formatter/Parser class
//	public Money(final String amount) {
//		final char[] ch = amount.toCharArray();
//		final boolean neg = (ch[0] == '-');
//		int d = -1;
//		int i = (neg) ? 1 : 0;
//
//		for (; i < ch.length; i++) {
//			if (ch[i] == '.') {
//				if (++d != 0)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//			} else {
//				if (d >= 0 && d++ == 2)
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				if (ch[i] < '0' || ch[i] > '9')
//					throw new InvalidFormatException("Invalid money value {P}", amount);
//
//				this.amount = (this.amount << 3) + (this.amount << 1) + ch[i] - '0';
//			}
//		}
//
//		if (d <= 0)
//			this.amount *= 100;
//		else if (d == 1)
//			this.amount = (this.amount << 3) + (this.amount << 1);
//
//		if (neg)
//			this.amount = ~this.amount + 1;
//	}

	public MoneyLong(final MoneyLong... amounts) {
		for (MoneyLong m : amounts) {
			this.amount += m.amount;
		}
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	public final long getAmount() {
		return amount;
	}

	public final void setAmount(final long amount) {
		this.amount = amount;
	}

	public final void add(final MoneyLong m) {
		this.amount += m.amount;
	}

	public final void subtract(final MoneyLong m) {
		this.amount -= m.amount;
	}

	public final MoneyLong multiply(final int value) {
		return new MoneyLong(amount * value);
	}

	public final MoneyLong multiply(final Percent p) {
		return p.multiply(this);
	}

	public final MoneyLong divide(final int value) {
		final long q = amount / value;

		// TODO: I don't know if this is the correct algorithm for rounding half-up
		return new MoneyLong(((amount - (q * value)) << 1) >= value ? q + 1 : q);
	}

	public final Percent divide(final MoneyLong divisor) {
		return new Percent(this, divisor);
	}

	@Override
	public final boolean equals(final Object o) {
		if (o == null || (o.getClass() != MoneyLong.class)) {
			return false;
		}

		return ((MoneyLong) o).amount == amount;
	}

	@Override
	public final int hashCode() {
		return (int)(amount ^ (amount >>> 32));
	}

	@Override
	public final int compareTo(final MoneyLong m) {
		return (amount < m.amount) ? -1 : (amount == m.amount) ? 0 : 1;
	}

	@Override
	public final void extract(final CurrencyFormatter formatter) {
		formatter.format(amount);
	}

	@Override
	public final String toString() {
		throw new UnsupportedOperationException("Use the extract(CurrencyFormatter) method to get a String representation of a Money object");
	}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~ Private Methods ~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Returns the percentage difference between <code>a</code> and <code>b</code>.
	 * <p>
	 * The numerator (a) <b><i>must</i></b> be greater than the denominator (b).
	 * 
	 * @param a the numerator
	 * @param b the denominator
	 * @return the percentage difference between <code>a</code> and <code>b</code>
	 */
	public static final double percentDiff(final double a, final double b) {
		// TODO: Find a home for this
		return (a/b) - 1;
	}

	public static void main(String[] args) {
//		Money yo = new Money("3.49");

//		Money yo = new Money("-0.00");
//		Money yo = new Money("-21474836.48");
//		Money yo = new Money("-21474836.48");
//		Money yo = new Money("3.50");
//		yo.credit("7.19");
//		yo.debit("4.35");
//		yo.debit("6.24");
//		yo.debit("4993.75");

//		System.out.println(yo.multiply(27).divide(12));
//		System.out.println(yo);

//		Money foo = new Money(1225000);
//		Money bar = new Money(6000000);

//		System.out.println(foo);
//		System.out.println(bar);

		// ROI is actually 389.80% not 489.80%...guess we need a Finance object to work the magic
//		System.out.println("ROI = " + bar.divide(foo));
//		System.out.println("Ratio = " + foo.divide(bar));

//		foo = new Money(747463);
//		bar = new Money(639534);

//		System.out.println("Ratio = " + bar.divide(foo));

		// 86113.04 * 85.56% = 73678.32
//		foo = new Money(8611304);
//		Percent p = new Percent("85.56");

//		System.out.println("Amount = $" + foo.multiply(p));

		System.out.println(Fast.divideDouble(475, 1820));
		System.out.println(Fast.divideFloat(475, 1820));

		System.out.println(Fast.divideDouble(84096, 2628) * 100);
		System.out.println(Fast.divideFloat(84096, 2628) * 100);

		System.out.println(Fast.divideDouble(47120, 26099)-1);
		System.out.println(Fast.divideFloat(47120, 26099)-1);

		Double.toString(Fast.divideDouble(47120, 26099)-1);
		Float.toString(Fast.divideFloat(47120, 26099)-1);

		new BigDecimal(Fast.divideDouble(47120, 26099)-1);
		new BigDecimal(Fast.divideFloat(47120, 26099)-1);
	}

}	// End Money
