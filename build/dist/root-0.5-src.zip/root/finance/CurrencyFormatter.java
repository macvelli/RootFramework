/*
 * CurrencyFormatter.java
 * 
 * Last Modified: 04/10/2016
 */
package root.finance;

import java.io.IOException;

import root.lang.Characters;
import root.lang.Extractable;

/**
 * 
 * 
 * @author esmith
 * @version 1.0
 */
public class CurrencyFormatter implements Characters {

	// <><><><><><><><><><><><><><><> Attributes <><><><><><><><><><><><><><><>

	private final Characters chars;
	private final char symbol;
	private final char groupSeparator;
	private final char decimalSeparator;

	// <><><><><><><><><><><><><><>< Constructors ><><><><><><><><><><><><><><>

	/**
	 * 
	 * 
	 * @param chars
	 */
	public CurrencyFormatter(final Characters chars) {
		this.chars = chars;
		this.symbol = Currency.USD.getSymbol();
		this.groupSeparator = Currency.USD.getGroupSeparator();
		this.decimalSeparator = Currency.USD.getDecimalSeparator();
	}

	/**
	 * 
	 * 
	 * @param chars
	 * @param currency
	 */
	public CurrencyFormatter(final Characters chars, final Currency currency) {
		this.chars = chars;
		this.symbol = currency.getSymbol();
		this.groupSeparator = currency.getGroupSeparator();
		this.decimalSeparator = currency.getDecimalSeparator();
	}

	// <><><><><><><><><><><><><><> Public Methods <><><><><><><><><><><><><><>

	@Override
	public final CurrencyFormatter append(final boolean b) {
		chars.append(b);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final byte[] b) {
		chars.append(b);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final double d) {
		chars.append(d);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final float f) {
		chars.append(f);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final int i) {
		chars.append(i);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final long l) {
		chars.append(l);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final char c) {
		chars.append(c);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final char... str) {
		chars.append(str);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final char[] str, final int offset, final int count) {
		chars.append(str, offset, count);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final CharSequence csq) throws IOException {
		chars.append(csq);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final CharSequence csq, final int start, final int end) throws IOException {
		chars.append(csq, start, end);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final Extractable<Characters> e) {
		chars.append(e);
		return this;
	}

	@Override
	public final Characters append(final Extractable<Characters>[] array, final int offset, final int count) {
		chars.append(array, offset, count);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final Object o) {
		chars.append(o);
		return this;
	}

	@Override
	public final Characters append(final Object[] array, final int offset, final int count) {
		chars.append(array, offset, count);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final String str) {
		chars.append(str);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final StringBuffer strBuf) {
		chars.append(strBuf);
		return this;
	}

	@Override
	public final CurrencyFormatter append(final StringBuilder builder) {
		chars.append(builder);
		return this;
	}

	@Override
	public final char charAt(final int index) {
		return chars.charAt(index);
	}

	@Override
	public final void clear() {
		chars.clear();		
	}

	public final CurrencyFormatter format(int i) {
		if (i == Integer.MIN_VALUE) {
            chars.append('-',symbol,'2','1',groupSeparator,'4','7','4',groupSeparator,'8','3','6',decimalSeparator,'4','8');
            return this;
		}

		final boolean sign = (i < 0);
		final int formatSize;
		if (sign) {
			i = -i;
			formatSize = intFormatSize(i) + 1;
		} else {
			formatSize = intFormatSize(i);
		}

		int charPos = formatSize + chars.getLength();
		final char[] buf = chars.getChars(formatSize);

		int r;

		// Format the decimal places first
		r = i % 100;
		i /= 100;
		buf[--charPos] = Characters.digitOnes[r];
		buf[--charPos] = Characters.digitTens[r];
		buf[--charPos] = decimalSeparator;

		do {
			// One digit left
			if (i < 10) {
				buf[--charPos] = Characters.digits[i];
				break;
			}

			// Two digits left
			if (i < 100) {
				buf[--charPos] = Characters.digitOnes[i];
				buf[--charPos] = Characters.digitTens[i];
				break;
			}

			// At least three digits left
			r = i % 100;
			i /= 100;
			buf[--charPos] = Characters.digitOnes[r];
			buf[--charPos] = Characters.digitTens[r];

			r = i % 10;
			i /= 10;
			buf[--charPos] = Characters.digits[r];

			// Add group separator, if necessary
			if (i > 0) {
				buf[--charPos] = groupSeparator;
			}
		} while (i > 0);

		// Add currency symbol
		buf[--charPos] = symbol;

		if (sign) {
			buf[--charPos] = '-';
		}

		return this;
	}

	public final CurrencyFormatter format(long l) {
		if (l == Long.MIN_VALUE) {
            chars.append('-',symbol,'9','2',groupSeparator,'2','3','3',groupSeparator,'7','2','0',groupSeparator,'3','6','8',groupSeparator,'5','4','7',groupSeparator,'7','5','8',decimalSeparator,'0','8');
            return this;
		}

		final boolean sign = (l < 0);
		final int formatSize;
		if (sign) {
			l = -l;
			formatSize = longFormatSize(l) + 1;
		} else {
			formatSize = longFormatSize(l);
		}

		int charPos = formatSize + chars.getLength();
		final char[] buf = chars.getChars(formatSize);

		int r;

		// Format the decimal places first
		r = (int) (l % 100);
		l /= 100;
		buf[--charPos] = Characters.digitOnes[r];
		buf[--charPos] = Characters.digitTens[r];
		buf[--charPos] = decimalSeparator;

		do {
			// One digit left
			if (l < 10) {
				buf[--charPos] = Characters.digits[(int) l];
				break;
			}

			// Two digits left
			if (l < 100) {
				r = (int) l;
				buf[--charPos] = Characters.digitOnes[r];
				buf[--charPos] = Characters.digitTens[r];
				break;
			}

			// At least three digits left
			r = (int) (l % 100);
			l /= 100;
			buf[--charPos] = Characters.digitOnes[r];
			buf[--charPos] = Characters.digitTens[r];

			r = (int) (l % 10);
			l /= 10;
			buf[--charPos] = Characters.digits[r];

			// Add group separator, if necessary
			if (l > 0) {
				buf[--charPos] = groupSeparator;
			}
		} while (l > 0);

		// Add currency symbol
		buf[--charPos] = symbol;

		if (sign) {
			buf[--charPos] = '-';
		}

		return this;
	}

	@Override
	public final int getCapacity() {
		return chars.getCapacity();
	}

	@Override
	public final char[] getChars(final int numCharsToAdd) {
		return chars.getChars(numCharsToAdd);
	}

	@Override
	public final void setCharAt(final int index, final char c) {
		chars.setCharAt(index, c);
	}

	@Override
	public final int getLength() {
		return chars.getLength();
	}

	@Override
	public final void setLength(final int len) {
		chars.setLength(len);
	}

	@Override
	public final int length() {
		return chars.length();
	}

	@Override
	public final CurrencyFormatter separator(final int start) {
		chars.separator(start);
		return this;
	}


	@Override
	public final CharSequence subSequence(final int start, final int end) {
		return chars.subSequence(start, end);
	}

	@Override
	public final String toString() {
		return chars.toString();
	}

	// <><><><><><><><><><><><><>< Private Methods <><><><><><><><><><><><><><>

	private int intFormatSize(final int i) {
		if (i < 1000) return 5;					// $9.99
		if (i < 10000) return 6;				// $99.99
		if (i < 100000) return 7;				// $999.99
		if (i < 1000000) return 9;				// $9,999.99
		if (i < 10000000) return 10;			// $99,999.99
		if (i < 100000000) return 11;			// $999,999.99
		if (i < 1000000000) return 13;			// $9,999,999.99

		return 14;								// $19,999,999.99
	}

	private int longFormatSize(final long l) {
		if (l < 1000) return 5;							// $9.99
		if (l < 10000) return 6;						// $99.99
		if (l < 100000) return 7;						// $999.99
		if (l < 1000000) return 9;						// $9,999.99
		if (l < 10000000) return 10;					// $99,999.99
		if (l < 100000000) return 11;					// $999,999.99
		if (l < 1000000000) return 13;					// $9,999,999.99
		if (l < 10000000000L) return 14;				// $99,999,999.99
		if (l < 100000000000L) return 15;				// $999,999,999.99
		if (l < 1000000000000L) return 17;				// $9,999,999,999.99
		if (l < 10000000000000L) return 18;				// $99,999,999,999.99
		if (l < 100000000000000L) return 19;			// $999,999,999,999.99
		if (l < 1000000000000000L) return 21;			// $9,999,999,999,999.99
		if (l < 10000000000000000L) return 22;			// $99,999,999,999,999.99
		if (l < 100000000000000000L) return 23;			// $999,999,999,999,999.99
		if (l < 1000000000000000000L) return 25;		// $9,999,999,999,999,999.99

		return 26;										// $19,999,999,999,999,999.99
	}

}	// End CurrencyFormatter
