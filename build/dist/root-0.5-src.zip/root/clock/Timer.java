/*
 * Timer.java
 * 
 * Last Modified: 03/12/2016
 */
package root.clock;

/**
 * TODO http://www.howtogeek.com/244996/how-to-use-the-alarm-timer-and-stopwatch-on-android/
 * 
 * How to Use the Timer
 * 	- You can set up multiple timers in the Clock app, making this more useful
 *    than your standard kitchen timer, which can usually, at most, only time
 *    two things at the same time. To use the timer, tap the timer icon at the
 *    top of the screen. Set the amount of time for the timer using the number
 *    pad on the right. Be sure to enter zeros as needed. For example, to set
 *    a timer for 10 minutes, tap 1000 on the number pad. If you only tap
 *    10 you will end up with 10 seconds on your timer, not 10 minutes. You
 *    can see the number of hours, minutes, and seconds on the digital readout
 *    on the left as you type the time. To start the timer, tap the red Start
 *    button at the bottom.
 * 	- Just like with the alarms, you can have multiple timers, so you might
 *    want to give them names so you know which timer is timing which activity.
 *    To add a label to the current timer, tap Label.
 * 	- There are a couple of settings you can change for timers. To access these
 *    settings, tap the menu button and tap Settings on the popup menu as
 *    described earlier. The Timer Expired ringtone is set by default as the
 *    sound used when the timer expires. If you want to change the ringtone,
 *    tap “Timer ringtone.
 * 
 * @author esmith
 * @version 1.0
 */
public class Timer {

	// <><><><><><><><><><><><><>< Attributes ><><><><><><><><><><><><><><><><>

	/** The number of milliseconds before the <code>Timer</code> expires		*/
	private long expiry;

	/** The start time of the <code>Timer</code>								*/
	private long startTime;

	// <><><><><><><><><><><><><> Constructors <><><><><><><><><><><><><><><><>

	/**
	 * Creates a <code>Timer</code> instance initialized with start time from
	 * {@link java.lang.System#currentTimeMillis()}
	 */
	public Timer() {
		this.startTime = System.currentTimeMillis();
	}

	/**
	 * Creates a <code>Timer</code> instance initialized with start time from
	 * {@link java.lang.System#currentTimeMillis()} and the supplied default
	 * expiry value.
	 * 
	 * @param expiry The number of milliseconds before the <code>Timer</code> expires.
	 */
	public Timer(final long expiry) {
		this.startTime = System.currentTimeMillis();
		this.expiry = expiry;
	}

	// <><><><><><><><><><><><>< Public Methods ><><><><><><><><><><><><><><><>

	/**
	 * Returns the elapsed time since the start time of the <code>Timer</code>.
	 * 
	 * @return the elapsed time since the start time of the <code>Timer</code>.
	 */
	public final long elapsed() {
		return System.currentTimeMillis() - startTime;
	}

	/**
	 * Returns the expiry of this <code>Timer</code>.
	 * 
	 * @return the expiry of this <code>Timer</code>.
	 */
	public final long getExpiry() {
		return expiry;
	}

	/**
	 * Sets the <code>Timer</code> expiry.
	 * 
	 * @param expiry The expiry value to set.
	 */
	public final void setExpiry(final long expiry) {
		this.expiry = expiry;
	}

	/**
	 * Returns <code>true</code> if the elapsed time of this <code>Timer</code>
	 * is greater than or equal to the expiry value.
	 * <p>
	 * <b>NOTE:</b> The <code>Timer</code> only expires if the expiry value is
	 * greater than zero.
	 *
	 * @return <code>true</code> if <code>Timer</code> has expired, <code>false</code> otherwise.
	 */
	public final boolean hasExpired() {
		return (expiry > 0 && elapsed() >= expiry);
	}

	/**
	 * Returns <code>true</code> if the elapsed time of this <code>Timer</code>
	 * is greater than or equal to the expiry value.
	 * <p>
	 * <b>NOTE:</b> This is a convenience method for when you need to evaluate
	 * multiple <code>Timer</code> objects against a single point in time.
	 * 
	 * @param currentTime The current time which is used to calculate the elapsed time of this <code>Timer</code>
	 * @return <code>true</code> if <code>Timer</code> has expired, <code>false</code> otherwise.
	 */
	public final boolean hasExpired(final long currentTime) {
		return (expiry > 0 && (currentTime - startTime) >= expiry);
	}

	/**
	 * Returns the amount of time remaining before the timer expires.
	 *
	 * @return the amount of time remaining before the timer expires.
	 */
	public final long remaining() {
		return (expiry > 0) ? expiry - elapsed() : 0L;
	}

	/**
	 * Returns the amount of time remaining before the timer expires.
	 * <p>
	 * <b>NOTE:</b> This is a convenience method for when you have already
	 * called {@link java.lang.System#currentTimeMillis()}
	 * 
	 * @param currentTime The current time which is used to calculate the elapsed time of this <code>Timer</code>
	 * @return the amount of time remaining before the timer expires.
	 */
	public final long remaining(final long currentTime) {
		return (expiry > 0) ? expiry - (currentTime - startTime) : 0L;
	}

	/**
	 * Resets the <code>Timer</code> start time to the value returned from
	 * {@link java.lang.System#currentTimeMillis()}
	 */
	public final void reset() {
		startTime = System.currentTimeMillis();
	}

	/**
	 * Resets the <code>Timer</code> start time to the specified current time.
	 * <p>
	 * <b>NOTE:</b> This is a convenience method for when you have already
	 * called {@link java.lang.System#currentTimeMillis()}
	 * 
	 * @param currentTime The current time to assign to the <code>Timer</code> start time
	 */
	public final void reset(final long currentTime) {
		startTime = currentTime;
	}

}	// End Timer
