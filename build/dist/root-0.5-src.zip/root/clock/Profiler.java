package root.clock;

import java.math.BigDecimal;
import java.math.RoundingMode;

import root.math.Stat;

/**
 * TODO: Hmm, ratios!  How to implement, and what do you compare against?
 * 
 * @author esmith
 * @version 1.0
 */
public class Profiler {

	private final Stat time;
	private final Stat results;

	public Profiler() {
		time = new Stat();
		results = new Stat();
	}

	public void accrue(final Stopwatch t) {
		time.add(t.elapsed());
	}

	public void accrue(final Stopwatch t, final int numResults) {
		this.accrue(t);
		results.add(numResults);
	}

	public Stat getResultStats() {
		return results;
	}

	public String getThroughput() {
		final double throughput = results.sum() / (time.sum() / 1000.0);

		return new BigDecimal(throughput).setScale(2, RoundingMode.HALF_DOWN).toString() + "/second";
	}

	public Stat getTimeStats() {
		return time;
	}

	// TODO: Do I need a Duration type (hr, min, sec, ms)?
	@Override public String toString() {
		final StringBuilder builder = new StringBuilder("(");

		builder.append(time.count()).append(" count, ");

		if (time.sum() < 1000)
			builder.append(time.sum()).append("ms total, ");
		else
			builder.append(new BigDecimal(time.sum() / 1000.0).setScale(2, RoundingMode.HALF_DOWN)).append(" sec total, ");

		if (time.mean() < 1000)
			builder.append(time.mean()).append("ms average, ");
		else
			builder.append(new BigDecimal(time.mean() / 1000.0).setScale(2, RoundingMode.HALF_DOWN)).append(" sec average, ");

		if (time.min() < 1000)
			builder.append(time.min()).append("ms/");
		else
			builder.append(new BigDecimal(time.min() / 1000.0).setScale(2, RoundingMode.HALF_DOWN)).append(" sec/");

		if (time.max() < 1000)
			builder.append(time.max()).append("ms min/max");
		else
			builder.append(new BigDecimal(time.max() / 1000.0).setScale(2, RoundingMode.HALF_DOWN)).append(" sec min/max");

		return builder.append(')').toString();
	}

}	// End Profiler
