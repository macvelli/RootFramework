package root.clock;

import java.util.Date;

import root.data.structure.MapHashed;

/**
 * TODO: This guy needs a pimped out toString() method so I don't have to write out the Profilers every time I test something, just System.out.println(Watch) and be done with it
 * 
 * How to Use the Stopwatch
 * 	- The Clock app has a simple but useful stopwatch you can use to time
 *    activities. To access it, tap the stopwatch icon at the top of the
 *    screen. The stopwatch does not need any set up before use, so tap the
 *    Start button to start it.
 * 	- The stopwatch allows you to record lap times, which is basically stopping
 *    the stopwatch as specific points, recording each time you stop the
 *    stopwatch. Tap the lap button each time you want to record a lap time,
 *    for example, when someone your timing completes a lap around a track.
 * 	- Each lap time is recorded either next to the running time (landscape mode)
 *    or below it (portrait mode). While the stopwatch is running, the Start
 *    button is the Pause button, which you can use to temporarily stop the
 *    stopwatch.
 * 	- To reset the stopwatch to zero, tap the circular arrow icon. While the
 *    stopwatch is paused, you can tap the Share button on the bottom-right to
 *    share the time and lap times with someone, upload to a cloud service, or
 *    one of many sharing options.
 * 
 * @author esmith
 * @version 1.0
 */
public final class Stopwatch {

	private boolean							running;

	private boolean							failed;

	private long							start;

	private long							stop;

	private Date							begin;

	private Date							end;

	private String							name;

	private final Profiler					total;

	private final MapHashed<String, Profiler>	profilerMap;

	public Stopwatch() {
		total = new Profiler();
		profilerMap = new MapHashed<String, Profiler>();
	}

	public Stopwatch(final String name) {
		this();
		this.name = name;
	}

	public long elapsed() {
		return (stop - start);
	}

	public boolean isRunning() {
		return running;
	}

	public String freeMemory(final String task) {
		final StringBuilder builder = new StringBuilder(name);

		builder.append(' ').append(task).append(':').append(' ');
		builder.append(Runtime.getRuntime().freeMemory() >> 10).append('K');

		return builder.toString();
	}

	public void mark(final String profile) {
		stop = System.currentTimeMillis();
		total.accrue(this);
		profilerMap.get(profile, Profiler.class).accrue(this);
		start = System.currentTimeMillis();
	}

	public void start() {
		if (!running) {
			running = true;
			start = System.currentTimeMillis();
			if (begin == null)
				begin = new Date(start);
		}
	}

	public void stop(final String... profiles) {
		if (running) {
			stop = System.currentTimeMillis();
			end = new Date(stop);
			total.accrue(this);

			for (String s : profiles)
				profilerMap.get(s, Profiler.class).accrue(this);
			running = false;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Date getStartDate() {
		return begin;
	}

	public Date getEndDate() {
		return end;
	}

	public void failed() {
		failed = true;
	}

	public boolean hasFailed() {
		return failed;
	}

	public int getNumProcessed() {
		return (int) total.getResultStats().sum();
	}

	public void setNumProcessed(final int processed) {
		total.getResultStats().add(processed);
	}

	public Profiler getProfile(final String profile) {
		return profilerMap.get(profile);
	}

	public Profiler getTotal() {
		return total;
	}

}	// End Watch
