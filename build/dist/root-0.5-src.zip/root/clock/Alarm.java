package root.clock;

/**
 * TODO http://www.howtogeek.com/244996/how-to-use-the-alarm-timer-and-stopwatch-on-android/
 * TODO Is there any difference between an Alarm and a Timer?
 * 
 * @author esmith
 * @version 1.0
 */
public class Alarm {

}
